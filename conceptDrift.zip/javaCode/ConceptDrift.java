import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import ptolemy.plot.Plot;
import ptolemy.plot.PlotApplication;

public class ConceptDrift {

		
	private static Set<Vertex> getIntersection(Set<Vertex> set1, Set<Vertex> set2) {
        boolean set1IsLarger = set1.size() > set2.size();
        Set<Vertex> o =new HashSet<Vertex>();
        if (set1IsLarger) {
			for (Vertex v : set2) {
				for (Vertex u : set1) {
					if (v.ID==u.ID) {
						o.add(v);
					}
				}
				
			}
		}
        else{
        	for (Vertex v : set1) {
				for (Vertex u : set2) { 
					if (v.ID==u.ID) {
						o.add(v);
					}
				}
				
			}
        }
        return o;
    }
	private static Set<Vertex> mutualNeighbors(int v1, int v2, Map<Integer,HashSet<Vertex>> neighbors){
    	HashSet<Vertex> neighbors1=neighbors.get(v1);
    	HashSet<Vertex> neighbors2=neighbors.get(v2);
    	
    	return getIntersection(neighbors1, neighbors2);
    }
    private static Vector<Vertex> VectorOf_lastPercentile(Set<Vertex> set, HashSet<Integer> uniquestamps, double butterflyConnectivityPercentile){
    	int[] timestamps=toArray(uniquestamps);
    	Arrays.sort(timestamps);
    	HashSet<Integer> percentileTimestamps=new HashSet<Integer>();       
    	for (int i = (int) (timestamps.length-Math.round(timestamps.length*butterflyConnectivityPercentile)); i < timestamps.length; i++) {
    		percentileTimestamps.add(timestamps[i]);
		}
    	Vector<Vertex> v=new Vector<Vertex>();
    	for (Vertex i : set) {
    		if (percentileTimestamps.contains(i.Timestamp)) {
    			v.add(i);
			}
		}
    	return v;   	
    }
    private static int[] toArray(HashSet<Integer> s){
    	int size=s.size();
    	int[] array=new int[size];
    	int t=0;
    	for (Iterator iterator2 = s.iterator(); iterator2.hasNext();) {
			Integer integer = (Integer) iterator2.next();
			array[t]=integer;
			t++;
		}
    	return array;   	
    } 
    private static String[] getColumns(String line, String separator) { 
        return line.split(separator);
    }
    private static BipartiteGraph ingest_sgr_to_BBG(int vertexI_ID,int vertexJ_ID,int timeStamp, String separator, int startVertexIndexinFile, BipartiteGraph BBG) throws FileNotFoundException {
    	
      	int iStrength=0, jStrength=0, istamp=0, jstamp=0;
    	Vertex iv=null,jv=null;
    	iStrength=0;jStrength=0;
		istamp=timeStamp; jstamp=timeStamp;
			
			
		iv=new Vertex(istamp, vertexI_ID, iStrength);
		jv=new Vertex(jstamp, vertexJ_ID, jStrength);
		IJ_Edge e_ij=new IJ_Edge(iv,jv,timeStamp);
		if ( !(BBG.IvertexID_JNeighbors_HashIndex.containsKey(e_ij.i.ID) && BBG.IvertexID_JNeighbors_HashIndex.get(e_ij.i.ID).contains(e_ij.j))){ 
			BBG.add_IJEdge(e_ij);
		}
		return BBG;
    }
    private static void add_butterfly_to_BGvListOfButterflies(HashMap<Integer,HashSet<HashSet<String>>> vertexID_butterflyList, int BGvID, HashSet<String> butterfly) {
    	if (vertexID_butterflyList.containsKey(BGvID)) {
			vertexID_butterflyList.get(BGvID).add(butterfly);
		}
		else {
			HashSet<HashSet<String>> set_of_butterflies=new HashSet<HashSet<String>>();
			set_of_butterflies.add(butterfly);
			vertexID_butterflyList.put(BGvID, set_of_butterflies);
		}
    }
    private static void remove_m_RandomVertex(int m, WeightedUnipartiteGraph G){    																																																								//System.out.print(m+" vertices for removal: ");
    	List<UGVertex> list=new ArrayList<UGVertex>();
		HashSet<UGVertex> vertices=G.vertices;
		for (UGVertex v : vertices) {
			list.add(v);
		}
		Collections.shuffle(list);
		
		HashSet<UGVertex> selectedVertices=new HashSet<UGVertex>(m);
		int listSize=list.size();
		UGVertex candidatevertex;
		
		while(selectedVertices.size()<m) {
			candidatevertex=list.get((int)(Math.random()*listSize));
			selectedVertices.add(candidatevertex);
			
		}
		for (UGVertex v : selectedVertices) {
			G.remove_UGVertex(v);
		}
		list.clear();
	}
    private static WeightedUnipartiteGraph createButterflyBasedUWGOprojection(Boolean connectThroughIvertices, BipartiteGraph BBG,WeightedUnipartiteGraph UWGO, HashMap<HashSet<String>,UGVertex> butterfly_UGvertex, HashSet<Integer> uniquestamps, double butterflyConnectivityPercentile) {
    	Vector<Vertex>  i1neighbors=new Vector<Vertex>(); List<Vertex> i1neighbors_sublist=new ArrayList<Vertex>(); 
    	int i1neighbors_currentSize, j1ID, i2vertices_size;
  		Set<Vertex> i2_vertices;
  		HashSet<String> butterfly=new HashSet<String>(4);
  		HashSet<HashSet<String>> identified_butterflies=new HashSet<HashSet<String>>();
  		HashSet<HashSet<String>> merged_listOfButterflies=new HashSet<HashSet<String>>();
  		HashMap<Integer,HashSet<HashSet<String>>> ivertexID_butterflyList=new HashMap<Integer, HashSet<HashSet<String>>>();
		HashMap<Integer,HashSet<HashSet<String>>> jvertexID_butterflyList=new HashMap<Integer, HashSet<HashSet<String>>>();
		int id; double initphase, natFreq;
  		UGVertex UGv,v;
  		UG_Edge e1;
  		
  		Map<Integer,HashSet<Vertex>> imap= BBG.IvertexID_JNeighbors_HashIndex;
    	Map<Integer,HashSet<Vertex>> jmap= BBG.JvertexID_INeighbors_HashIndex;
    	Set<Integer>	ivertices=imap.keySet();
    	for (Integer vi1ID : ivertices) {
			i1neighbors=VectorOf_lastPercentile(imap.get(vi1ID), uniquestamps, butterflyConnectivityPercentile);//filter j-vertex neighbors of i1 to those who are in the last utterflyConnectivityPercentile of the uniquestamps_inCurrentBGwindow
			i1neighbors_currentSize=i1neighbors.size();                          
			for (int jindex = 0; jindex < i1neighbors_currentSize; jindex++) {
				j1ID=i1neighbors.elementAt(jindex).ID;
				i1neighbors_sublist=i1neighbors.subList(jindex+1, i1neighbors_currentSize);
				for (Vertex vj2 : i1neighbors_sublist) {
					i2_vertices=mutualNeighbors(j1ID,vj2.ID, jmap);
					i2vertices_size=i2_vertices.size()-1;
					if (i2vertices_size!=0) {
						for (Vertex vi2 : i2_vertices) {
							if (vi2.ID != vi1ID) {
								butterfly=new HashSet<String>(4);
								butterfly.add("i"+vi1ID);butterfly.add("j"+j1ID);butterfly.add("i"+vi2.ID);butterfly.add("j"+vj2.ID);
								if (!identified_butterflies.contains(butterfly)) {
									identified_butterflies.add(butterfly);		
									//add identified vertices to corresponding lists
									add_butterfly_to_BGvListOfButterflies(ivertexID_butterflyList, vi1ID, butterfly);
									add_butterfly_to_BGvListOfButterflies(ivertexID_butterflyList, vi2.ID, butterfly);
									add_butterfly_to_BGvListOfButterflies(jvertexID_butterflyList, j1ID, butterfly);
									add_butterfly_to_BGvListOfButterflies(jvertexID_butterflyList, vj2.ID, butterfly);
									
									//map the current butterfly to a Unipartite Graph vertex (UGv)
									id=0;
									initphase=0;                          
									natFreq=0;
									UGv=new UGVertex(id, initphase, natFreq);
									UGv.setID(UGv.hashCode());
									UWGO.add_Vertex(UGv);
									butterfly_UGvertex.put(butterfly,UGv);
									//connect this butterfly-UGv to any butterfly-UGvs of its vertices
									merged_listOfButterflies=new HashSet<HashSet<String>>();
									if (connectThroughIvertices) {
										merged_listOfButterflies.addAll(ivertexID_butterflyList.get(vi1ID));
										merged_listOfButterflies.addAll(ivertexID_butterflyList.get(vi2.ID));
									}
									else {
										merged_listOfButterflies.addAll(jvertexID_butterflyList.get(j1ID));
										merged_listOfButterflies.addAll(jvertexID_butterflyList.get(vj2.ID));
									}
									for ( HashSet<String> b : merged_listOfButterflies) {
										v=butterfly_UGvertex.get(b);
										if (!UGv.equals(v)) {
											e1=new UG_Edge(UGv,v,merged_listOfButterflies.size()*1.0);//weight=number of butterflies connecting UGv and v
											UWGO.add_Edge(e1);
										}
									}
								}
							}
						} 
					}						
				}//end j2
			}//end j1		
		}//end i1
    	
    	//set null to free up memory
    	ivertexID_butterflyList=null;
	    jvertexID_butterflyList=null;
	    merged_listOfButterflies=null;
	    System.gc();
	                                                                                                                                                                                                                               //System.out.println("UG created...|V|="+UWGO.vertices.size()+" |E|="+UWGO.edges.size());
	    return UWGO;
    }
     
    private static double standardDeviation_alist(ArrayList<Integer> a, double mean){
		double std=0;
		int n=a.size();
		for (int i = 0; i < n; i++) {
			std+=Math.pow(a.get(i)-mean, 2);
		}
		std/=n;
		std=Math.sqrt(std);
		return std;
	}
    private static Vector<Double> kuramato(WeightedUnipartiteGraph UWGO, int numberOfRuns, double h, double couplingStrength, Vector<Double> orderParameter, boolean weighted_RungKutah){
    	Map<UGVertex,Double> UGvertices_phases=new HashMap<UGVertex, Double>();
    	for (int i = 0; i <numberOfRuns ; i++) {
	    	if (weighted_RungKutah) {
	    		UGvertices_phases=weightedRungeKutah(UWGO, couplingStrength, h);
			}
	    	else {
	    		UGvertices_phases=unweightedRungeKutah(UWGO, couplingStrength, h);
	    	}
	    	setInitialPhases(UGvertices_phases, UWGO);	    	   	
	    }	
	   orderParameter=computeOrderParameter(UWGO, orderParameter);
	   return orderParameter;
	}
    private static Vector<Double> computeOrderParameter(WeightedUnipartiteGraph UWGO, Vector<Double> orderParameter){
    	HashSet<UGVertex>  UGvertices=UWGO.vertices;
	    double sumCosine=0, sumSine=0, phase=0; 
	    int allVerticesCount=UGvertices.size();
	    for (UGVertex u : UGvertices) {
	    	phase=u.Phase;
	    	sumCosine+=Math.cos(phase);
	    	sumSine+=Math.sin(phase);
	    }
	    sumCosine=Math.pow(sumCosine, 2);
	    sumSine=Math.pow(sumSine, 2);
	    orderParameter.add((Math.sqrt(sumSine+sumCosine)*1.0)/(allVerticesCount*1.0));
	    return orderParameter;
    }
    private static void setInitialPhases(Map<UGVertex,Double> map, WeightedUnipartiteGraph UWGO) {
    	HashSet<UGVertex> UGvertices=UWGO.vertices;
    	for (UGVertex u : UGvertices) {
 	    	u.setPhase(map.get(u));
 	    }
    }
    private static void setNaturalFrequencies_Gaussian(WeightedUnipartiteGraph UWGO) {
    	double u,v,pi,r,y;
    	pi=Math.PI;
    	HashSet<UGVertex> UGvertices=UWGO.vertices;
    	for (UGVertex ugvertex : UGvertices) {
    		u=Math.random();
			v=Math.random();
			y=u*2*pi;
			r=Math.sqrt(-2*Math.log1p(v-1));//r=sqrt(-2*log(v)) log(v)=natural log(v) and Math.log1p(v)=ln(1+x) so log(v)=Math.log1p(v-1)
			ugvertex.setFreq(r*Math.cos(y));    		
 	    }
    }
    private static Map<UGVertex,Double> unweightedRungeKutah(WeightedUnipartiteGraph UWGO, double couplingStrength, double h){
    	HashSet<UGVertex> UGvertices, neighbors;
    	Map<UGVertex,Double> UGvertex_currentPhase=new HashMap<UGVertex, Double>();
    	Map<UGVertex,Vector<Double>> UGVertex_k1_k2_k3_k4=new HashMap<UGVertex, Vector<Double>>();
    	Vector<Double> temp_k1_k2_k3_k4;
    	double phase_ofu=0;
        //---------------------------------------------K1------------------------------------------------
        UGvertices=UWGO.vertices;
	    double tempS=0;
	    UG_Edge e=null;
	    for (UGVertex u : UGvertices) {
	    	tempS=0;
	    	phase_ofu=u.Phase;
	    	neighbors=UWGO.vertexID_Neighbors_HashIndex.get(u.ID);
	    	if (neighbors!=null) {
	    		for (UGVertex neighbor : neighbors) {
		    		tempS+=Math.sin(phase_ofu-neighbor.Phase);//K1=omega+(K/M)*S  where S=sum(sin(theta[j]-theta[i])) for all neighbors(j) of i
				}
			}
	    	temp_k1_k2_k3_k4=new Vector<Double>(4);temp_k1_k2_k3_k4.add(0.0);temp_k1_k2_k3_k4.add(0.0);temp_k1_k2_k3_k4.add(0.0);temp_k1_k2_k3_k4.add(0.0);
	    	temp_k1_k2_k3_k4.setElementAt(u.NaturalFrequency+(tempS*couplingStrength), 0);
	    	UGVertex_k1_k2_k3_k4.put(u, temp_k1_k2_k3_k4);
	    }
        //---------------------------------------------K2------------------------------------------------
	    for (UGVertex u : UGvertices) {
	    	UGvertex_currentPhase.put(u, u.Phase+(0.5*h*UGVertex_k1_k2_k3_k4.get(u).elementAt(0))  ); // theta = theta_0 + 0.5*h*K_1
	    }
	    Set<UGVertex> vs=UGvertex_currentPhase.keySet();
	    for (UGVertex u : UGvertices) {
	    	phase_ofu=UGvertex_currentPhase.get(u);
	    	tempS=0;
	    	neighbors=UWGO.vertexID_Neighbors_HashIndex.get(u.ID);
	    	if (neighbors!=null) {
	    		for (UGVertex neighbor : neighbors) {
		    		tempS+=Math.sin(UGvertex_currentPhase.get(neighbor)-phase_ofu);
				}
	    	}
	    	temp_k1_k2_k3_k4=UGVertex_k1_k2_k3_k4.get(u);
	    	temp_k1_k2_k3_k4.setElementAt(u.NaturalFrequency+(tempS*couplingStrength), 1);
	    	UGVertex_k1_k2_k3_k4.put(u, temp_k1_k2_k3_k4);//K2=omega+(K/M)*S  where S=sum(sin(theta[j]-theta[i])) for all neighbors(j) of i
	    }
        //---------------------------------------------K3------------------------------------------------
	    for (UGVertex u : UGvertices) {
	    	UGvertex_currentPhase.put(u, u.Phase+(0.5*h*UGVertex_k1_k2_k3_k4.get(u).elementAt(1))  ); // theta = theta_0 + 0.5*h*K_2
	    }
	    for (UGVertex u : UGvertices) {
	    	phase_ofu=UGvertex_currentPhase.get(u);
	    	tempS=0;
	    	neighbors=UWGO.vertexID_Neighbors_HashIndex.get(u.ID);
	    	if (neighbors!=null) {
	    		for (UGVertex neighbor : neighbors) {
		    		tempS+=Math.sin(UGvertex_currentPhase.get(neighbor)-phase_ofu);
				}
	    	}
	    	temp_k1_k2_k3_k4=UGVertex_k1_k2_k3_k4.get(u);
	    	temp_k1_k2_k3_k4.setElementAt(u.NaturalFrequency+(tempS*couplingStrength), 2);
	    	UGVertex_k1_k2_k3_k4.put(u, temp_k1_k2_k3_k4);//K3=omega+(K/M)*S  where S=sum(sin(theta[j]-theta[i])) for all neighbors(j) of i
	    }
        //---------------------------------------------K4------------------------------------------------
	    for (UGVertex u : UGvertices) {
	    	UGvertex_currentPhase.put(u, u.Phase+(h*UGVertex_k1_k2_k3_k4.get(u).elementAt(2))  ); // theta = theta_0 + h*K_3
	    }
	    for (UGVertex u : UGvertices) {
	    	phase_ofu=UGvertex_currentPhase.get(u);
	    	tempS=0;
	    	neighbors=UWGO.vertexID_Neighbors_HashIndex.get(u.ID);
	    	if (neighbors!=null) {
	    		for (UGVertex neighbor : neighbors) {
		    		tempS+=Math.sin(UGvertex_currentPhase.get(neighbor)-phase_ofu);
				}
	    	}
	    	temp_k1_k2_k3_k4=UGVertex_k1_k2_k3_k4.get(u);
	    	temp_k1_k2_k3_k4.setElementAt(u.NaturalFrequency+(tempS*couplingStrength), 3);
	    	UGVertex_k1_k2_k3_k4.put(u, temp_k1_k2_k3_k4);//K4=omega+(K/M)*S  where S=sum(sin(theta[j]-theta[i])) for all neighbors(j) of i
	    }
        //---------------------------------------------final theta out----------------------------------------------
	    for (UGVertex u : UGvertices) { //theta_out=mod((in+(h/6.0)*(K1+2*K2+2*K3+K4)),2*pi)
	    	UGvertex_currentPhase.put(u, (h/0.6)*(   UGVertex_k1_k2_k3_k4.get(u).elementAt(0)  +  (2.0*UGVertex_k1_k2_k3_k4.get(u).elementAt(1))  + (2.0*UGVertex_k1_k2_k3_k4.get(u).elementAt(2))  +  UGVertex_k1_k2_k3_k4.get(u).elementAt(3) )  ); 
	    }
        return UGvertex_currentPhase;
    }
    private static Map<UGVertex,Double> weightedRungeKutah(WeightedUnipartiteGraph UWGO, double couplingStrength, double h){
    	HashSet<UGVertex> UGvertices, neighbors;
    	Map<UGVertex,Double> UGvertex_currentPhase=new HashMap<UGVertex, Double>();
    	Map<UGVertex,Vector<Double>> UGVertex_k1_k2_k3_k4=new HashMap<UGVertex, Vector<Double>>();
    	Vector<Double> temp_k1_k2_k3_k4;
    	double phase_ofu=0;
    	double weight_of_uTOneighbor;
        //---------------------------------------------K1------------------------------------------------
        UGvertices=UWGO.vertices;
	    double tempS=0;
	    UG_Edge e=null;
	    for (UGVertex u : UGvertices) {
	    	tempS=0;
	    	phase_ofu=u.Phase;
	    	neighbors=UWGO.vertexID_Neighbors_HashIndex.get(u.ID);
	    	if (neighbors!=null) {
	    		for (UGVertex neighbor : neighbors) {
		    		if (UWGO.edgeIDs_edges.containsKey(u.ID+"-"+neighbor.ID)) {
		    			e=UWGO.edgeIDs_edges.get(u.ID+"-"+neighbor.ID);
					}
		    		else if (UWGO.edgeIDs_edges.containsKey(neighbor.ID+"-"+u.ID)) {
		    			e=UWGO.edgeIDs_edges.get(neighbor.ID+"-"+u.ID);
					}
		    		weight_of_uTOneighbor=e.Weight;  
		    		tempS+=weight_of_uTOneighbor*Math.sin(phase_ofu-neighbor.Phase);//K1=omega+(K/M)*S  where S=sum(sin(theta[j]-theta[i])) for all neighbors(j) of i
				}
	    	}
	    	temp_k1_k2_k3_k4=new Vector<Double>(4);temp_k1_k2_k3_k4.add(0.0);temp_k1_k2_k3_k4.add(0.0);temp_k1_k2_k3_k4.add(0.0);temp_k1_k2_k3_k4.add(0.0);
	    	temp_k1_k2_k3_k4.setElementAt(u.NaturalFrequency+(tempS*couplingStrength), 0);
	    	UGVertex_k1_k2_k3_k4.put(u, temp_k1_k2_k3_k4);
	    }
        //---------------------------------------------K2------------------------------------------------
	    for (UGVertex u : UGvertices) {
	    	UGvertex_currentPhase.put(u, u.Phase+(0.5*h*UGVertex_k1_k2_k3_k4.get(u).elementAt(0))  ); // theta = theta_0 + 0.5*h*K_1
	    }
	    Set<UGVertex> vs=UGvertex_currentPhase.keySet();
	    for (UGVertex u : UGvertices) {
	    	phase_ofu=UGvertex_currentPhase.get(u);
	    	tempS=0;
	    	neighbors=UWGO.vertexID_Neighbors_HashIndex.get(u.ID);
	    	if (neighbors!=null) {
	    		for (UGVertex neighbor : neighbors) {
		    		if (UWGO.edgeIDs_edges.containsKey(u.ID+"-"+neighbor.ID)) {
		    			e=UWGO.edgeIDs_edges.get(u.ID+"-"+neighbor.ID);
					}
		    		else if (UWGO.edgeIDs_edges.containsKey(neighbor.ID+"-"+u.ID)) {
		    			e=UWGO.edgeIDs_edges.get(neighbor.ID+"-"+u.ID);
					}
		    		weight_of_uTOneighbor=e.Weight; 
		    		tempS+=weight_of_uTOneighbor*Math.sin(UGvertex_currentPhase.get(neighbor)-phase_ofu);
				}
	    	}
	    	temp_k1_k2_k3_k4=UGVertex_k1_k2_k3_k4.get(u);
	    	temp_k1_k2_k3_k4.setElementAt(u.NaturalFrequency+(tempS*couplingStrength), 1);
	    	UGVertex_k1_k2_k3_k4.put(u, temp_k1_k2_k3_k4);//K2=omega+(K/M)*S  where S=sum(sin(theta[j]-theta[i])) for all neighbors(j) of i
	    }
        //---------------------------------------------K3------------------------------------------------
	    for (UGVertex u : UGvertices) {
	    	UGvertex_currentPhase.put(u, u.Phase+(0.5*h*UGVertex_k1_k2_k3_k4.get(u).elementAt(1))  ); // theta = theta_0 + 0.5*h*K_2
	    }
	    for (UGVertex u : UGvertices) {
	    	phase_ofu=UGvertex_currentPhase.get(u);
	    	tempS=0;
	    	neighbors=UWGO.vertexID_Neighbors_HashIndex.get(u.ID);
	    	if (neighbors!=null) {
	    		for (UGVertex neighbor : neighbors) {
		    		if (UWGO.edgeIDs_edges.containsKey(u.ID+"-"+neighbor.ID)) {
		    			e=UWGO.edgeIDs_edges.get(u.ID+"-"+neighbor.ID);
					}
		    		else if (UWGO.edgeIDs_edges.containsKey(neighbor.ID+"-"+u.ID)) {
		    			e=UWGO.edgeIDs_edges.get(neighbor.ID+"-"+u.ID);
					}
		    		weight_of_uTOneighbor=e.Weight;  
		    		tempS+=weight_of_uTOneighbor*Math.sin(UGvertex_currentPhase.get(neighbor)-phase_ofu);
				}
	    	}
	    	temp_k1_k2_k3_k4=UGVertex_k1_k2_k3_k4.get(u);
	    	temp_k1_k2_k3_k4.setElementAt(u.NaturalFrequency+(tempS*couplingStrength), 2);
	    	UGVertex_k1_k2_k3_k4.put(u, temp_k1_k2_k3_k4);//K3=omega+(K/M)*S  where S=sum(sin(theta[j]-theta[i])) for all neighbors(j) of i
	    }
        //---------------------------------------------K4------------------------------------------------
	    for (UGVertex u : UGvertices) {
	    	UGvertex_currentPhase.put(u, u.Phase+(h*UGVertex_k1_k2_k3_k4.get(u).elementAt(2))  ); // theta = theta_0 + h*K_3
	    }
	    for (UGVertex u : UGvertices) {
	    	phase_ofu=UGvertex_currentPhase.get(u);
	    	tempS=0;
	    	neighbors=UWGO.vertexID_Neighbors_HashIndex.get(u.ID);
	    	if (neighbors!=null) {
	    		for (UGVertex neighbor : neighbors) {
		    		if (UWGO.edgeIDs_edges.containsKey(u.ID+"-"+neighbor.ID)) {
		    			e=UWGO.edgeIDs_edges.get(u.ID+"-"+neighbor.ID);
					}
		    		else if (UWGO.edgeIDs_edges.containsKey(neighbor.ID+"-"+u.ID)) {
		    			e=UWGO.edgeIDs_edges.get(neighbor.ID+"-"+u.ID);
					}
		    		weight_of_uTOneighbor=e.Weight;  
		    		tempS+=weight_of_uTOneighbor*Math.sin(UGvertex_currentPhase.get(neighbor)-phase_ofu);
				}
	    	}
	    	temp_k1_k2_k3_k4=UGVertex_k1_k2_k3_k4.get(u);
	    	temp_k1_k2_k3_k4.setElementAt(u.NaturalFrequency+(tempS*couplingStrength), 3);
	    	UGVertex_k1_k2_k3_k4.put(u, temp_k1_k2_k3_k4);//K4=omega+(K/M)*S  where S=sum(sin(theta[j]-theta[i])) for all neighbors(j) of i
	    }
        //---------------------------------------------final theta out----------------------------------------------
	    for (UGVertex u : UGvertices) { //theta_out=mod((in+(h/6.0)*(K1+2*K2+2*K3+K4)),2*pi)
	    	UGvertex_currentPhase.put(u, (h/0.6)*(   UGVertex_k1_k2_k3_k4.get(u).elementAt(0)  +  (2.0*UGVertex_k1_k2_k3_k4.get(u).elementAt(1))  + (2.0*UGVertex_k1_k2_k3_k4.get(u).elementAt(2))  +  UGVertex_k1_k2_k3_k4.get(u).elementAt(3) )  ); 
	    }
        return UGvertex_currentPhase;
    }
	
    public static void readFile_getburstSizes(String file,String separator, int linebreaks, int column) throws IOException{
    	PrintWriter w=new PrintWriter("timestamp_index of first sgr_burst size in "+file);
    	
    	FileInputStream fstream = new FileInputStream(file);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
    	String line;
    	String[] columns;
    	int size;
    	String timestamp, lasttimestamp;
    	HashMap<String, Integer> burst_size=new HashMap<String, Integer>();
    	HashMap<String, Vector<Vector<Integer>>> burst_allsizesandTheirIndex=new HashMap<String, Vector<Vector<Integer>>>();
    	if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
    	
    	line = br.readLine();
    	columns = getColumns(line,separator);
		lasttimestamp=columns[column];
		burst_size.put(lasttimestamp, 1);
		
		Vector<String> burstStamps=new Vector<String>();
		
		int previousSize=0;
		int i=1;
    	while ((line = br.readLine()) != null){
    		
    		columns = getColumns(line,separator);
    		timestamp=columns[column];
    		
    		
    		if (burst_size.containsKey(timestamp) && timestamp.equals(lasttimestamp)) { // continue recording the size of current burst
				size=burst_size.get(lasttimestamp);
				burst_size.put(lasttimestamp, size+1);
			}
    		else if (burst_size.containsKey(timestamp)&& !timestamp.equals(lasttimestamp)) {//this is a repeated burst, record the previous size and restart the size from 1
    			previousSize=burst_size.get(timestamp);
    			if (burst_allsizesandTheirIndex.containsKey(timestamp)) {
    				Vector<Integer> size_index=new Vector<Integer>(2);size_index.add(previousSize);size_index.add(i);
    				burst_allsizesandTheirIndex.get(timestamp).add(size_index);
				}
    			else {
    				Vector<Vector<Integer>> vectorOf_size_index=new Vector<Vector<Integer>>();
    				Vector<Integer> size_index=new Vector<Integer>(2);size_index.add(previousSize);size_index.add(i);
    				vectorOf_size_index.add(size_index);
    				burst_allsizesandTheirIndex.put(timestamp, vectorOf_size_index);
    			}
    			burst_size.put(timestamp, 1);
    			burstStamps.add(timestamp);
			}
    		
    		
    		
    		else if (!burst_size.containsKey(timestamp)) {// a new non-repeated burst
    			burst_size.put(timestamp, 1);
    			burstStamps.add(timestamp);
    			
    			Vector<Vector<Integer>> vectorOf_size_index=new Vector<Vector<Integer>>();
				Vector<Integer> size_index=new Vector<Integer>(2);size_index.add(1);size_index.add(i);
				vectorOf_size_index.add(size_index);
				burst_allsizesandTheirIndex.put(timestamp, vectorOf_size_index);
    			
			}
    		
    		
    		lasttimestamp=timestamp;
    		i++;
    		
    		
    	}
    	
		int t0=833493600;
		
		Plot plot12=new Plot();
		plot12.setXLabel("burst index");
		plot12.setYLabel("burst size");
		plot12.setMarksStyle("dots");
		
		//int i=0;
    	//int[]a=new int[6500];
		
    	
    	double avgBurstSize=0; int max=0;ArrayList<Integer> sizes=new ArrayList<Integer>();
    	Set<String> timestamps=burst_allsizesandTheirIndex.keySet();
    	Vector<Vector<Integer>>v;
    	int burstIndex=0;
    	for (String t : timestamps) {//for(String t : burstStamps){//for (String t : timestamps) {
    		v=burst_allsizesandTheirIndex.get(t);
    		for (Vector<Integer> size_index : v) {
    			
    			avgBurstSize+=size_index.elementAt(0);
        		if (max<size_index.elementAt(0)) {
    				max=size_index.elementAt(0);
    			}
        		sizes.add(size_index.elementAt(0));
        		w.append(t+"\t"+size_index.elementAt(1)+"\t"+size_index.elementAt(0)+"\n");
    			
        		plot12.addPoint(1, size_index.elementAt(1), size_index.elementAt(0), false);//plot12.addPoint(1, Integer.parseInt(t), size_index.elementAt(0), false);
			}   		
    		//a[i]=Integer.parseInt(t);i++;
    		burstIndex++;
		}
    	avgBurstSize/=(sizes.size()*1.0);
    	System.out.println("\tavgBurstSize+-std: "+avgBurstSize+"+-"+standardDeviation_alist(sizes, avgBurstSize)+"\tmax burst size: "+max+" |t|="+timestamps.size());
    	w.close();
    	
    	
    	/*int t0=833493600;
    	Arrays.sort(a);
    	for (int j = 0; j < a.length; j++) {
    		if (a[j]!=0) {
    			//plot1.addPoint(0, j, burst_size.get(a[j]+""), true);
    			plot1.addPoint(1, a[j]-t0, burst_size.get(a[j]+""), true);
			}
    		
		}*/
    	
    	plot12.setTitle(file);
    	new PlotApplication(plot12);
    }
    public static void readFile_getavg(String file,String separator, int linebreaks, int column) throws IOException{
    	PrintWriter w=new PrintWriter("timestamp_index of first sgr_burst size in "+file);
    	
    	FileInputStream fstream = new FileInputStream(file);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
    	String line;
    	String[] columns;
    	
    	if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
    	
    	int temp=0;
    	double avg=0;
		int c=0;
		
    	while ((line = br.readLine()) != null){
    		columns = getColumns(line,separator);
    		if (!columns[column].equals("NaN")) {
				avg+=Math.abs(Integer.parseInt(columns[column]));
				c++;
			}
    	}
    	avg/=c;
    	
    	System.out.println("avg="+avg+" c="+c);
    }
       
    private static Vector<Vector<Integer>> detectDriftV2(int maxBsize,long drifttime, double avgBsize, Vector<Double> orderParameter, Vector<Double> orderParameter2, Vector<Vector<Integer>> detectedDrifts_timestamp_windowNumber, int windowNum, int t) {
    	int d=detectedDrifts_timestamp_windowNumber.size();
    	double p=Math.pow(-1, d);
    	int sdriftDetectionSubWindowSize=(int)(1000*Math.pow( Math.floor(Math.log10(Math.max(maxBsize,100)))/Math.floor(Math.log10(Math.max(avgBsize,10))), p));
    	
    	double mean1=0;
    	long detectiontime, detectionlatency;
    	Vector<Integer> timestamp_winNum;
    	int s2=orderParameter2.size(), 
    		Sprime=(int) (sdriftDetectionSubWindowSize*(1-(0.1*d)));
    	
    	int s1=orderParameter.size();
    	int Nmore2=0, Nless2=0;
	    if (s2>sdriftDetectionSubWindowSize) {
	    	
			double temp=0, currentO2=orderParameter2.elementAt(s2-1);
			for (int i = s2-sdriftDetectionSubWindowSize-1; i < s2; i++) {
				temp=orderParameter2.elementAt(i);
				if (temp>currentO2) {
					Nmore2++;
				}
				if (temp<currentO2) {
					Nless2++;
				}
			}
	    	
			mean1=0;
			for (int i = s1-Sprime-1; i < s1; i++) {
				temp=orderParameter.elementAt(i);
				mean1+=temp;
			}
			mean1/=sdriftDetectionSubWindowSize;
			
			double x=1*(2+1*d);
			double r1=Math.abs((int)(orderParameter.lastElement()*Math.pow(10, x))-(int)(mean1*Math.pow(10, x))*1.0)/(1.0*Math.pow(10, x)); 
			if( (Nmore2>=Sprime || Nless2>=Sprime) && r1<5*Math.pow(10,-x)) {
				detectiontime=System.currentTimeMillis();
				detectionlatency=detectiontime-drifttime;
				System.out.println("Detected Drift  >>         t="+t+" W#:"+windowNum+
						" , Nmore2="+Nmore2+" Nless2="+Nless2+
						"  >>   mean1="+mean1+" r1="+orderParameter.elementAt(s1-1)+
						" r2="+orderParameter2.elementAt(s2-1)+						
						"  S="+sdriftDetectionSubWindowSize+" avgBsize="+avgBsize+" maxBsize="+maxBsize+
						" detection time="+detectiontime+" latency="+detectionlatency+" [s2/2]="+Sprime+" r1="+r1+" x="+x );

				timestamp_winNum=new Vector<Integer>(2);
				timestamp_winNum.add(t);timestamp_winNum.add(windowNum);
				detectedDrifts_timestamp_windowNumber.add(timestamp_winNum);				
			}			
	    }
	    return detectedDrifts_timestamp_windowNumber;
    }
    private static Vector<Vector<Integer>> detectDriftV1(int maxBsize,long drifttime, double avgBsize, Vector<Double> orderParameter, Vector<Double> orderParameter2, Vector<Vector<Integer>> detectedDrifts_timestamp_windowNumber, int windowNum, int t) {
    	int d=detectedDrifts_timestamp_windowNumber.size();
    	double p=Math.pow(-1, d);
    	int sdriftDetectionSubWindowSize=(int) (500.0*(d+2.0)/(d+1.0));    		
    	double mean1=0;
    	long detectiontime, detectionlatency;
    	Vector<Integer> timestamp_winNum;
    	int s2=orderParameter2.size(), Sprime=(int) (sdriftDetectionSubWindowSize*(1-(0.05*d)));
    	
    	int s1=orderParameter.size();
    	int Nmore2=0, Nless2=0;
	    if (s2>sdriftDetectionSubWindowSize) {
	    	
			double temp=0, currentO2=orderParameter2.elementAt(s2-1);
			for (int i = s2-sdriftDetectionSubWindowSize-1; i < s2; i++) {
				temp=orderParameter2.elementAt(i);
				if (temp>currentO2) {
					Nmore2++;
				}
				if (temp<currentO2) {
					Nless2++;
				}
			}
	    	
			mean1=0;
			for (int i = s1-sdriftDetectionSubWindowSize-1; i < s1; i++) {
				temp=orderParameter.elementAt(i);
				mean1+=temp;
			}
			mean1/=sdriftDetectionSubWindowSize;
			
			
			double x=1*(2+1*d);
			double r1=Math.abs((int)(orderParameter.lastElement()*Math.pow(10, x))-(int)(mean1*Math.pow(10, x))*1.0)/(1.0*Math.pow(10, x));
			if( (Nmore2>=Sprime || Nless2>=Sprime) && r1<Math.pow(10,-x)) {
				detectiontime=System.currentTimeMillis(); 
				detectionlatency=detectiontime-drifttime;
				System.out.println("Detected Drift  >>         t="+t+" W#:"+windowNum+
						" , Nmore2="+Nmore2+" Nless2="+Nless2+
						"  >>   mean1="+mean1+" r1="+orderParameter.elementAt(s1-1)+
						" r2="+orderParameter2.elementAt(s2-1)+						
						"  S="+sdriftDetectionSubWindowSize+" avgBsize="+avgBsize+" maxBsize="+maxBsize+
						" detection time="+detectiontime+" latency="+detectionlatency+" [s2/2]="+Sprime+" r1="+r1+" x="+x );

				timestamp_winNum=new Vector<Integer>(2);
				timestamp_winNum.add(t);timestamp_winNum.add(windowNum);
				detectedDrifts_timestamp_windowNumber.add(timestamp_winNum);				
			}
			
	    }
	    return detectedDrifts_timestamp_windowNumber;
    }
    public static void run(boolean connectButterfliesWithAtleastOneIvertex, 
    		int startVertexIndexinFile, String filename, int firstTimestamp, int rows, String separator, int linebreaks, 
    		int BGwindowSize_numberOfburstsPerWindow, int UGwindowSize_numberOfVerticesPerWindow, 
    		double butterflyConnectivityPercentile, 
    		int numberOfKuramotoRuns, double RungrKutah_h, int KuramotoCouplingStrength, boolean weighted_RungKutah) 
    				throws NumberFormatException, IOException {
		
    	System.out.println("run "+filename);
  		
  		FileInputStream fstream = new FileInputStream(filename);
      	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
      	String sgr;
  		int vertexI_ID,vertexJ_ID,timeStamp=0;
  		String[] columns;
  		int t=1, windowNum=1;
  		WeightedUnipartiteGraph UWGO=new WeightedUnipartiteGraph();
  		UWGO.vertices=new HashSet<UGVertex>();
  		HashMap<HashSet<String>,UGVertex> butterfly_UGvertex=new HashMap<HashSet<String>,UGVertex>();
  		HashSet<UGVertex> UGvertices, neighbors=new HashSet<UGVertex>();
  		Vector<Vector<Double>> orderparameters=new Vector<Vector<Double>>(2);
  		Vector<Double> orderParameter=new Vector<Double>(), orderParameter2=new Vector<Double>();
  		int allVerticesCount=0;
  		double phase=0;
  		BipartiteGraph BBG=new BipartiteGraph();
  		BBG.edges=new Vector<IJ_Edge>();
  		BBG.ivertices=new HashSet<Vertex>(); BBG.jvertices=new HashSet<Vertex>();
		HashSet<Integer> uniquestamps=new HashSet<Integer>();
  		Vector<Vector<Integer>> detectedDrifts_timestamp_windowNumber=new Vector<Vector<Integer>>(), trueDrifts_timestamp_windowNumber=new Vector<Vector<Integer>>();
  		Vector<Integer> timestamp_winNum;
  		int currentBsize=1;
  		double avgBsize=0;
  		double temp=0;
  		boolean bursty=false;
  		int maxburstSize=0;
  		long drifttime = 0;
  		
  		//The first row in the input file includes the drift timestamps
  		String driftTimestamps=br.readLine();
  		String[] ts=getColumns(driftTimestamps, separator);
  		int numberOfDrifts=ts.length;
  		Vector<Integer> DriftTimestamps=new Vector<Integer> (numberOfDrifts);
  		for (int i = 0; i < numberOfDrifts; i++) {
  			DriftTimestamps.add(new BigDecimal(ts[i]).intValue());
		}
  		
  		while ((sgr = br.readLine()) != null){
  			
  			vertexI_ID=0;vertexJ_ID=0;
  			columns = getColumns(sgr,separator);
  			vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
  			vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
  			timeStamp=new BigDecimal(columns[3]).intValue();	
  			if (uniquestamps.contains(timeStamp)) {
  				currentBsize++;
  				bursty= (currentBsize>avgBsize && currentBsize>maxburstSize);
			}
  			else {
  				temp=(avgBsize*uniquestamps.size())+currentBsize;
  				avgBsize=temp/((uniquestamps.size()+1.0)*1.0);
  				currentBsize=1; 			  				
  			}
  			if (currentBsize>maxburstSize) {
				maxburstSize=currentBsize;
			}
  			
  			
  			BBG=ingest_sgr_to_BBG(vertexI_ID, vertexJ_ID, timeStamp, separator, startVertexIndexinFile, BBG);
  
  			if(DriftTimestamps.contains(t))	{  
  				drifttime=System.currentTimeMillis();
  				timestamp_winNum=new Vector<Integer>(2);
  				timestamp_winNum.add(t);timestamp_winNum.add(windowNum);
  				trueDrifts_timestamp_windowNumber.add(timestamp_winNum);
  				System.out.println("true Drift  >>         t="+t+" windowNumber="+windowNum+" time="+drifttime+"  avgBsize="+avgBsize+" maxBsize="+maxburstSize + "  |V|="+allVerticesCount);
  				
  			}                                                                       
  			if(!uniquestamps.contains(timeStamp) && (uniquestamps.size()+1)%BGwindowSize_numberOfburstsPerWindow==0  && uniquestamps.size()>1 ) {
  				                                         
  				uniquestamps.add(timeStamp);
  				
  				UWGO=createButterflyBasedUWGOprojection(connectButterfliesWithAtleastOneIvertex,BBG,UWGO,butterfly_UGvertex,uniquestamps,butterflyConnectivityPercentile);
  				
  		    	//retire the BBG window
  		    	BBG=new BipartiteGraph();
  		    	BBG.edges=new Vector<IJ_Edge>();
  		  		BBG.ivertices=new HashSet<Vertex>(); BBG.jvertices=new HashSet<Vertex>();
  		  		
  		    	//set initial phases and compute order parameter for this UWGO window
  		  	    UGvertices=UWGO.vertices;
  		    	allVerticesCount=UGvertices.size();
  		    	for (UGVertex u : UGvertices) {
  		    		phase=0;
  		    		neighbors=UWGO.vertexID_Neighbors_HashIndex.get(u.ID);
  		    		if (neighbors!=null) {
  		    			for (UGVertex n : neighbors) {
  	  		    			phase+=n.hashCode();
  	  		    		}
  	  		    		phase=phase%(2*Math.PI);  	  	
					}
  		    		u.setPhase(phase);
  		    	}
  		    	System.gc(); 	
  		    	orderParameter=computeOrderParameter(UWGO, orderParameter);
  		    	setNaturalFrequencies_Gaussian(UWGO);
  			    orderParameter2=kuramato(UWGO, numberOfKuramotoRuns, RungrKutah_h, KuramotoCouplingStrength, orderParameter2, weighted_RungKutah);
  		    	
  		    	
  		    	detectedDrifts_timestamp_windowNumber=detectDriftV1(maxburstSize,drifttime,avgBsize, orderParameter, orderParameter2,detectedDrifts_timestamp_windowNumber, windowNum, t);
  		    										//detectDriftV2(maxburstSize,drifttime,avgBsize, orderParameter, orderParameter2,detectedDrifts_timestamp_windowNumber, windowNum, t);
				
  				
  		    	if (bursty && allVerticesCount>0) {
  		    		remove_m_RandomVertex( (int)(0.1*Math.log(maxburstSize)*allVerticesCount), UWGO);  		    																																																					  		    		
  		    	}
  		    	
  		    	windowNum++;
  			}
  	    	else {
  	    		uniquestamps.add(timeStamp);
  			}
  	    	
  			t++;
  			
  		}
  		orderparameters.add(orderParameter);orderparameters.add(orderParameter2);  		
	}
    
    public static void main(String[] args) throws Exception {
		
        String separator="\t";int linebreaks=0;int startVertexIndexinFile=0;
		int rows=1083633; int t0=833493600;
		boolean connectButterfliesWithAtleastOne_IvertexTrue_or_JvertexFalse=true;
        int BGwindowSize_numberOfburstsPerWindow=1;
        int UGwindowSize_numberOfVerticesPerWindow=50;
        double butterflyConnectivityPercentile=0.25; int numberOfKuramotoRuns=1; double RungrKutah_h=0.01; int KuramotoCouplingStrength=1;boolean weighted_RungKutah=true;
        
        
        double p=0.4;String changePattern="reoccurring";//"gradual";
        String filename="sGrow-"+changePattern+"2 LP_bursty - walkLen=[1,4] - beta=5 - M=10 -synthetic-timesortedAmazon E0=1000 P="+p;
        
        
         for (int i = 1; i <=5; i++) {
        	for (int j = 0; j < 50; j++) {//iterations per graph
        		System.out.print("\n"+changePattern+" "+i+" - #"+j+" - ");
        		
            	
            	run(connectButterfliesWithAtleastOne_IvertexTrue_or_JvertexFalse,startVertexIndexinFile, i+"-"+filename, t0, rows, separator, linebreaks,
                		BGwindowSize_numberOfburstsPerWindow, UGwindowSize_numberOfVerticesPerWindow,butterflyConnectivityPercentile,
               		numberOfKuramotoRuns,RungrKutah_h,KuramotoCouplingStrength,weighted_RungKutah);
                
            	//readFile_getburstSizes(indexes.elementAt(i)+"-"+filename, separator, 1, 3);
            }
		}
              
       
        //String file="detectiondelays";
        //String sep="\t";
        //readFile_getavg(file,sep,0,1);
        //readFile_getavg(file,sep,0,2);
        //readFile_getavg(file,sep,0,3);        
	}
}