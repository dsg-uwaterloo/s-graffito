
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

class IJ_Edge{
	String ID;//I-J since the graph is simple and we don't have multiple edges between two vertices, concatenating the IDs of 2 vertices gives us a unique ID for the edge.
	
	Vertex i;
	Vertex j;
	int timeStamp;
	int FreeVariable;
	
	
	IJ_Edge(Vertex iVertex, Vertex jVertex, int timestamp, int weight) {
		ID=iVertex.ID+"-"+jVertex.ID;
		i=iVertex;//iID=iVertex.ID;
		j=jVertex;//jID=jVertex.ID;
		timeStamp= timestamp;
		FreeVariable=weight;
	}
	
	IJ_Edge(Vertex iVertex, Vertex jVertex, int timestamp) {
		ID=iVertex.ID+"-"+jVertex.ID;
		i=iVertex;
		j=jVertex;
		timeStamp= timestamp;
	}
}

class Vertex{
	int Timestamp;
	int ID;
	int Strength;
	Vertex(int timestamp, int id, int strength){
		Timestamp=timestamp;
		ID=id;
		Strength=strength;
	}
	
	void setID(int id){
		ID=id;
	}
	void setStrength(int s){
		Strength=s;
	}
	void setTimestamp(int timestamp){
		Timestamp=timestamp;
	}
	
}

public class BipartiteGraph{
	Map<Integer,HashSet<Vertex>> JvertexID_INeighbors_HashIndex = new HashMap<Integer,HashSet<Vertex>>();//map each vertex J to its I-type neighbors
	Map<Integer,HashSet<Vertex>> IvertexID_JNeighbors_HashIndex = new HashMap<Integer,HashSet<Vertex>>();//maps each vertex I  to its J-type neighbors //inverted hash index
	
	Map<String,IJ_Edge> edgeIDs_IJedges=new HashMap<String,IJ_Edge>();
	
	Vector<IJ_Edge> edges=new Vector<IJ_Edge>();
	HashSet<Vertex> ivertices=new HashSet<Vertex>(), jvertices=new HashSet<Vertex>();
	int totalWeights=0;
	
	long t0;
	
	Map<String,Integer> edgeIDs_degdiff=new HashMap<String,Integer>();
	
	Map<Integer,Integer> JvertexID_degree_HashIndex = new HashMap<Integer,Integer>();
	Map<Integer,Integer> IvertexID_degree_HashIndex = new HashMap<Integer,Integer>();
	Map<Integer,Integer> iDegree_frequency=new HashMap<Integer,Integer>();;
	Map<Integer,Integer> jDegree_frequency=new HashMap<Integer,Integer>();
	double average_iDegree=0, average_jDegree=0, average_unique_iDegree=0, average_unique_jDegree=0; int maxIdegree=0, maxJdegree=0;
	
	int maxDegreeDifferenceofedges;
	double meanDegreeDifferenceofedges;
	
	Map<Integer, int[]> timeUnit_selfSimilarityBins=new HashMap<Integer, int[]>();
	
	Map<Integer, Integer> degDiffDistribution;
	Map<Integer, Double> degDiff_probDistribution;
	Map<Double, Integer> degDiff_cumulativeDistribution;
	Map<Double, Double> degDiff_cumulativeprobDistribution;
	Map<Double, Double> degDiff_casBasedEntropyOfProbDis;
	ArrayList<Double> degDiffs;
	
	Vector<Integer> spikeIDs, spikeTimestamps, burstCounts, burstLengths;
	Vector<Double> burstRate;
	
	Map<Integer, Integer> burstCountDistribution=new HashMap<Integer, Integer>(), burstLengthDistribution=new HashMap<Integer, Integer>();
	int MaxBurstCount, MaxBurstLength;
	
	int[] interarrivals;
	Map<Integer, Integer> InterArrivalDistribution=new HashMap<Integer, Integer>();
	int MaxInterArrival;
	
	HashSet<Integer> ihubs, jhubs;
	
	void add_JVertex (Vertex jv) {
		
		if (this.JvertexID_INeighbors_HashIndex.containsKey(jv.ID) || jv==null) return;
        this.JvertexID_INeighbors_HashIndex.put(jv.ID, new HashSet<Vertex>());
        this.jvertices.add(jv);
	}
	void add_IVertex (Vertex iv) {
		
		if (this.IvertexID_JNeighbors_HashIndex.containsKey(iv.ID) || iv==null) return;
        this.IvertexID_JNeighbors_HashIndex.put(iv.ID, new HashSet<Vertex>());
        this.ivertices.add(iv);
	}
	
	void add_IJEdge(IJ_Edge e_ij) {
		Vertex i=e_ij.i,j=e_ij.j;
		//self-loop and duplicate-edges are not allowed
		if ( (IvertexID_JNeighbors_HashIndex.containsKey(i.ID) && IvertexID_JNeighbors_HashIndex.get(i.ID).contains(j))){ 
			return;
		
		}
     	 
	    this.add_JVertex(j);
	    if (JvertexID_INeighbors_HashIndex.containsKey(j.ID)) {
	    	JvertexID_INeighbors_HashIndex.get(j.ID).add(i);
		}
	    else{
	    	HashSet<Vertex> ineighbors=new HashSet<Vertex>();ineighbors.add(i);
	    	JvertexID_INeighbors_HashIndex.put(j.ID, ineighbors);
	    }
	   
	    
	    this.add_IVertex(i);
	    if (IvertexID_JNeighbors_HashIndex.containsKey(i.ID)) {
	    	IvertexID_JNeighbors_HashIndex.get(i.ID).add(j);
		}
	    else{
	    	HashSet<Vertex> jneighbors=new HashSet<Vertex>();jneighbors.add(j);
	    	IvertexID_JNeighbors_HashIndex.put(i.ID, jneighbors);
	    }
	    	     
	    edgeIDs_IJedges.put(e_ij.ID, e_ij);	  
	    
	    edges.add(e_ij);
	    
	    i.setStrength( i.Strength + e_ij.FreeVariable);//+1
	    j.setStrength( j.Strength + e_ij.FreeVariable);																								
	    
	    totalWeights+=e_ij.FreeVariable;
	}

	boolean add_IJEdge_trueifNonduplicate (IJ_Edge e_ij) {
		Vertex i=e_ij.i,j=e_ij.j;
		//self-loop and duplicate-edges are not allowed
		if ( (IvertexID_JNeighbors_HashIndex.containsKey(i.ID) && IvertexID_JNeighbors_HashIndex.get(i.ID).contains(j))){ 
			System.out.println(e_ij.ID+" is a duplicate edge not added");
			return false;
		
		}
     	 
	    this.add_JVertex(j);
	    if (JvertexID_INeighbors_HashIndex.containsKey(j.ID)) {
	    	JvertexID_INeighbors_HashIndex.get(j.ID).add(i);
		}
	    else{
	    	HashSet<Vertex> ineighbors=new HashSet<Vertex>();ineighbors.add(i);
	    	JvertexID_INeighbors_HashIndex.put(j.ID, ineighbors);
	    }
	   
	    
	    this.add_IVertex(i);
	    if (IvertexID_JNeighbors_HashIndex.containsKey(i.ID)) {
	    	IvertexID_JNeighbors_HashIndex.get(i.ID).add(j);
		}
	    else{
	    	HashSet<Vertex> jneighbors=new HashSet<Vertex>();jneighbors.add(j);
	    	IvertexID_JNeighbors_HashIndex.put(i.ID, jneighbors);
	    }
	    	     
	    edgeIDs_IJedges.put(e_ij.ID, e_ij);	  
	    
	    edges.add(e_ij);
	    
	    i.setStrength( i.Strength + e_ij.FreeVariable);//+1
	    j.setStrength( j.Strength + e_ij.FreeVariable);
	    
	    totalWeights+=e_ij.FreeVariable;
	    
	    return true;
	}
	
	void remove_IJedge(IJ_Edge e_ij){
		Vertex i=e_ij.i, j=e_ij.j;
		
		
		
		if (this.IvertexID_JNeighbors_HashIndex.get(i.ID)==null || this.IvertexID_JNeighbors_HashIndex.get(i.ID).isEmpty()) {
			return;
		}
		if (this.JvertexID_INeighbors_HashIndex.get(j.ID)==null || this.JvertexID_INeighbors_HashIndex.get(j.ID).isEmpty()) {
			return;
		}
		
		if (!this.IvertexID_JNeighbors_HashIndex.get(i.ID).isEmpty()) {
			this.IvertexID_JNeighbors_HashIndex.get(i.ID).remove(j);
			this.edgeIDs_IJedges.remove(e_ij.ID);
			this.edges.remove(this.edges.indexOf(e_ij));
			
			i.setStrength(i.Strength - e_ij.FreeVariable);//-1 
		    j.setStrength(j.Strength - e_ij.FreeVariable); 																			//System.out.println( " w="+e_ij.FreeVariable+" --> i.s="+i.Strength+" j.s="+j.Strength);
		    totalWeights -= e_ij.FreeVariable; 
		}
		
		
		if (!this.JvertexID_INeighbors_HashIndex.get(j.ID).isEmpty()) {
			this.JvertexID_INeighbors_HashIndex.get(j.ID).remove(i);
		}
		
	}
	
	void remove_IVertex (Vertex iv){
		this.IvertexID_JNeighbors_HashIndex.remove(iv.ID);
		
		Set<Integer> jz=JvertexID_INeighbors_HashIndex.keySet();Iterator iterator = jz.iterator();		
		for (Integer jID : jz) {
			this.JvertexID_INeighbors_HashIndex.get(jID).remove(iv);
		}
		
		this.ivertices.remove(iv);
	}

	void remove_JVertex (Vertex jv){
		this.JvertexID_INeighbors_HashIndex.remove(jv.ID);
		
		Set<Integer> iz=IvertexID_JNeighbors_HashIndex.keySet();Iterator iterator = iz.iterator();		
		for (Integer iID : iz) {
			this.IvertexID_JNeighbors_HashIndex.get(iID).remove(jv);
		}	
		
		this.jvertices.remove(jv);
	}
}

	class UGVertex{
		int ID;
		double Phase;
		double NaturalFrequency;
		
		UGVertex(int id, double phase, double natFreq){
			ID=id;
			Phase=phase;
			NaturalFrequency=natFreq;
		}
	
		void setID(int id){
			ID=id;
		}
		void setPhase(double phase){
			Phase=phase;
		}
		void setFreq(double freq){
			NaturalFrequency=freq;
		}
	}
	class UG_Edge{
		String ID;
		double Weight;
		UGVertex source;
		UGVertex destination;
		
		UG_Edge(UGVertex iVertex, UGVertex jVertex, double weight) {
			ID=iVertex.ID+"-"+jVertex.ID;
			source=iVertex;
			destination=jVertex;
			Weight=weight;
		}		
	}
	class WeightedUnipartiteGraph{
	Map<Integer,HashSet<UGVertex>> vertexID_Neighbors_HashIndex = new HashMap<Integer,HashSet<UGVertex>>();//map each vertex J to its I-type neighbors
	
	Map<String,UG_Edge> edgeIDs_edges=new HashMap<String,UG_Edge>();
	HashSet<UGVertex> vertices;
	
	void add_Vertex (UGVertex v) {
		
		if (v==null) return;
        this.vertexID_Neighbors_HashIndex.putIfAbsent(v.ID, new HashSet<UGVertex>());
        this.vertices.add(v);
	}
	
	void add_Edge(UG_Edge e) {
		UGVertex i=e.source,j=e.destination;
		if ( (vertexID_Neighbors_HashIndex.containsKey(i.ID) && vertexID_Neighbors_HashIndex.get(i.ID).contains(j))){ 
			return;
		
		}
     	 
	    this.add_Vertex(j);
	    if (vertexID_Neighbors_HashIndex.containsKey(j.ID)) {
	    	this.vertexID_Neighbors_HashIndex.get(j.ID).add(i);
		}
	    else{
	    	HashSet<UGVertex> neighbors=new HashSet<UGVertex>();neighbors.add(i);
	    	this.vertexID_Neighbors_HashIndex.put(j.ID, neighbors);
	    }
	   
	    
	    this.add_Vertex(i);
	    if (vertexID_Neighbors_HashIndex.containsKey(i.ID)) {
	    	this.vertexID_Neighbors_HashIndex.get(i.ID).add(j);
		}
	    else{
	    	HashSet<UGVertex> neighbors=new HashSet<UGVertex>();neighbors.add(j);
	    	this.vertexID_Neighbors_HashIndex.put(i.ID, neighbors);
	    }
	    	     
	    this.edgeIDs_edges.put(e.ID, e);	  
	    
	}

	
	
	void remove_UGedge(UG_Edge e){
		UGVertex i=e.source, j=e.destination;
		
		
		
		if (this.vertexID_Neighbors_HashIndex.get(i.ID)==null || this.vertexID_Neighbors_HashIndex.get(i.ID).isEmpty()) {
			return;
		}
		if (this.vertexID_Neighbors_HashIndex.get(j.ID)==null || this.vertexID_Neighbors_HashIndex.get(j.ID).isEmpty()) {
			return;
		}
		
		if (!this.vertexID_Neighbors_HashIndex.get(i.ID).isEmpty()) {
			this.vertexID_Neighbors_HashIndex.get(i.ID).remove(j);
		}
		
		if (!this.vertexID_Neighbors_HashIndex.get(j.ID).isEmpty()) {
			this.vertexID_Neighbors_HashIndex.get(j.ID).remove(i);
		}
		
		this.edgeIDs_edges.remove(e.ID);
	}
	
	void remove_UGVertex (UGVertex v){
		this.vertices.remove(v);
		
		HashSet<UGVertex> neighbors=vertexID_Neighbors_HashIndex.get(v.ID);
		String id;
		if (neighbors!=null&&!neighbors.isEmpty()) {
			for (UGVertex neighbor : neighbors) {
				id=neighbor.ID+"-"+v.ID;
				edgeIDs_edges.remove(id);
				id=v.ID+"-"+neighbor.ID;
				edgeIDs_edges.remove(id);
			}
		}
		this.vertexID_Neighbors_HashIndex.remove(v.ID);
		
		Set<UGVertex> neighborhood;
		Set<Integer> IDs=vertexID_Neighbors_HashIndex.keySet();
		for (int vid : IDs) {
			neighborhood=vertexID_Neighbors_HashIndex.get(vid);
			neighborhood.remove(v);
		}		
	}	
}