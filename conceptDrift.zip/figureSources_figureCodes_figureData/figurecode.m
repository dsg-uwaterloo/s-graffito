%% data
% reocurring v1 - delay1 delay2 milisecond
Data1=dlmread(['v R_21']);
Data2=dlmread('v1 R_22');
Data3=dlmread('v1 R_23');
Data4=dlmread('v1 R_24');
Data5=dlmread('v1 R_25');

% reocurring v2 0.05/0.1 - delay1 delay2 milisecond
% Data1=dlmread(['v2 0.05 R_21']);%dlmread(['v2 0.1 R_21']);
% Data2=dlmread('v2 0.05 R_22');%dlmread('v2 0.1 R_22');
% Data3=dlmread('v2 0.05 R_23');%dlmread('v2 0.1 R_23');
% Data4=dlmread('v2 0.05 R_24');%dlmread('v2 0.1 R_24');
% Data5=dlmread('v2 0.05 R_25');%dlmread('v2 0.1 R_25');

% gradual CD v1 - delay1 delay2 delay3 milisecond
% Data1=dlmread('v1 G_21');
% Data2=dlmread('v1 G_22');
% Data3=dlmread('v1 G_23');
% Data4=dlmread('v1 G_24');
% Data5=dlmread('v1 G_25');

% gradual CD v2-0.05/0.1 - delay1 delay2 delay3 milisecond
% Data1=dlmread('v2 0.05 G_21');%dlmread('v2 0.1 G_21');
% Data2=dlmread('v2 0.05 G_22');%dlmread('v2 0.1 G_22');
% Data3=dlmread('v2 0.05 G_23');%dlmread('v2 0.1 G_23');
% Data4=dlmread('v2 0.05 G_24');%dlmread('v2 0.1 G_24');
% Data5=dlmread('v2 0.05 G_25');%dlmread('v2 0.1 G_25');

%% plots

figure;hold on;
plot(Data1(:,2:end),'DisplayName','data1(:,2:end)');
plot(Data2(:,2:end),'DisplayName','data2(:,2:end)');
plot(Data3(:,2:end),'DisplayName','data3(:,2:end)');
plot(Data4(:,2:end),'DisplayName','data4(:,2:end)');
plot(Data5(:,2:end),'DisplayName','data5(:,2:end)');
hold off;

% ---------------------------Delay1 * 10^{-3}------------------------------
% figure;hold on;
% plot(Data1(:,2)/1000,'o','LineWidth',15,'MarkerSize',50);
% plot(Data2(:,2)/1000,'+','LineWidth',15,'MarkerSize',50);
% plot(Data3(:,2)/1000,'x','LineWidth',15,'MarkerSize',50);
% plot(Data4(:,2)/1000,'d','LineWidth',15,'MarkerSize',50);
% plot(Data5(:,2)/1000,'*','LineWidth',15,'MarkerSize',50);
% hold off;
% xlabel('Execution Instance');
% ylabel('Delay1\times10^{-3}(ms)');set(gca,'FontSize',100, 'FontName', 'Likhan','LineWidth',35);

% ---------------------------Delay2 * 10^{-6}------------------------------
% figure;hold on;
% plot(Data1(:,3)/1000000,'o','LineWidth',15,'MarkerSize',50);
% plot(Data2(:,3)/1000000,'+','LineWidth',15,'MarkerSize',50);
% plot(Data3(:,3)/1000000,'x','LineWidth',15,'MarkerSize',50);
% plot(Data4(:,3)/1000000,'d','LineWidth',15,'MarkerSize',50);
% plot(Data5(:,3)/1000000,'*','LineWidth',15,'MarkerSize',50);
% hold off;
% set(gca,'FontSize',100, 'FontName', 'Likhan','LineWidth',35);
% xlabel('Execution Instance');
% ylabel('Delay2\times10^{-6}(ms)');

% ---------------------------Delay2 * 10^{-5}------------------------------
% figure;hold on;
% plot(Data1(:,3)/100000,'o','LineWidth',15,'MarkerSize',50);
% plot(Data2(:,3)/100000,'+','LineWidth',15,'MarkerSize',50);
% plot(Data3(:,3)/100000,'x','LineWidth',15,'MarkerSize',50);
% plot(Data4(:,3)/100000,'d','LineWidth',15,'MarkerSize',50);
% plot(Data5(:,3)/100000,'*','LineWidth',15,'MarkerSize',50);
% hold off;
% set(gca,'FontSize',100, 'FontName', 'Likhan','LineWidth',35);
% xlabel('Execution Instance');
% ylabel('Delay2\times10^{-5}(ms)');

% ---------------------------Delay3 * 10^{-5}------------------------------
% figure;hold on;
% plot(Data1(:,4)/100000,'o','LineWidth',15,'MarkerSize',50);
% plot(Data2(:,4)/100000,'+','LineWidth',15,'MarkerSize',50);
% plot(Data3(:,4)/100000,'x','LineWidth',15,'MarkerSize',50);
% plot(Data4(:,4)/100000,'d','LineWidth',15,'MarkerSize',50);
% plot(Data5(:,4)/100000,'*','LineWidth',15,'MarkerSize',50);
% hold off;
% set(gca,'FontSize',100, 'FontName', 'Likhan','LineWidth',35);
% xlabel('Execution Instance');
% ylabel('Delay3\times10^{-5}(ms)');