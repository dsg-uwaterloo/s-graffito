clear;clc;

% %each file is a n*1 array
% l1=dlmread('true diversity-timesortedEpinions1m');%('skewness-timesortedEpinions1m');%('PDF entropy-timesortedmovielens1m','\n');%('PDF entropy-timesortedmovielens1m','\n');
% l2=dlmread('true diversity-timesorted-Epinions1m-readstampsBA');%('skewness-timesorted-Epinions1m-readstampsBA');%('PDF entropy-timesorted-ML1m-readstamps-BA','\n');%('PDF entropy-timesorted-randomstampsBAml1m','\n');
% l3=dlmread('true diversity-timesorted-Epinions1m-BA-randomstamps');%('skewness-timesorted-Epinions1m-BA-randomstamps');%('PDF entropy-timesorted-ML1m-randomstamps-BA','\n');
 
% l1=dlmread('number of ihubs in windows of timesorted100k');%('number of old ihubs in windows of timesortedm1m');%('number of old ihubs in windows of timesortedEpinions1m');%('number of jhubs in windows of timesortedEpinions1m');
% l2=dlmread('number of ihubs in windows of timesorted-mlstampsBA');%('number of old ihubs in windows of timesorted-Epinions1m-readstampsBA');%('number of old jhubs in windows of timesorted-Epinions1m-readstampsBA');
% l3=dlmread('number of ihubs in windows of timesorted-randomstampBA');%('number of old ihubs in windows of timesorted-Epinions1m-BA-randomstamps');%('number of old jhubs in windows of timesorted-Epinions1m-BA-randomstamps');
 
% l1=dlmread('number of cliques after adding each edge - timesortedmovielens1m');%('cumulative number of cliques at all steps untill  tl=5000 timesortedEpinions1m')%('cumulative number of cliques at all steps untill  tl=5000 timesorted100k');('number of cliques after adding each edge - timesortedmovielens1m');%timesortedEpinions1m');%timesorted100k');%timesorted100k');% timesortedmovielens1m');
% l2=dlmread('number of cliques after adding each edge - timesorted-ML1m-readstamps-BA');%('cumulative number of cliques at all steps untill  tl=5000 timesorted-Epinions1m-readstampsBA');%('cumulative number of cliques at all steps untill  tl=5000 timesorted-mlstampsBA');%timesorted-Epinions1m-readstampsBA');%timesorted-mlstampsBA');%timesorted-mlstampsBA');%ML1m-readstamps-BA');

% l1=dlmread('avgg i-vertex density  of components - timesorted100k');%movielens1m');
% l2=dlmread('avgg i-vertex density  of components - timesorted-mlstampsBA');%ML1m-readstamps-BA');
 
%l1=dlmread('timesorted-Epinions1m-readstampsBA - jdegree dist - Nj=21455');%('timesorted-randomstampBA - jdegree dist - Nj=982');%('timesorted-ML1m-randomstamps-BA - jdegree dist - Nj=6022');%movielens1m');
% l2=dlmread('timesorted-Epinions1m-readstampsBA - jdegree dist - Nj=21455');%('Epinioins1m-BA-N=22515-m=41-m0=41 - in-degree dist - Nj=21455');%('BA-N=996-m=106-m0=106- in-degree dist - N=996');%('ML1m-BA-N=6107-m=166-m0=166- in-degree dist - N=6107');%ML1m-readstamps-BA');
% 
% figure
%scatter(l1(:,1),l1(:,2), '*','r'); 
%title('i-degree Distribution of bipartite BA graph - (a) Epinions');

% figure
% scatter(l2(:,1),l2(:,2)/21455,'*','b');
% title('in-degree Distribution of unipartite BA graph - (b) MovieLens 100k');

% figure
% scatter(l11(:,1),l11(:,2), 'k', 'filled'); hold on %'r'); 
% scatter(l21(:,1),l21(:,2),'^','m', 'filled')

% scatter(1:size(l1,1),l1(:,1), 'k', 'filled'); hold on     %'r'); 
% scatter(1:size(l2,1),l2(:,1),'^','m');                     %,'b', 'filled');
% x=-114:7000;%1:size(l1,1);hold on 
%y=power(x,1.2)*0.4;%power(x,1)*0.033;   
%scatter(x,y,'filled','MarkerFaceColor',[0.65,0.65,0.65]);
 %z = (x - 2500)/1444;
%y2=46.92*power(z,5)+ 48.16*power(z,4) - 251.4*power(z,3) + 476.4*power(z,2) + 2534*z + 1989;%x*0.22-274;%x*0.08-75.43;%=power(x,1.79)*6.1;   
%scatter(x,y2,'.','b');



%scatter(1:size(l3,1),l3(:,1),'x','g');%'g', 'filled');

%legend({'ML100k','BA+ML100k stamps'},'Location','southeast');%

% legend({'real-world graph','BA+real stamps'},'Location','northwest');
% xlabel('time point t');%('Cumulative number of added edges');%('window number');%
% ylabel('number of cliques');% ('i-vertex density of component(s)');
% title('(c) MovieLens 1m');

% legend({'ML100k','BA+ML100k stamps','BA+random stamps'},'Location','southeast');%({'ML1m','BA+ML1m stamps'},'Location','northwest');


%({'ML100k i-vertex density','BA+ML100k stamps ivertex density', 'ML100k j-vertex density','BA+ML100k stamps j-vertex density'},'Location','southwest');
%({'Epinions1m','BA+Epinions1m stamps','BA+random stamps'},'Location','northeast');
%({'ML100k','BA+ML100k stamps'},'Location','northwest');
%({'ML1m','BA+ML1m stamps'},'Location','northwest');


%({'ML1m','BA+ML1m stamps','BA+random stamps'},'Location','southeast');%({'ML100k','BA+ML100k stamps','BA+random stamps'},'Location','southeast')
%({'Epinions1m Y-scale=100','BA+Epinions1m stamps'},'Location','northwest');%,'BA+random stamps'
%({'ML100k','BA+ML100k stamps','BA+random stamps'},'Location','southeast');%
% 
% xlabel('Cumulative number of added edges');%('time point t');%('window number');%
% ylabel('j-vertex density of component(s)');%('number of cliques')%('number of i-hubs');%('true diversity');%('skewness');

% hold off  


% figure;l=dlmread('number of components - timesorted-mlstampsBA'); scatter(l(:,1),l(:,2),'^', 'm');title('BA+ML100k stamps');xlabel('number of removed i-vertices');ylabel('N_{CC}');
% figure;l=dlmread('number of components - timesorted100k'); scatter(l(:,1),l(:,2),'k', 'filled');title('MovieLens100k');xlabel('number of removed i-vertices');ylabel('N_{CC}');
% 
% figure;l=dlmread('number of components - timesorted-ML1m-readstamps-BA'); scatter(l(:,1),l(:,2),'^', 'm');title('BA+MovieLens1mstamps');xlabel('number of removed i-vertices');ylabel('N_{CC}');
% figure;l=dlmread('number of components - timesortedmovielens1m'); scatter(l(:,1),l(:,2),'k', 'filled');title('MovieLens1m');xlabel('number of removed i-vertices');ylabel('N_{CC}');
figure;
l1=dlmread('number of old jhubs in windows of timesorted-ml10m');
scatter(1:size(l1,1),l1(:,1), 'k', 'filled');
xlabel('window number','fontweight','bold','fontsize',14);
ylabel('number of old j-hubs','fontweight','bold','fontsize',14);
title('(f) MovieLens10m','fontweight','bold','fontsize',14);