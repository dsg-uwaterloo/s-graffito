
% %%MAPE for long adaptive windows
% %x=approximation exponent
% x=1:0.005:1.05;
% x=transpose(x);
% xmat=ones(11,5);
% for i=1:1:5
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=0.006:0.001:0.01;
% ymat=ones(11,5);
% for i=1:1:11
% ymat(i,:)=y;
% end
% %z=MAPE
% z=dlmread('z');
% 
% contour(xmat,ymat,z,'ShowText','on');%plot3(xmat,ymat,z);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=fw',ymat);

%%MAPE for all adaptive windows
%x=approximation exponent
% x=0.9:0.005:1.05;
% x=transpose(x);
% xmat=ones(31,8);
% for i=1:1:8
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=0.01:0.04:0.29;%0.001:0.001:0.01;
% ymat=ones(31,8);
% for i=1:1:31
% ymat(i,:)=y;
% end
% %z=MAPE
% z=dlmread('z2');
% 
% figure;
% contour(xmat(:,2:8),ymat(:,2:8),z(:,2:8),'ShowText','on');%(xmat(:,3:10),ymat(:,3:10),z(:,3:10),'ShowText','on');
% %plot3(xmat,ymat,z);
% dlmwrite('xallall=exponents',xmat);
% dlmwrite('yallall=fw',ymat);

% %%MAPE for short adaptive windows
% %x=approximation exponent
% x=0.9:0.005:1;
% x=transpose(x);
% xmat=ones(21,4);
% for i=1:1:4
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=0.002:0.001:0.005;
% ymat=ones(21,4);
% for i=1:1:21
% ymat(i,:)=y;
% end
% %z=MAPE
% z=dlmread('zshort');
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');
% %plot3(xmat,ymat,z);
% dlmwrite('xshort=exponents',xmat);
% dlmwrite('yshort=fw',ymat);
% 
%%ML100k
%z=MAPE
z=dlmread('z-ml100k');
z2=z(18:36,1:21);

x=1.36:0.005:1.45;
x=transpose(x);
xmat=ones(19,21);
for i=1:1:21
xmat(:,i)=x;
end
%y=window length cutoff percentage
y=0.0095:0.0005:0.0195;
ymat=ones(19,21);
for i=1:1:19
ymat(i,:)=y;
end
% % 
% 
% figure;
% contour(xmat,ymat,z2,'ShowText','on');%(xmat(:,3:10),ymat(:,3:10),z(:,3:10),'ShowText','on');
% %plot3(xmat,ymat,z);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);


% %%En Wiki
% %z=MAPE
% z=dlmread('zenwiki');
% 
% x=0.48:0.005:0.53;
% x=transpose(x);
% xmat=ones(11,17);
% for i=1:1:17
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=220:5:300
% ymat=ones(11,17);
% for i=1:1:11
% ymat(i,:)=y;
% end
% 
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');%(xmat(:,3:10),ymat(:,3:10),z(:,3:10),'ShowText','on');
% %plot3(xmat,ymat,z);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);

% %%En Wiki
% %z=MAPE
% z=dlmread('zbaepinions');
% 
% x=0.53:0.01:0.85;
% x=transpose(x);
% xmat=ones(33,9);
% for i=1:1:9
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=58:5:98
% ymat=ones(33,9);
% for i=1:1:33
% ymat(i,:)=y;
% end
% 
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');%(xmat(:,3:10),ymat(:,3:10),z(:,3:10),'ShowText','on');
% %plot3(xmat,ymat,z);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);

% %%baml1m
% %z=MAPE
% z=dlmread('zbaml1m');
% 
% x=0.95:0.001:0.97;
% x=transpose(x);
% xmat=ones(21,14);
% for i=1:1:14
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=240:20:500
% ymat=ones(21,14);
% for i=1:1:21
% ymat(i,:)=y;
% end
% 
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');%(xmat(:,3:10),ymat(:,3:10),z(:,3:10),'ShowText','on');
% %plot3(xmat,ymat,z);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);

% %%baml1m
% %z=MAPE
% z=dlmread('zml10m');
% 
% x=1.38:0.001:1.41;
% x=transpose(x);
% xmat=ones(31,9);
% for i=1:1:9
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=50:5:90
% ymat=ones(31,9);
% for i=1:1:31
% ymat(i,:)=y;
% end
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');%(xmat(:,3:10),ymat(:,3:10),z(:,3:10),'ShowText','on');
% %plot3(xmat,ymat,z);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);


%%frwiki 
%rows=0.821:0.001:0.83
%cols=185:5:260
 
%  
% %z=MAPE
% z=dlmread('zfrwiki');%('zfrwiki');
% 
% x=0.84:0.005:0.96;
% x=transpose(x);
% xmat=ones(25,31);
% for i=1:1:31
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=200:10:500
% ymat=ones(25,31);
% for i=1:1:25
% ymat(i,:)=y;
% end
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');%(xmat(:,3:10),ymat(:,3:10),z(:,3:10),'ShowText','on');
% %plot3(xmat,ymat,z);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);

% z=dlmread('z3-epinions');%('zfrwiki');
% figure;
% x=0.96:0.001:1.04;
% x=transpose(x);
% xmat=ones(81,18);
% for i=1:1:18
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=12:2:46
% ymat=ones(81,18);
% for i=1:1:81
% ymat(i,:)=y;
% end
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');%(xmat(:,3:10),ymat(:,3:10),z(:,3:10),'ShowText','on');
% %plot3(xmat,ymat,z);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);

% 
% %%ML100k
% %z=MAPE
% z=dlmread('z-ml1m');


% x=1.2:0.005:1.4;
% x=transpose(x);
% xmat=ones(41,19);
% for i=1:1:19
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=150:50:1050;
% ymat=ones(41,19);
% for i=1:1:41
% ymat(i,:)=y;
% end
% % 



% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');%(xmat(:,3:10),ymat(:,3:10),z(:,3:10),'ShowText','on');
% %plot3(xmat,ymat,z);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);



%%optimized sGrapp

% % %z=MAPE
% z=dlmread('optimized |E|=tl - exponent(tl) - windowPercentage - MAPE - timesortedEpinions1m');
% 
% x=0.96:0.001:1.04; x=transpose(x); xmat=ones(81,18); for i=1:1:18
% xmat(:,i)=x; end %y=window length cutoff percentage y=12:2:46
% ymat=ones(81,18); for i=1:1:81 ymat(i,:)=y; end
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');%(xmat(:,3:10),ymat(:,3:10),z(:,3:10),'ShowText','on');
% %plot3(xmat,ymat,z);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);


% %z=MAPE
% z=dlmread('2optimized |E|=tl - exponent(tl) - windowPercentage - MAPE - timesorted-editfrwiki');
% 
% x=0.84:0.001:0.96;
% x=transpose(x);
% xmat=ones(121,31);
% for i=1:1:31
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=200:10:500;
% ymat=ones(121,31);
% for i=1:1:121
% ymat(i,:)=y;
% end
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');
% set(gca,'FontSize',80);
% xlabel('\alpha','fontsize',80); 
% ylabel('N_t^W','fontsize',80);
% title('Edit-FrWiki', 'fontsize',80);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);

% z=dlmread('75semisupervised- |E|=tl - exponent(tl) - windowPercentage - MAPE - timesorted-ml10m');%('semisupervised-optimized |E|=tl - exponent(tl) - windowPercentage - MAPE - timesorted-ml10m');
% 
% x=1.38:0.001:1.41;
% x=transpose(x);
% xmat=ones(31,9);
% for i=1:1:9
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=50:5:90;
% ymat=ones(31,9);
% for i=1:1:31
% ymat(i,:)=y;
% end
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');
% set(gca,'FontSize',80);
% xlabel('\alpha','fontsize',80); 
% ylabel('N_t^W','fontsize',80);
% title('Edit-FrWiki', 'fontsize',80);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);

z=dlmread('75semisupervised- |E|=tl - exponent(tl) - windowPercentage - MAPE - timesortedEpinions1m');%('supervised-2optimized |E|=tl - exponent(tl) - windowPercentage - MAPE - timesortedEpinions1m');

x=0.96:0.001:1.04;
x=transpose(x);
xmat=ones(81,18);
for i=1:1:18
xmat(:,i)=x;
end
%y=window length cutoff percentage
y=12:2:46;
ymat=ones(81,18);
for i=1:1:81
ymat(i,:)=y;
end

figure;
contour(xmat,ymat,z,'ShowText','on');
set(gca,'FontSize',80);
xlabel('\alpha','fontsize',95); 
ylabel('N_t^W','fontsize',95);
title('Epinions', 'fontsize',95);
dlmwrite('x=exponents',xmat);
dlmwrite('y=winLen',ymat);
% 
% z=dlmread('bi- |E|=tl - exponent(tl) - windowPercentage - MAPE - timesortedmovielens1m');%('supervised-2optimized |E|=tl - exponent(tl) - windowPercentage - MAPE - timesorted100k');
% x=1.2:0.001:1.4;
% x=transpose(x);
% xmat=ones(201,19);
% for i=1:1:19
% xmat(:,i)=x;
% end
% y=window length cutoff percentage
% y=150:50:1050;
% ymat=ones(201,19);
% for i=1:1:201
% ymat(i,:)=y;
% end
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');
% set(gca,'FontSize',80);
% xlabel('\alpha','fontsize',95); 
% ylabel('N_t^W','fontsize',95);
% title('MovieLens 100k', 'fontsize',95);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);


% z=dlmread('75semisupervised- |E|=tl - exponent(tl) - windowPercentage - MAPE - timesorted100k');%('supervised-2optimized |E|=tl - exponent(tl) - windowPercentage - MAPE - timesorted100k');
% x=1.36:0.001:1.45;
% x=transpose(x);
% xmat=ones(91,11);
% for i=1:1:11
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=469:49:961;
% ymat=ones(91,11);
% for i=1:1:91
% ymat(i,:)=y;
% end
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');
% set(gca,'FontSize',80);
% xlabel('\alpha','fontsize',95); 
% ylabel('N_t^W','fontsize',95);
% title('MovieLens 100k', 'fontsize',95);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);



% z=dlmread('75semisupervised- |E|=tl - exponent(tl) - windowPercentage - MAPE - timesortedmovielens1m');%('supervised-2optimized |E|=tl - exponent(tl) - windowPercentage - MAPE - timesortedmovielens1m');
% x=1.2:0.001:1.4;
% x=transpose(x);
% xmat=ones(201,19);
% for i=1:1:19
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=150:50:1050;
% ymat=ones(201,19);
% for i=1:1:201
% ymat(i,:)=y;
% end
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');
% set(gca,'FontSize',80);
% xlabel('\alpha','fontsize',95); 
% ylabel('N_t^W','fontsize',95);
% title('MovieLens 1m', 'fontsize',95);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);



% z=dlmread('75semisupervised- |E|=tl - exponent(tl) - windowPercentage - MAPE - timesorted-Enwiki');
% x=0.48:0.001:0.53;
% x=transpose(x);
% xmat=ones(51,9);
% for i=1:1:9
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=220:10:300;
% ymat=ones(51,9);
% for i=1:1:51
% ymat(i,:)=y;
% end
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');
% set(gca,'FontSize',80);
% xlabel('\alpha','fontsize',95); 
% ylabel('N_t^W','fontsize',95);
% title('Edit-EnWiki', 'fontsize',95);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);


% z=dlmread('75semisupervised- |E|=tl - exponent(tl) - windowPercentage - MAPE - timesorted-editfrwiki');
% x=0.84:0.001:0.96;
% x=transpose(x);
% xmat=ones(121,31);
% for i=1:1:31
% xmat(:,i)=x;
% end
% %y=window length cutoff percentage
% y=200:10:500;
% ymat=ones(121,31);
% for i=1:1:121
% ymat(i,:)=y;
% end
% 
% figure;
% contour(xmat,ymat,z,'ShowText','on');
% set(gca,'FontSize',80);
% xlabel('\alpha','fontsize',95); 
% ylabel('N_t^W','fontsize',95);
% title('Edit-FrWiki', 'fontsize',95);
% dlmwrite('x=exponents',xmat);
% dlmwrite('y=winLen',ymat);

