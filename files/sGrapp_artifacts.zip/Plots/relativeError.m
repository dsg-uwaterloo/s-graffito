
%%relative error over windows
e0=dlmread('binary- timestep-realtive error - timesortedEpinions1m exponent=1.023 Ntw=44');
e=e0(:,2);
figure
hold on
for i=1:size(e)
   if e(i)>=0
       stem(i,e(i),'r','MarkerSize',80,'Marker','^','LineWidth', 2);
   end
   if e(i)<0
       stem(i,e(i),'b','MarkerSize',80,'Marker','v','LineWidth', 2)
   end
end
xlabel('window ID','fontweight','bold','fontsize',95); %('window number');
ylabel('Relative Error','fontweight','bold','fontsize',95);
title('MovieLens10m - \alpha=1.023 N_t^W=44 MAPE=0.024','fontweight','bold','fontsize',95);
set(gca,'FontSize',80)
hold off