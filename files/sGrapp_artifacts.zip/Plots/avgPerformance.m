clc;
% l=dlmread('avg window times (ns) - window cutoff=250.0*134075025 - exponent=0.515 - timesorted-Enwiki');
% figure;
% plot(1:size(l,1),l(:,1)/power(10,9),'Marker','o','MarkerSize',80,'linewidth',10);
% xlabel('window ID','fontweight','bold','fontsize',95);
% ylabel('Average window latency','fontweight','bold','fontsize',95);
% % title('Edit-EnWiki - \alpha=0.515 N_t^W=250','fontweight','bold','fontsize',95);
% set(gca,'FontSize',95);


% l=dlmread('avg window throughputs (edge per s) - window cutoff=250.0*134075025 - exponent=0.515 - timesorted-Enwiki');
% figure;
% plot(1:size(l,1),l(:,1),'Marker','o','MarkerSize',80,'linewidth',10);
% xlabel('window ID','fontweight','bold','fontsize',95);
% ylabel('Average window throughput','fontweight','bold','fontsize',95);
% title('Edit-EnWiki - \alpha=0.515 N_t^W=250','bold','fontsize',95);
% set(gca,'FontSize',95);


% l=dlmread('avg total throughput (edge per s) - window cutoff=250.0*134075025 - exponent=0.515 - timesorted-Enwiki');
% figure;
% plot(1:size(l,1),l(:,1),'Marker','o','MarkerSize',80,'linewidth',10);
% xlabel('window ID','fontweight','bold','fontsize',90);
% ylabel('Average throughput','fontweight','bold','fontsize',90);
% title('Edit-EnWiki - \alpha=0.515 N_t^W=250','fontweight','bold','fontsize',90);
% set(gca,'FontSize',95);

%%creat min and max mape bars
% minMAPE=[0.022 0.022 0.027 0.027 0.027 0.024;
%     0.0097 0.0099 0.0099 0.0099 0.0099 0.013;
%     0.040 0.040 0.048 0.062 0.0509 0.044;
%     0.143 0.187 0.151 0.1697 0.161 0.145;
%     0.681 0.376 0.1018 0.105 0.0977 0.616;
%     0.2016 0.2358 0.01385 0.1342 0.137 0.111];
% figure;bar(round(minMAPE,3));
% 
% 
% maxMAPE=[0.7 0.49 0.45 0.45 0.45 0.65;
% 0.7 0.58 0.45 0.4 0.4 0.8;
% 3.5 2.19 1.2 1.05 1.5 5.5;
% 0.6 0.36 0.3 0.25 0.25 0.7; 
% 0.715 0.52 0.24 0.16 0.15 0.8
% 2 0.45 0.3 0.26 0.26 5
% ];
% figure;bar(round(maxMAPE,3));

%fH = gcf; colormap(jet(4));applyhatch_plusC(fH, '\-x.', 'rkbk');


%% Create patterned bars
%fH = gcf; colormap(jet(4));
%h = bar(round(b,2));
%legend('Apple', 'Orange', 'Banana', 'Melon', 'Location', 'NorthOutside');

% % Apply Brandon's function
% tH = title('Brandon''s applyhatch');
% applyhatch_pluscolor(fH, '\-x.', 0, [1 0 1 0], jet(4));

% Apply Brian's function
%set(tH, 'String', 'Brian''s applyhatch');
%applyhatch_plusC(fH, '\-x.', 'rkbk');

% %% create mape histogram
% %z=dlmread('z-ml100k');m=z(18:36,1:21);
% m=dlmread('z');%('bi- |E|=tl - exponent(tl) - windowPercentage - MAPE - timesortedmovielens1m');%('bi- |E|=tl - exponent(tl) - windowPercentage - MAPE - timesorted100k');%('bi- |E|=tl - exponent(tl) - windowPercentage - MAPE - timesortedEpinions1m');
% figure; cdf=histogram(m, 'Normalization', 'cdf','linewidth',10, 'BinWidth', 0.05);
% %sfigure; prob=histogram(m, 'Normalization', 'probability','linewidth',10, 'BinWidth', 0.05);
% CDFvals=cdf.Values
% Freqvals=cdf.BinCounts/sum(cdf.BinCounts)
% set(gca,'FontSize',55);
% xlabel('MAPE','fontweight','bold','fontsize',55);
% ylabel('Probability','fontweight','bold','fontsize',55);
% title('Epinions','fontweight','bold','fontsize',50);

%%CDF(mape<0.15 [0.1,0.15])  
c1=[0.2957 0.6713 0.5796 0.5837 0.5844;
0.4912 0.4885 0.6094 0.6833 0.6993;
0.1617 0.1686 0.1804 0.3994 0.3543;
0.03226 0.09319 0 0 0;
0 0 0.3203 0.7974 0.9931;
0 0 0.0104 0.2263 0.15];
figure;bar(c1);title('Probability of MAPE\leq 0.15');

%%CDF(mape<=0.2[0.15,0.2])
c2=[0.4211 0.7853 0.7936 0.7956 0.7963;
0.6416 0.6364 0.7463 0.8012 0.8132;
0.2272 0.2474 0.3619 0.4522 0.4647;
0.4122 0.5842 0.405 0.4946 0.5484;
0 0 0.9455 1 1;
0 0 0.1645 0.8427 0.8208];
figure;createfigurebar(c2);%title('Probability of MAPE\leq 0.2');


minMAPE=[0.022 0.022 0.027 0.027 0.027;
    0.0097 0.0099 0.0099 0.0099 0.0099;
    0.040 0.040 0.048 0.062 0.0509;
    0.143 0.187 0.151 0.1697 0.161;
    0.681 0.376 0.1018 0.105 0.0977;
    0.2016 0.2358 0.1385 0.1342 0.137];

maxMAPE=[0.7 0.49 0.45 0.45 0.45;
0.7 0.58 0.45 0.4 0.4;
3.5 2.19 1.2 1.05 1.5;
0.6 0.36 0.3 0.25 0.25; 
0.715 0.52 0.24 0.16 0.15;
2 0.45 0.3 0.26 0.26];

%%comparison with Fleet
mape=[0.058 13.789 0.336  0.022 0.022 0.028 0.028 0.028;
      0.959 2.287 0.399 0.009 0.009 0.009 0.009 0.009;
    0.085 5.261 0.047 0.043 0.043 0.053 0.067  0.055;
    0.156 0.839 0.086 0.143 0.247 0.162 0.180 0.170;
    2.689 467.747 178.702  0.684 0.494 0.161 0.141 0.137;
    1.575 49.165 57.563 0.201 0.313 0.217 0.134 0.137];
figure;createfigurebar(mape);

memory=[172639808 43617296 27452976 167772376 167772416 167772496 167772536 167772312;
    218853904 7927320 15854800 482346480 482345296 482345288 482346616 482345976;
    210102248 14534464 29067984 246339872 266806680 283292320 282899216 283784368;
    90607576 14533872 33031176 190135928 186993616 187337688 188910688 189352976;
    149944640 48953744 34205544 104857768 125829184 125830304 125829384 125829184;
    99213296 50207064 26616688 125829360 146800792 146804896 146800848 146801272];
figure;createfigurebar(memory);

thru=[;
    ;
    ;
    ;
    ;
    ;
    ];
