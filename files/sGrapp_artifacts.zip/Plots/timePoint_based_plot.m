% l=dlmread('avg window times (ns) - window cutoff=360.0*39190059 - exponent=0.9 - timesorted-editfrwiki');%('total throughput (edge per s) - window cutoff=295.0*49282 - exponent=1.435 - timesorted100k');
% plot(1:size(l,1),l(:,1)/power(10,9),'MarkerSize',15,'Marker','o','LineStyle','--');%,'k', 'filled');%'^', 'm');/power(10,3)
% xlabel('window number','fontweight','bold','fontsize',40); %('window number');
% ylabel('Average window latency (s)','fontweight','bold','fontsize',40);
% title('Edit-EnWiki - \alpha=0.9 N_t^W=360','fontweight','bold','fontsize',40);%('MovieLens100k - \alpha=1.435 N_t^W=295','fontweight','bold','fontsize',28);
% clear;clc;
% figure

%each row in the file is a data point (x,y)

% l1=dlmread('normalized fracyion of ihubs with deg>41-timesortedEpinions1m');%('normalized fracyion of ihubs with deg>41-timesortedEpinions1m');%('normalized fracyion of ihubs with deg>166-timesortedmovielens1m'); %('normalized fracyion of ihubs with deg>106-timesorted100k');
% l2=dlmread('normalized fracyion of ihubs with deg>41-timesorted-Epinions1m-readstampsBA');%('normalized fracyion of ihubs with deg>41-timesorted-Epinions1m-readstampsBA');%('normalized fracyion of ihubs with deg>164-timesorted-ML1m-readstamps-BA'); %('normalized fracyion of ihubs with deg>100-timesorted-mlstampsBA');
% l3=dlmread('normalized fracyion of ihubs with deg>41-timesorted-Epinions1m-BA-randomstamps');%('normalized fracyion of ihubs with deg>164-timesorted-ML1m-randomstamps-BA');%('normalized fracyion of ihubs with deg>100-timesorted-randomstampBA');

% l1=dlmread('normalized fracyion of jhubs with deg>41-timesortedEpinions1m');%('normalized fracyion of jhubs with deg>106-timesorted100k');%('normalized fracyion of jhubs with deg>166-timesortedmovielens1m'); 
% l2=dlmread('normalized fracyion of jhubs with deg>41-timesorted-Epinions1m-readstampsBA');%('normalized fracyion of jhubs with deg>100-timesorted-mlstampsBA');%('normalized fracyion of jhubs with deg>164-timesorted-ML1m-readstamps-BA');
% l3=dlmread('normalized fracyion of jhubs with deg>41-timesorted-Epinions1m-BA-randomstamps');%('normalized fracyion of jhubs with deg>100-timesorted-randomstampBA');%('normalized fracyion of ihubs with deg>164-timesorted-ML1m-randomstamps-BA');
% 
% l1=dlmread('Number of ihubs with deg>41-timesortedEpinions1m');%('Number of ihubs with deg>166-timesortedmovielens1m');%('Number of ihubs with deg>106-timesorted100k');
% l2=dlmread('Number of ihubs with deg>41-timesorted-Epinions1m-readstampsBA');%('Number of ihubs with deg>164-timesorted-ML1m-readstamps-BA');%('Number of ihubs with deg>100-timesorted-mlstampsBA');
% l3=dlmread('Number of ihubs with deg>41-timesorted-Epinions1m-BA-randomstamps');%('Number of ihubs with deg>164-timesorted-ML1m-randomstamps-BA');%('Number of ihubs with deg>100-timesorted-randomstampBA');

% l1=dlmread('Number of jhubs with deg>3-timesortedEpinions1m');%('Number of jhubs with deg>270-timesortedmovielens1m');%('Number of jhubs with deg>59-timesorted100k');
% l2=dlmread('Number of jhubs with deg>43-timesorted-Epinions1m-readstampsBA');%('Number of jhubs with deg>166-timesorted-ML1m-readstamps-BA');%('Number of jhubs with deg>100-timesorted-mlstampsBA');
% l3=dlmread('Number of jhubs with deg>43-timesorted-Epinions1m-BA-randomstamps');%('Number of jhubs with deg>166-timesorted-ML1m-randomstamps-BA');%('Number of jhubs with deg>100-timesorted-randomstampBA');


% 
% scatter(l1(:,1),l1(:,2),'k', 'filled');  hold on
% scatter(l2(:,1),l2(:,2),'^','m');
% scatter(l3(:,1),l3(:,2),'x','g');
% 
% legend({'Epinions1m','BA+Epinions1m stamps','BA+random stamps'},'Location','northeast');%({'ML1m','BA+ML1m stamps','BA+random stamps'},'Location','northeast');%({'ML100k','BA+ML100k stamps','BA+random stamps'},'Location','northeast'); 
% 
% xlabel('time point'); %('window number');
% ylabel('normalized i-hubs degree');
 




%%relative error over windows
% e0=dlmread('timestep-realtive error - timesorted-editfrwiki exponent=0.927 Ntw=500 mape=0.137');
% e=e0(:,2);
% figure
% hold on
% for i=1:size(e)
%    if e(i)>=0
%        stem(i,e(i),'r','MarkerSize',80,'Marker','^','LineWidth', 2);
%    end
%    if e(i)<0
%        stem(i,e(i),'b','MarkerSize',80,'Marker','v','LineWidth', 2)
%    end
% end
% xlabel('window ID','fontweight','bold','fontsize',95); %('window number');
% ylabel('Relative Error','fontweight','bold','fontsize',95);
% title('Edit-FrWki - \alpha=0.927 N_t^W=500 MAPE=0.137','fontweight','bold','fontsize',95);
% set(gca,'FontSize',80)
% hold off

%%temporal dist
%l=dlmread('dist of timestamps -timesorted-Enwiki');
%scatter(l(:,1),l(:,2),'k','filled');
%xlabel('Timestamps','fontweight','bold','fontsize',18, 'FontName', 'Times New Roman'); %('window number');
%ylabel('Frequency','fontweight','bold','fontsize',18, 'FontName', 'Times New Roman');
%title('Edit-EnWki','fontweight','bold','fontsize',18, 'FontName', 'Times New Roman');
%set(gca,'FontSize',18, 'FontName', 'Times New Roman', 'YScale', 'log');