
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Vector;
import java.util.function.Predicate;
import java.util.stream.*;

import javax.print.attribute.standard.Finishings;

import org.omg.CORBA.portable.ApplicationException;

import ptolemy.plot.Plot;
import ptolemy.plot.PlotApplication;


public class sGrappsuit {
	 
	static boolean[] jV,iV;
	
	private static String[] getColumns(String line, String separator) { //enhance this by extracting feature vectors from the data set
        return line.split(separator);//("/t");//
    }
	
	public static BipartiteGraph readFile_createBipartiteGraph(int startVertexIndexinFile, String fileName, int linebreaks, int stampColumn, int firstTimestamp, int rows, boolean save_intervals_spikeNumbers_spikeTimes,String separator) throws NumberFormatException, IOException{
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			long startTime=System.currentTimeMillis();
			System.out.println("\nreadFile_createBipartiteGraph() started at "+dateFormat.format(cal.getTime())+" , "+startTime+" millisec");
			
			BipartiteGraph BG=new BipartiteGraph();
			BG.t0=firstTimestamp;
			BG.ivertices=new HashSet<Vertex>(); BG.jvertices=new HashSet<Vertex>();
			
			FileInputStream fstream = new FileInputStream(fileName);
	    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
	    	
			int vertexI_ID,vertexJ_ID,timeStamp;
			IJ_Edge e_ij;
			String line;
			String[] columns;
			
			BG.interarrivals=new int[rows];
			
			int previousTimestamp=firstTimestamp;
			int c=0;
			//BG.spikeIDs=new Vector<Integer>();
			//BG.spikeTimestamps=new Vector<Integer>();
			
			BG.edges=new Vector<IJ_Edge>(rows);
			
			int t=0;
			
			Map<Integer,Integer> i_ID_index=new HashMap<Integer,Integer>();
			Map<Integer,Integer> j_ID_index=new HashMap<Integer,Integer>();
			int temp_i_index, temp_j_index;
			Vertex iv,jv;
			
			int inter_arrival=0;
			
			int maxtemp=0;
			if (linebreaks!=0) {
				for (int i = 0; i < linebreaks; i++) {
					br.readLine();
				}
			}
			while (t<rows&&(line = br.readLine()) != null){
				t++;
				
				vertexI_ID=0;vertexJ_ID=0;e_ij=null;
				columns = getColumns(line,separator);
				vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
				vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
				timeStamp=new BigDecimal(columns[stampColumn]).intValue();//Integer.parseInt(columns[stampColumn]);	
				
				inter_arrival=0;
				
				if (save_intervals_spikeNumbers_spikeTimes) {
					inter_arrival=timeStamp-previousTimestamp;
					BG.interarrivals[c]=inter_arrival;
					
					//System.out.println("inter-arrival of "+vertexI_ID+"-"+vertexJ_ID+" : "+BG.intervals[c]);
					/*
					if (BG.interarrivals[c]>150) {//System.out.println("---> spike seen at arrival number "+c+" at timestamp "+timeStamp);
						BG.spikeIDs.add(c);
						BG.spikeTimestamps.add(timeStamp);
					}
					*/
					previousTimestamp=timeStamp;
					c++;				
				}
				
				if (i_ID_index.containsKey(vertexI_ID)) {//existing i-vertex
					temp_i_index=i_ID_index.get(vertexI_ID);
					
					if (j_ID_index.containsKey(vertexJ_ID)) {//existing j-vertex
						temp_j_index=j_ID_index.get(vertexJ_ID);
					}
					else {//new j-vertex
						temp_j_index=j_ID_index.keySet().size();
						j_ID_index.put(vertexJ_ID,temp_j_index);
						
						jv=new Vertex(timeStamp, temp_j_index);
						BG.jvertices.add(jv);
					}	
				}//end if existing i-vertex
				
				else{//new i-vertex
					temp_i_index=i_ID_index.keySet().size();
					i_ID_index.put(vertexI_ID,temp_i_index);
					
					iv=new Vertex(timeStamp, temp_i_index);
					BG.ivertices.add(iv);
					
					if (j_ID_index.containsKey(vertexJ_ID)) {//existing j-vertex
						temp_j_index=j_ID_index.get(vertexJ_ID);
					}
					else {//new j-vertex
						temp_j_index=j_ID_index.keySet().size();
						j_ID_index.put(vertexJ_ID,temp_j_index);
						
						jv=new Vertex(timeStamp, temp_j_index);
						BG.jvertices.add(jv);
					}
				}
				
				e_ij=new IJ_Edge(temp_i_index,temp_j_index,timeStamp, inter_arrival);
				BG.add_IJEdge(e_ij);
				
				if (maxtemp<inter_arrival) {
					maxtemp=inter_arrival;
				}
				
				BG.edges.add(e_ij);
				
			}
			//BG.MaxInterArrival=maxtemp;
			System.out.println("BG graph created with "+BG.edgeIDs_IJedges.size()+" edges and "+BG.IvertexID_JNeighborIDs_HashIndex.size()+" i-vertices and "+BG.JvertexID_INeighborIDs_HashIndex.size()+" j-vertices" +" ---> max iunter-arrival="+BG.MaxInterArrival+"="+maxtemp);
			br.close();
			
			long finishTime=System.currentTimeMillis();
			long duration=finishTime-startTime;
			cal = Calendar.getInstance();
			System.out.println("\nreadFile_createBipartiteGraph() finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" millisec, duration="+duration+" millisec" );
			
			return BG;	
		}
	
	
	//dist of inter-arrivals - pearson correlation
    private static Map<Double, Integer> increaseValueInMap(double key, Map<Double, Integer> map){
		int val;
		if (map.containsKey(key)) {
			val=map.get(key);
			map.put(key, val+1);
		}
		else{
			map.put(key, 1);
		}
		return map;
	}
    private static void writeMap_doubleKeys(Map<Double, Integer> map, String fileName){
		PrintWriter w = null;
    	
    	try {
    		w=new PrintWriter(fileName);    
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		Set<Double> keys=map.keySet();
		for (Double key : keys) {
			w.append(key+" "+map.get(key)+"\r\n");
		}
		w.close();
	}
    private static void writeArrayList(ArrayList<Integer> a, String fileName){
		PrintWriter w = null;
    	
    	try {
    		w=new PrintWriter(fileName);     
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		for (Integer i : a) {
			w.append(i+"\r\n");
		}
		w.close();
	}
    private static void plot2maps_doubleKey(Map<Double,Integer> map, String title, String xLable, String yLable, int scale, boolean continuousPlot) throws IOException{
		
		Plot plot1=new Plot();
		plot1.setTitle(title);
		plot1.setXLabel(xLable);
		plot1.setYLabel(yLable);
		plot1.setMarksStyle("dots");
		
		/*Plot plot2=new Plot();
		plot2.setTitle("LogLog "+title);
		plot2.setXLabel(xLable);
		plot2.setYLabel(yLable);
		plot2.setMarksStyle("various");*/
		
		Set<Double> keys=map.keySet();
		int val;
		for (Double key : keys) {
			val=map.get(key);
			//System.out.println(key+" : "+val);
			plot1.addPoint(0, key, scale*val, continuousPlot);
			//plot2.addPoint(0, Math.log(key), scale*Math.log(val), continuousPlot);						
		}		
		
		PlotApplication app=new PlotApplication(plot1);	
	    //app=new PlotApplication(plot2);	
	    
		
	}
    private static double pearsonCorrelation_mapValues(Map<Integer, int[]> map, int val1index, int val2index){
    	double sumv1=0, sumv2=0;//, sumv1v2=0, sumv1v1=0, sumv2v2=0;
		int v1,v2;
		Set<Integer> keys=map.keySet();
		for (Integer key : keys) {
			v1=map.get(key)[val1index];
			v2=map.get(key)[val2index];      
			sumv1+=v1;
			sumv2+=v2;
			//sumv1v2+=(v1*v2);
			//sumv1v1+=(v1*v1);
			//sumv2v2+=(v2*v2);
		}
		int n=keys.size();
		double meanV1=sumv1/n, meanV2=sumv2/n,
		       c=0, s1=0, s2=0;
		for (Integer key : keys) {
			v1=map.get(key)[val1index];
			v2=map.get(key)[val2index];      
			c+=(v1-meanV1)*(v2-meanV2);
			s1+=Math.pow(v1-meanV1,2);
			s2+=Math.pow(v2-meanV2,2);
		}
		
		double cov=c/n;//(sumv1v2*n) - (sumv1 *sumv2);
		double sigmav1=Math.sqrt(s1/n);//Math.sqrt(Math.abs(  (sumv1v1 * n) -  (sumv1 * sumv1) ) );
		double sigmav2=Math.sqrt(s2/n);//Math.sqrt(Math.abs(  (sumv2v2 * n) -  (sumv2 * sumv2) ) );
		
		double correlationxy= cov/(sigmav1*sigmav2);
		
		//((n*sumv1v2)-(sumv1*sumv2))/(Math.sqrt(Math.abs(n*sumv1v1-Math.pow(sumv1, 2)))*Math.sqrt(Math.abs((n*sumv2v2-Math.pow(sumv2, 2)))));
		return correlationxy;
    }
    private static Map<Integer, int[]> putkeyValue_inMap(int key, int val, Map<Integer, int[]> map, int valIndex){
    	int[] valsarray;
    	if (map.containsKey(key)) {
			
    		switch (valIndex) {
			case 0:
				map.get(key)[0]= val;
				break;

			case 1:
				map.get(key)[1]= val;
				break;
				
			case 2:
				if (map.get(key)[2]==0) {//set the 3rd val only one time
					map.get(key)[2]= val;
				}
				break;
			}
    		
		}
    	else {//new key
    		valsarray=new int[3];
    		valsarray[valIndex]=val;
			map.put(key, valsarray);    		
		}
    	return map;
    }
    public static void interarrival_of_clique_edges(int startVertexIndexinFile, int stampColumn, String filename, int firstTimestamp, int rows, int Ni, int Nj,String separator, int linebreaks, int lasttimeStep) throws NumberFormatException, IOException{
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.currentTimeMillis();
		System.out.println("\ninterval_of_clique_edges() started at "+dateFormat.format(cal.getTime())+" , "+startTime+" millisec");
		
		//Plot plot1=new Plot();
		//plot1.setTitle("Evolution of clique densification - "+filename);
		//plot1.setYLabel("Number of emerged cliques at time step t");
		//plot1.setXLabel("time t");
		//plot1.setMarksStyle("dots");
		
		BipartiteGraph BG=new BipartiteGraph();
		
		FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
    	
		int vertexI_ID,vertexJ_ID,timeStamp, interarrival;
		IJ_Edge e_ij,e1;
		String line;
		String[] columns;
		
		
		Vector<IJ_Edge> edges=new Vector<IJ_Edge>();
		Map<Integer,HashSet<Integer>> imap, jmap;
		int previousTimestamp=firstTimestamp;
		int timestep=0, edges_currentCount=0;
		List<IJ_Edge> edges_subset=new ArrayList<IJ_Edge>();
		double interval=0;
		int current_cliqueCount=0;
		ArrayList<Integer> numberofcliques_ateachstep=new ArrayList<Integer>(lasttimeStep);
		Map<Double, Integer> interarrivalOfCliqueEdges_frequency=new HashMap<Double, Integer>();
		
		Map<Integer, int[]> iVertexID_NumberOfattachedCliques_degree_birthday=new HashMap<Integer, int[]>();//cliquesCount_including_ivertex=new double[Ni];
		Map<Integer, int[]> jVertexID_NumberOfattachedCliques_degree_birthday=new HashMap<Integer, int[]>();//cliquesCount_including_jvertex=new double[Nj];
		
		//Map<Integer, Integer> iVertexID_birthday=new HashMap<Integer, Integer>();//double[] ivertices_birthday=new double[Ni];  
		//Map<Integer, Integer> jVertexID_birthday=new HashMap<Integer, Integer>();//double[] jvertices_birthday=new double[Nj];  
		
		//int[] ivertices_degrees=new int[Ni];
		//int[] jvertices_degrees=new int[Nj];
		
		HashSet<String> clique=new HashSet<String>(4);
		HashSet<HashSet<String>> identified_cliques=new HashSet<HashSet<String>>();
		
		if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while ((line = br.readLine()) != null && timestep<lasttimeStep){
			vertexI_ID=0;vertexJ_ID=0;e_ij=null;
			columns = getColumns(line,separator);
			vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
			vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
			timeStamp=new BigDecimal(columns[stampColumn]).intValue();
			interarrival=timeStamp-previousTimestamp;
			previousTimestamp=timeStamp;
			e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
			BG.add_IJEdge(e_ij);
			edges.add(e_ij);
			edges_currentCount++;                                       
	    	imap= BG.IvertexID_JNeighborIDs_HashIndex;
	    	jmap= BG.JvertexID_INeighborIDs_HashIndex;
	    	
	    	/*if (ivertices_birthday[vertexI_ID]==0) {
	    		ivertices_birthday[vertexI_ID]=timeStamp-firstTimestamp;
			}
	    	if (jvertices_birthday[vertexJ_ID]==0) {
	    		jvertices_birthday[vertexJ_ID]=timeStamp-firstTimestamp;
			}*/
	    	
	    	iVertexID_NumberOfattachedCliques_degree_birthday=putkeyValue_inMap(vertexI_ID, timeStamp-firstTimestamp, iVertexID_NumberOfattachedCliques_degree_birthday, 2);//set if there is no previous birthday value
	    	jVertexID_NumberOfattachedCliques_degree_birthday=putkeyValue_inMap(vertexJ_ID, timeStamp-firstTimestamp, jVertexID_NumberOfattachedCliques_degree_birthday, 2);
	    	
	    	iVertexID_NumberOfattachedCliques_degree_birthday=putkeyValue_inMap(vertexI_ID, imap.get(vertexI_ID).size(), iVertexID_NumberOfattachedCliques_degree_birthday, 1);//unconditional
	    	jVertexID_NumberOfattachedCliques_degree_birthday=putkeyValue_inMap(vertexJ_ID, jmap.get(vertexJ_ID).size(), jVertexID_NumberOfattachedCliques_degree_birthday, 1);
	    	
	    	
	    	for (int i = 0; i < edges_currentCount; i++) {   //count 4-edge cliques at this timestep and commpute the distribution of inter-arrival time of the edges forming the clique and count the number of cliques attached to vertices
				e1=edges.elementAt(i);
				edges_subset=edges.subList(i+1, edges_currentCount);     
				for (IJ_Edge e2 : edges_subset) {                       
					if (e1.iID!=e2.iID &&
							e1.jID!=e2.jID && 
							imap.get(e1.iID).contains(e2.jID) &&
							jmap.get(e1.jID).contains(e2.iID) ) {
						
						interval=(Math.abs(e1.timeStamp-e2.timeStamp)*1.0)/1.0;//min(e1.timeStamp, e2.timeStamp);
						interarrivalOfCliqueEdges_frequency=increaseValueInMap(interval,interarrivalOfCliqueEdges_frequency);
						
						clique=new HashSet<String>(4);
						clique.add("i"+e1.iID);clique.add("j"+e1.jID);clique.add("i"+e2.iID);clique.add("j"+e2.jID);
						
						
						if (!identified_cliques.contains(clique)) {
							
							identified_cliques.add(clique);
							
							current_cliqueCount++;
							
							iVertexID_NumberOfattachedCliques_degree_birthday=putkeyValue_inMap(e1.iID, iVertexID_NumberOfattachedCliques_degree_birthday.get(e1.iID)[0]+1, iVertexID_NumberOfattachedCliques_degree_birthday, 0);//cliquesCount_including_ivertex[e1.iID]++;
							jVertexID_NumberOfattachedCliques_degree_birthday=putkeyValue_inMap(e1.jID, jVertexID_NumberOfattachedCliques_degree_birthday.get(e1.jID)[0]+1, jVertexID_NumberOfattachedCliques_degree_birthday, 0);//cliquesCount_including_jvertex[e1.jID]++;
							iVertexID_NumberOfattachedCliques_degree_birthday=putkeyValue_inMap(e2.iID, iVertexID_NumberOfattachedCliques_degree_birthday.get(e2.iID)[0]+1, iVertexID_NumberOfattachedCliques_degree_birthday, 0);//cliquesCount_including_ivertex[e2.iID]++;
							jVertexID_NumberOfattachedCliques_degree_birthday=putkeyValue_inMap(e2.jID, jVertexID_NumberOfattachedCliques_degree_birthday.get(e2.jID)[0]+1, jVertexID_NumberOfattachedCliques_degree_birthday, 0);//cliquesCount_including_jvertex[e2.jID]++;
				
						}
						
					}
					
				}
			}
	    	numberofcliques_ateachstep.add(current_cliqueCount);
	    	//plot1.addPoint(0, timestep, current_cliqueCount, true);
	    	
	    	//System.out.println("t="+timestep+" |E|="+edges_currentCount+" N_cc="+current_cliqueCount+" sgt="+e_ij.ID);
			timestep++;
		}
		br.close();
		
		//new PlotApplication(plot1);	
		//pdf?
		plot2maps_doubleKey(interarrivalOfCliqueEdges_frequency, "Distribution of interarrival of clique-edges in "+filename, "clique edge inter-arrival", "Frequency of inter-arrival", 1, false);
		writeMap_doubleKeys(interarrivalOfCliqueEdges_frequency, "Distribution of interarrival of clique-edges - "+filename);
		//writeArrayList(numberofcliques_ateachstep,"number of cliques after adding each edge - "+filename);
		
		//array_plot(cliquesCount_including_ivertex, "Distribution of cliques attached to each i-vertex", "i-vertex", "frequency of attached clique", 1, true);
		//array_plot(cliquesCount_including_jvertex, "Distribution of cliques attached to each j-vertex", "j-vertex", "frequency of attached clique", 1, true);
		
		double correlatio_iVertexdegree_attachedCliqueCount=pearsonCorrelation_mapValues(iVertexID_NumberOfattachedCliques_degree_birthday,0,1),
		       correlatio_jVertexdegree_attachedCliqueCount=pearsonCorrelation_mapValues(jVertexID_NumberOfattachedCliques_degree_birthday,0,1);
	    System.out.println("\n Pearson Correlation between degree and the number of cliques attached to i-vertices="+correlatio_iVertexdegree_attachedCliqueCount+
				"\n Pearson Correlation between degree and the number of cliques attached to j-vertices="+correlatio_jVertexdegree_attachedCliqueCount);
		
		double correlation_between_iVertexbirthday_and_attachedCliqueCount=pearsonCorrelation_mapValues(iVertexID_NumberOfattachedCliques_degree_birthday,0,2),
		       correlation_between_jVertexbirthday_and_attachedCliqueCount=pearsonCorrelation_mapValues(jVertexID_NumberOfattachedCliques_degree_birthday,0,2);
		System.out.println("\n Pearson Correlation between birthday and the number of cliques attached to i-vertices="+correlation_between_iVertexbirthday_and_attachedCliqueCount+
				"\n Pearson Correlation between birthday and the number of cliques attached to j-vertices="+correlation_between_jVertexbirthday_and_attachedCliqueCount);
		
    	long finishTime=System.currentTimeMillis();
		long duration=finishTime-startTime;
		cal = Calendar.getInstance();
		System.out.println("\n\ninterval_of_clique_edges() finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" millisec, duration="+duration+" millisec" );		
    }
   
    
    //hubs contributing to cliques
    public static double  prob_of_clqswithhubs(int lasttimeStep, int startVertexIndexinFile, int stampColumn, String filename, int firstTimestamp, int rows, int Ni, int Nj,String separator, int linebreaks) throws NumberFormatException, IOException{
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.currentTimeMillis();
		System.out.println("\n  prob_of_clqswithhubs() started at "+dateFormat.format(cal.getTime())+" , "+startTime+" millisec");
		
		Map<Integer,Vector<Double>> avIdegs_avJdegs = timestap_avgIdeg_avgJdeg(lasttimeStep, startVertexIndexinFile, filename, linebreaks, stampColumn, firstTimestamp, separator);
    	double avgIdeg=1.0*Math.ceil(avIdegs_avJdegs.get( lasttimeStep-1)  .elementAt(0));//v.elementAt(0); 
    	double avgJdeg=1.0*Math.ceil(avIdegs_avJdegs.get(lasttimeStep-1).elementAt(1));//v.elementAt(1);
		
		
		FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
    	
		int vertexI_ID,vertexJ_ID,timeStamp, interarrival;
		IJ_Edge e_ij;
		String line;
		String[] columns;
		
		Map<Integer,HashSet<Integer>> imap, jmap;
		int previousTimestamp=firstTimestamp;
		int timestep=1;
		Map<HashSet<String>, Integer> clique_maxdegDiffOfEdges=new HashMap<HashSet<String>, Integer>();
		HashSet<String> clique=new HashSet<String>(4);
		HashSet<HashSet<String>> identifiedclqs=new HashSet<HashSet<String>>();
		
		Set<Integer> ivertices, jvertices, i2_vertices,j2_vertices;
		Vector<Integer>  vi1neighbors=new Vector<Integer>(); List<Integer> vi1neighbors_sublist=new ArrayList<Integer>(); 
		int vi1neighbors_currentSize, j1, i2vertices_size;
		Vector<Integer>  vj1neighbors=new Vector<Integer>(); List<Integer> vj1neighbors_sublist=new ArrayList<Integer>(); 
		int vj1neighbors_currentSize, i1, j2vertices_size;
		
		int[] cliqs_with_0ihub_1ihub_2ihubs=new int[3];
		int[] cliqs_with_0jhub_1jhub_2jhubs=new int[3];
		int[] clqs_with_0to4_hubs=new int[5];
		int nihubs=0, njhubs=0, nhubs=0;
		/*
		int[] cliqs_with_1i0j_1i1j_1i2j=new int[3];
		int[] cliqs_with_1j0i_1j1i_1j2i=new int[3];
		
		int[] cliqs_with_2i0j_2i1j_2i2j=new int[3];
		int[] cliqs_with_2j0i_2j1i_2j2i=new int[3];
		*/
		
		//Map<Integer,Integer> ihub_numberOfcontributingClqs=new HashMap<Integer, Integer>(), jhub_numberOfcontributingClqs=new HashMap<Integer, Integer>();;
		
		BipartiteGraph BG=new BipartiteGraph();
		
		if (linebreaks!=0) {
			for (int l = 0; l < linebreaks; l++) {
				br.readLine();
			}
		}
		while (timestep<=lasttimeStep && (line = br.readLine()) != null){
			vertexI_ID=0;vertexJ_ID=0;e_ij=null;
			columns = getColumns(line,separator);
			vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
			vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
			timeStamp=new BigDecimal(columns[stampColumn]).intValue();
			interarrival=timeStamp-previousTimestamp;
			previousTimestamp=timeStamp;
			e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
			BG.add_IJEdge(e_ij);                                     
	    	imap= BG.IvertexID_JNeighborIDs_HashIndex;
	    	jmap= BG.JvertexID_INeighborIDs_HashIndex;
	    	
	    	if (Ni<=Nj) {
	    		ivertices=imap.keySet();
		    	for (Integer vi1 : ivertices) {
		    		vi1neighbors=toVector(imap.get(vi1));
		    		vi1neighbors_currentSize=vi1neighbors.size();
					for (int jindex = 0; jindex < vi1neighbors_currentSize; jindex++) {//for each pair of i1's neighbors <j1,j2>, the mutual i-neighbors of j1 and j2 form a butterfly
						j1=vi1neighbors.elementAt(jindex);
						vi1neighbors_sublist=vi1neighbors.subList(jindex+1, vi1neighbors_currentSize);
						for (Integer vj2 : vi1neighbors_sublist) {
							
							i2_vertices=mutualNeighbors(j1,vj2,jmap);i2_vertices.remove(vi1);
	                        i2vertices_size=i2_vertices.size();
							if (i2vertices_size!=0) {
								for (int vi2 : i2_vertices) {
									
									clique=new HashSet<String>(4);
			                		clique.add("i"+vi1);clique.add("j"+j1);clique.add("i"+vi2);clique.add("j"+vj2);
			                		
			                		
			                		if (!identifiedclqs.contains(clique)){
			                			identifiedclqs.add(clique);
			                			
			                			nhubs=0;njhubs=0;nihubs=0;
			                			if (imap.get(vi1).size()>avgIdeg) {
											nihubs++;nhubs++;
											//ihub_numberOfcontributingClqs=increaseValueInMap(vi1, 1, ihub_numberOfcontributingClqs);
										}
			                			if (imap.get(vi2).size()>avgIdeg) {
											nihubs++;nhubs++;
											//ihub_numberOfcontributingClqs=increaseValueInMap(vi2, 1, ihub_numberOfcontributingClqs);
										}
			                			if (jmap.get(j1).size()>avgJdeg) {
											njhubs++;nhubs++;
											//jhub_numberOfcontributingClqs=increaseValueInMap(j1, 1, jhub_numberOfcontributingClqs);
										}
			                			if (jmap.get(vj2).size()>avgJdeg) {
											njhubs++;nhubs++;
											//jhub_numberOfcontributingClqs=increaseValueInMap(vj2, 1, jhub_numberOfcontributingClqs);
										}
			                			
			                			cliqs_with_0ihub_1ihub_2ihubs[nihubs]++;
			                			cliqs_with_0jhub_1jhub_2jhubs[njhubs]++;
			                			
			                			clqs_with_0to4_hubs[nhubs]++;
			                			
			                			/*
			                			if (nihubs==1) {
			                				cliqs_with_1i0j_1i1j_1i2j[njhubs]++;
										}
			                			if (njhubs==1) {
			                				cliqs_with_1j0i_1j1i_1j2i[nihubs]++;
										}
			                			
			                			if (nihubs==2) {
			                				cliqs_with_2i0j_2i1j_2i2j[njhubs]++;
										}
			                			if (njhubs==2) {
			                				cliqs_with_2j0i_2j1i_2j2i[nihubs]++;
										}
			                			*/
			                			
									}//end if
								}
							}						
						}
					}	    		
				}
		    	
			}
	    	else{
	    		jvertices=jmap.keySet();
		    	for (Integer vj1 : jvertices) {
		    		vj1neighbors=toVector(jmap.get(vj1));
		    		vj1neighbors_currentSize=vj1neighbors.size();
					for (int index = 0; index < vj1neighbors_currentSize; index++) {//for each pair of i1's neighbors <j1,j2>, the mutual i-neighbors of j1 and j2 form a butterfly
						i1=vj1neighbors.elementAt(index);
						vj1neighbors_sublist=vj1neighbors.subList(index+1, vj1neighbors_currentSize);
						for (Integer vi2 : vj1neighbors_sublist) {
							
							j2_vertices=mutualNeighbors(i1,vi2,imap);j2_vertices.remove(vj1);
	                        j2vertices_size=j2_vertices.size();
							if (j2vertices_size!=0) {
								for (int vj2 : j2_vertices) {
									clique=new HashSet<String>(4);
			                		clique.add("i"+i1);clique.add("j"+vj1);clique.add("i"+vi2);clique.add("j"+vj2);
			                		
			                		if (!identifiedclqs.contains(clique)){
			                			identifiedclqs.add(clique);
			                			
			                			njhubs=0;nihubs=0;nhubs=0;
			                			if (imap.get(i1).size()>avgIdeg) {
											nihubs++;nhubs++;
											//ihub_numberOfcontributingClqs=increaseValueInMap(i1, 1, ihub_numberOfcontributingClqs);
										}
			                			if (imap.get(vi2).size()>avgIdeg) {
											nihubs++;nhubs++;
											//ihub_numberOfcontributingClqs=increaseValueInMap(vi2, 1, ihub_numberOfcontributingClqs);
										}
			                			if (jmap.get(vj1).size()>avgJdeg) {
											njhubs++;nhubs++;
											//jhub_numberOfcontributingClqs=increaseValueInMap(vj1, 1, jhub_numberOfcontributingClqs);
										}
			                			if (jmap.get(vj2).size()>avgJdeg) {
											njhubs++;nhubs++;
											//jhub_numberOfcontributingClqs=increaseValueInMap(vj2, 1, jhub_numberOfcontributingClqs);
										}
			                			
			                			cliqs_with_0ihub_1ihub_2ihubs[nihubs]++;
			                			cliqs_with_0jhub_1jhub_2jhubs[njhubs]++;
			                			clqs_with_0to4_hubs[nhubs]++;
			                			
			                			/*
			                			if (nihubs==1) {
			                				cliqs_with_1i0j_1i1j_1i2j[njhubs]++;
										}
			                			if (njhubs==1) {
											cliqs_with_1j0i_1j1i_1j2i[nihubs]++;
										}
			                			
			                			
			                			if (nihubs==2) {
			                				cliqs_with_2i0j_2i1j_2i2j[njhubs]++;
										}
			                			if (njhubs==2) {
			                				cliqs_with_2j0i_2j1i_2j2i[nihubs]++;
										}*/
									}
								} 
							}						
						}
					}	    		
				}
	    	}// end else
	    	//System.out.println("t="+timestep);
			timestep++;
		}
		br.close();
		/*
		double average_ihub_contributingconnections=0;
		Set<Integer> contributing_ihubs=ihub_numberOfcontributingClqs.keySet();
		for (Integer ihub : contributing_ihubs) {
			average_ihub_contributingconnections+=(1.0*ihub_numberOfcontributingClqs.get(ihub)/(1.0*BG.IvertexID_JNeighborIDs_HashIndex.get(ihub).size()));
		}
		average_ihub_contributingconnections=average_ihub_contributingconnections*1.0/(1.0*contributing_ihubs.size());
		
		
		double average_jhub_contributingconnections=0;
		Set<Integer> contributing_jhubs=jhub_numberOfcontributingClqs.keySet();
		for (Integer jhub : contributing_jhubs) {
			average_jhub_contributingconnections+=(1.0*jhub_numberOfcontributingClqs.get(jhub)/(1.0*BG.JvertexID_INeighborIDs_HashIndex.get(jhub).size()));
		}
		average_jhub_contributingconnections=average_jhub_contributingconnections*1.0/(1.0*contributing_jhubs.size());
		*/
		
		System.out.println("Number of clqs with 0ihubs: "+cliqs_with_0ihub_1ihub_2ihubs[0]+"  , 1ihub: "+cliqs_with_0ihub_1ihub_2ihubs[1]+"  , 2ihubs: "+cliqs_with_0ihub_1ihub_2ihubs[2]
				        +"\nNumber of clqs with  0jhubs: "+cliqs_with_0jhub_1jhub_2jhubs[0]+"  , 1jhubs: "+cliqs_with_0jhub_1jhub_2jhubs[1]+"  , 2jhubs: "+cliqs_with_0jhub_1jhub_2jhubs[2]+"\ntotal clqs: "+identifiedclqs.size()+
				       
				        
				        "\n\n fraction of clqs with 0hubs:"+clqs_with_0to4_hubs[0]*1.0/(1.0*identifiedclqs.size())+"  ,  1hub="+clqs_with_0to4_hubs[1]*1.0/(1.0*identifiedclqs.size())+"  ,  2hubs="+clqs_with_0to4_hubs[2]*1.0/(1.0*identifiedclqs.size())+"  ,  3hubs="+clqs_with_0to4_hubs[3]*1.0/(1.0*identifiedclqs.size())+"  , 4hubs="+clqs_with_0to4_hubs[4]*1.0/(1.0*identifiedclqs.size())+
				        
				        
				        "\n\nfraction of clqs with 0ihubs: "+cliqs_with_0ihub_1ihub_2ihubs[0]*1.0/(1.0*identifiedclqs.size())+"  , 1ihub: "+cliqs_with_0ihub_1ihub_2ihubs[1]*1.0/(1.0*identifiedclqs.size())+"  , 2ihubs: "+cliqs_with_0ihub_1ihub_2ihubs[2]*1.0/(1.0*identifiedclqs.size())
						        +"\nfraction of clqs with  0jhubs: "+cliqs_with_0jhub_1jhub_2jhubs[0]*1.0/(1.0*identifiedclqs.size())+"  , 1jhubs: "+cliqs_with_0jhub_1jhub_2jhubs[1]*1.0/(1.0*identifiedclqs.size())+"  , 2jhubs: "+cliqs_with_0jhub_1jhub_2jhubs[2]*1.0/(1.0*identifiedclqs.size())
						        
						        
						        //+"\n\n fraction of clq wit 1 i-hub and 0 j-hub: "+cliqs_with_1i0j_1i1j_1i2j[0]+"/"+identifiedclqs.size()+"="+cliqs_with_1i0j_1i1j_1i2j[0]*1.0/(1.0*identifiedclqs.size())+
						        	//									" 1 jhub:"+cliqs_with_1i0j_1i1j_1i2j[1]+"/"+identifiedclqs.size()+"="+cliqs_with_1i0j_1i1j_1i2j[1]*1.0/(1.0*identifiedclqs.size())+
						        		//								" 2 jhub:"+cliqs_with_1i0j_1i1j_1i2j[2]+"/"+identifiedclqs.size()+"="+cliqs_with_1i0j_1i1j_1i2j[2]*1.0/(1.0*identifiedclqs.size())+
						        										
						      //  "fraction of clq wit 1 j-hub and 0 i-hub: "+cliqs_with_1j0i_1j1i_1j2i[0]+"/"+identifiedclqs.size()+"="+cliqs_with_1j0i_1j1i_1j2i[0]*1.0/(1.0*identifiedclqs.size())+
						        //										" 1 ihub:"+cliqs_with_1j0i_1j1i_1j2i[1]+"/"+identifiedclqs.size()+"="+cliqs_with_1j0i_1j1i_1j2i[1]*1.0/(1.0*identifiedclqs.size())+
						        	//									" 2 ihub:"+cliqs_with_1j0i_1j1i_1j2i[2]+"/"+identifiedclqs.size()+"="+cliqs_with_1j0i_1j1i_1j2i[2]*1.0/(1.0*identifiedclqs.size())
						        										
						        										
						     //   +"\n\n fraction of clq wit 2 i-hub and 0 j-hub: "+cliqs_with_2i0j_2i1j_2i2j[0]+"/"+identifiedclqs.size()+"="+cliqs_with_2i0j_2i1j_2i2j[0]*1.0/(1.0*identifiedclqs.size())+
						       // 										" 1 jhub:"+cliqs_with_2i0j_2i1j_2i2j[1]+"/"+identifiedclqs.size()+"="+cliqs_with_2i0j_2i1j_2i2j[1]*1.0/(1.0*identifiedclqs.size())+
						        //										" 2 jhub:"+cliqs_with_2i0j_2i1j_2i2j[2]+"/"+identifiedclqs.size()+"="+cliqs_with_2i0j_2i1j_2i2j[2]*1.0/(1.0*identifiedclqs.size())+
						        										
						        //"fraction of clq wit 2 j-hub and 0 i-hub: "+cliqs_with_2j0i_2j1i_2j2i[0]+"/"+identifiedclqs.size()+"="+cliqs_with_2j0i_2j1i_2j2i[0]*1.0/(1.0*identifiedclqs.size())+
						        	//									" 1 ihub:"+cliqs_with_2j0i_2j1i_2j2i[1]+"/"+identifiedclqs.size()+"="+cliqs_with_2j0i_2j1i_2j2i[1]*1.0/(1.0*identifiedclqs.size())+
						        		//								" 2 ihub:"+cliqs_with_2j0i_2j1i_2j2i[2]+"/"+identifiedclqs.size()+"="+cliqs_with_2j0i_2j1i_2j2i[2]*1.0/(1.0*identifiedclqs.size())
						        										
						      // +"\n\n avg i-hub contributing connections (effective i-hub degree)="+average_ihub_contributingconnections+
						      // " , effective j-hub degree="+average_jhub_contributingconnections
				);
		
		long finishTime=System.currentTimeMillis();
		long duration=finishTime-startTime;
		cal = Calendar.getInstance();
		System.out.println("\n\n  prob_of_clqswithhubs() finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" millisec, duration="+duration+" millisec" );		
		
		double p=cliqs_with_0ihub_1ihub_2ihubs[1]*1.0/(1.0*identifiedclqs.size())
				+cliqs_with_0ihub_1ihub_2ihubs[2]*1.0/(1.0*identifiedclqs.size())
				+cliqs_with_0jhub_1jhub_2jhubs[1]*1.0/(1.0*identifiedclqs.size())
				+cliqs_with_0jhub_1jhub_2jhubs[2]*1.0/(1.0*identifiedclqs.size());
		return p;
    }
    private static Vector<Double> avg_uniqueiDegree_uniquejDegree(Map<Integer,HashSet<Integer>>imap, Map<Integer,HashSet<Integer>>jmap){//assuming IDs start from 1 -degree distribution is normalized to the number of vertices
    	Vector<Double> avgideg_avgJdeg=new Vector<Double>(2);
    	HashSet<Integer> uniqueidegreees=new HashSet<Integer>(), uniquejdegreees=new HashSet<Integer>();
    	
    	int Ni=imap.size();
  		HashSet<Integer> jneighbors;
  		for (int i = 0; i < Ni; i++) {
  			jneighbors=imap.get(i);
  			if (jneighbors!=null) {
  				uniqueidegreees.add(jneighbors.size());
  			}
  								
  		}
  		
  		
  		int Nj=jmap.size();
  		HashSet<Integer> ineighbors;
  		for (int j = 0; j < Nj; j++) {
  			ineighbors=jmap.get(j);
  			if (ineighbors!=null) {
  				uniquejdegreees.add(ineighbors.size());
  			}
  								
  		}
  		
  		avgideg_avgJdeg.add(mean(uniqueidegreees));avgideg_avgJdeg.add(mean(uniquejdegreees));
  		
  		return avgideg_avgJdeg;
  	}
    private static Map<Integer,Vector<Double>> timestap_avgIdeg_avgJdeg(int lastt, int startVertexIndexinFile, String fileName, int linebreaks, int stampColumn, int firstTimestamp, String separator) throws NumberFormatException, IOException{
		
		BipartiteGraph BG=new BipartiteGraph();
		BG.t0=firstTimestamp;
		BG.ivertices=new HashSet<Vertex>(); BG.jvertices=new HashSet<Vertex>();
		
		FileInputStream fstream = new FileInputStream(fileName);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
    	
		int vertexI_ID,vertexJ_ID,timeStamp;
		IJ_Edge e_ij;
		String line;
		String[] columns;
		
		int previousTimestamp=firstTimestamp;
		int c=0;
		
		int t=1;
		
		Map<Integer,Integer> i_ID_index=new HashMap<Integer,Integer>();
		Map<Integer,Integer> j_ID_index=new HashMap<Integer,Integer>();
		int temp_i_index, temp_j_index;
		Vertex iv,jv;
		
		int inter_arrival=0;
		
		Map<Integer,Vector<Double>> avgis_avgjs=new HashMap<Integer,Vector<Double>>();
		Vector<Double> avgi_avgj=new Vector<Double>(2);
		
		int maxtemp=0;
		if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while (t<=lastt&&(line = br.readLine()) != null){
			
			
			vertexI_ID=0;vertexJ_ID=0;e_ij=null;
			columns = getColumns(line,separator);
			vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
			vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
			timeStamp=new BigDecimal(columns[stampColumn]).intValue();//Integer.parseInt(columns[stampColumn]);	
			
			inter_arrival=0;
			
			
			if (i_ID_index.containsKey(vertexI_ID)) {//existing i-vertex
				temp_i_index=i_ID_index.get(vertexI_ID);
				
				if (j_ID_index.containsKey(vertexJ_ID)) {//existing j-vertex
					temp_j_index=j_ID_index.get(vertexJ_ID);
				}
				else {//new j-vertex
					temp_j_index=j_ID_index.keySet().size();
					j_ID_index.put(vertexJ_ID,temp_j_index);
					
					jv=new Vertex(timeStamp, temp_j_index);
					BG.jvertices.add(jv);
				}	
			}//end if existing i-vertex
			
			else{//new i-vertex
				temp_i_index=i_ID_index.keySet().size();
				i_ID_index.put(vertexI_ID,temp_i_index);
				
				iv=new Vertex(timeStamp, temp_i_index);
				BG.ivertices.add(iv);
				
				if (j_ID_index.containsKey(vertexJ_ID)) {//existing j-vertex
					temp_j_index=j_ID_index.get(vertexJ_ID);
				}
				else {//new j-vertex
					temp_j_index=j_ID_index.keySet().size();
					j_ID_index.put(vertexJ_ID,temp_j_index);
					
					jv=new Vertex(timeStamp, temp_j_index);
					BG.jvertices.add(jv);
				}
			}
			
			e_ij=new IJ_Edge(temp_i_index,temp_j_index,timeStamp, inter_arrival);
			BG.add_IJEdge(e_ij);
			
			
			if ((t+1)%1000==0 && t>=999) {
				
				avgi_avgj=avg_uniqueiDegree_uniquejDegree(BG.IvertexID_JNeighborIDs_HashIndex, BG.JvertexID_INeighborIDs_HashIndex);   System.out.println("t="+t+" avgIdeg-avgJdeg="+avgi_avgj);
				avgis_avgjs.put(t, avgi_avgj);
			}
			t++;
		}
		br.close();
		
		
		return avgis_avgjs;	
	}
    public static double[] probs_of_clqswith_iHubs_jHubs(int lasttimeStep, int startVertexIndexinFile, int stampColumn, String filename, int firstTimestamp, int rows, int Ni, int Nj,String separator, int linebreaks) throws NumberFormatException, IOException{
    	
		FileInputStream fstream ;
    	BufferedReader br;
    	
		int vertexI_ID,vertexJ_ID,timeStamp, interarrival;
		IJ_Edge e_ij;
		String line;
		String[] columns;
		
		Map<Integer,HashSet<Integer>> imap, jmap;
		int previousTimestamp=firstTimestamp;
		int timestep=1;
		HashSet<String> clique=new HashSet<String>(4);
		HashSet<HashSet<String>> identifiedclqs=new HashSet<HashSet<String>>();
		
		Set<Integer> ivertices, jvertices, i2_vertices,j2_vertices;
		Vector<Integer>  vi1neighbors=new Vector<Integer>(); List<Integer> vi1neighbors_sublist=new ArrayList<Integer>(); 
		int vi1neighbors_currentSize, j1, i2vertices_size;
		Vector<Integer>  vj1neighbors=new Vector<Integer>(); List<Integer> vj1neighbors_sublist=new ArrayList<Integer>(); 
		int vj1neighbors_currentSize, i1, j2vertices_size;
		
		int[] cliqs_with_0ihub_1ihub_2ihubs;
		int[] cliqs_with_0jhub_1jhub_2jhubs;
		int nihubs=0, njhubs=0;
		
		double p=0;
		double[] probs=new double[10];//[lasttimeStep/1000];------------------------------------------------------->changed
		double avgIdeg=0, avgJdeg=0;
		Vector<Double> v=new Vector<Double>(2);
		
		Map<Integer,Vector<Double>> avIdegs_avJdegs = timestap_avgIdeg_avgJdeg(lasttimeStep, startVertexIndexinFile, filename, linebreaks, stampColumn, firstTimestamp, separator);
		
		
		BipartiteGraph BG;
		
		for (int g = 1; g <=10; g++){// g<=probs.length; g++) {------------------------------------------------------->changed
			
			fstream = new FileInputStream(filename);
			br = new BufferedReader(new InputStreamReader(fstream));
			BG=new BipartiteGraph();
			cliqs_with_0ihub_1ihub_2ihubs=new int[3];
			cliqs_with_0jhub_1jhub_2jhubs=new int[3];
			identifiedclqs=new HashSet<HashSet<String>>();
			nihubs=0; njhubs=0;
			timestep=1;
			
			clique=new HashSet<String>(4);
			vi1neighbors=new Vector<Integer>(); vi1neighbors_sublist=new ArrayList<Integer>(); 
			vj1neighbors=new Vector<Integer>(); vj1neighbors_sublist=new ArrayList<Integer>(); 
			
			if (linebreaks!=0) {
				for (int l = 0; l < linebreaks; l++) {
					br.readLine();
				}
			}
			while (timestep<(g*1000) && (line = br.readLine()) != null){
				
				vertexI_ID=0;vertexJ_ID=0;e_ij=null;
				columns = getColumns(line,separator);
				vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
				vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
				timeStamp=new BigDecimal(columns[stampColumn]).intValue();
				interarrival=timeStamp-previousTimestamp;
				previousTimestamp=timeStamp;
				e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
				BG.add_IJEdge(e_ij);                                     
		    	imap= BG.IvertexID_JNeighborIDs_HashIndex;
		    	jmap= BG.JvertexID_INeighborIDs_HashIndex;
		    	
		    	//v=avg_uniqueiDegree_uniquejDegree(imap, jmap);
		    	avgIdeg=Math.ceil(avIdegs_avJdegs.get( (g*1000)-1)  .elementAt(0));//v.elementAt(0); 
		    	avgJdeg=Math.ceil(avIdegs_avJdegs.get((g*1000)-1).elementAt(1));//v.elementAt(1);
		    	//System.out.println("t="+timestep+"  ,  avg-unique-Ideg="+avgIdeg+"  -   avg-unique-Ideg="+avgJdeg);
		    	
		    	if (Ni<=Nj) {
		    		ivertices=imap.keySet();
			    	for (Integer vi1 : ivertices) {
			    		vi1neighbors=toVector(imap.get(vi1));
			    		vi1neighbors_currentSize=vi1neighbors.size();
						for (int jindex = 0; jindex < vi1neighbors_currentSize; jindex++) {//for each pair of i1's neighbors <j1,j2>, the mutual i-neighbors of j1 and j2 form a butterfly
							j1=vi1neighbors.elementAt(jindex);
							vi1neighbors_sublist=vi1neighbors.subList(jindex+1, vi1neighbors_currentSize);
							for (Integer vj2 : vi1neighbors_sublist) {
								
								i2_vertices=mutualNeighbors(j1,vj2,jmap);i2_vertices.remove(vi1);
		                        i2vertices_size=i2_vertices.size();
								if (i2vertices_size!=0) {
									for (int vi2 : i2_vertices) {
										
										clique=new HashSet<String>(4);
				                		clique.add("i"+vi1);clique.add("j"+j1);clique.add("i"+vi2);clique.add("j"+vj2);
				                		
				                		
				                		if (!identifiedclqs.contains(clique)){
				                			identifiedclqs.add(clique);
				                			
				                			njhubs=0;nihubs=0;
				                			if (imap.get(vi1).size()>avgIdeg) {
												nihubs++;
											}
				                			if (imap.get(vi2).size()>avgIdeg) {
												nihubs++;
											}
				                			if (jmap.get(j1).size()>avgJdeg) {
												njhubs++;
											}
				                			if (jmap.get(vj2).size()>avgJdeg) {
												njhubs++;
											}
				                			
				                			cliqs_with_0ihub_1ihub_2ihubs[nihubs]++;
				                			cliqs_with_0jhub_1jhub_2jhubs[njhubs]++;
				                			
										}//end if
									}
								}						
							}
						}	    		
					}
			    	
				}
		    	else{
		    		jvertices=jmap.keySet();
			    	for (Integer vj1 : jvertices) {
			    		vj1neighbors=toVector(jmap.get(vj1));
			    		vj1neighbors_currentSize=vj1neighbors.size();
						for (int index = 0; index < vj1neighbors_currentSize; index++) {//for each pair of i1's neighbors <j1,j2>, the mutual i-neighbors of j1 and j2 form a butterfly
							i1=vj1neighbors.elementAt(index);
							vj1neighbors_sublist=vj1neighbors.subList(index+1, vj1neighbors_currentSize);
							for (Integer vi2 : vj1neighbors_sublist) {
								
								j2_vertices=mutualNeighbors(i1,vi2,imap);j2_vertices.remove(vj1);
		                        j2vertices_size=j2_vertices.size();
								if (j2vertices_size!=0) {
									for (int vj2 : j2_vertices) {
										clique=new HashSet<String>(4);
				                		clique.add("i"+i1);clique.add("j"+vj1);clique.add("i"+vi2);clique.add("j"+vj2);
				                		
				                		if (!identifiedclqs.contains(clique)){
				                			identifiedclqs.add(clique);
				                			
				                			njhubs=0;nihubs=0;
				                			if (imap.get(i1).size()>avgIdeg) {
												nihubs++;
											}
				                			if (imap.get(vi2).size()>avgIdeg) {
												nihubs++;
											}
				                			if (jmap.get(vj1).size()>avgJdeg) {
												njhubs++;
											}
				                			if (jmap.get(vj2).size()>avgJdeg) {
												njhubs++;
											}
				                			
				                			cliqs_with_0ihub_1ihub_2ihubs[nihubs]++;
				                			cliqs_with_0jhub_1jhub_2jhubs[njhubs]++;
										}
									} 
								}						
							}
						}	    		
					}
		    	}
		    	
		    	
				timestep++;
			}
			br.close();
			
			System.out.println("\nt="+timestep+"  ,  avg-unique-Ideg="+avgIdeg+"  -   avg-unique-Ideg="+avgJdeg);
    		p=( cliqs_with_0ihub_1ihub_2ihubs[1]*1.0/(1.0*identifiedclqs.size()) )
    				+( cliqs_with_0ihub_1ihub_2ihubs[2]*1.0/(1.0*identifiedclqs.size()) )
    			    +( cliqs_with_0jhub_1jhub_2jhubs[1]*1.0/(1.0*identifiedclqs.size()) )
    			    +( cliqs_with_0jhub_1jhub_2jhubs[2]*1.0/(1.0*identifiedclqs.size()) );
    		probs[g-1]=p;//[((timestep+1)/1000)-1]=p;
    		System.out.println(
    				(cliqs_with_0ihub_1ihub_2ihubs[1]*1.0/(1.0*identifiedclqs.size()) )
    				+" "+( cliqs_with_0ihub_1ihub_2ihubs[2]*1.0/(1.0*identifiedclqs.size()) )
    			    +" "+( cliqs_with_0jhub_1jhub_2jhubs[1]*1.0/(1.0*identifiedclqs.size()) )
    			    +" "+( cliqs_with_0jhub_1jhub_2jhubs[2]*1.0/(1.0*identifiedclqs.size()) )
    				);
    		System.out.println("p(N_hubs(t="+timestep+")>1) = "+p);
			
		}//end g
		
		
		return probs;
    }
    
    //temporal distribution
    private static Map<Integer, Integer> increaseValueInMap(int key, Map<Integer, Integer> map){
		int val;
		if (map.containsKey(key)) {
			val=map.get(key);
			map.put(key, val+1);
		}
		else{
			map.put(key, 1);
		}
		return map;
	}
    private static void plot_write_map(Map<Integer,Integer> map, String title, String xLable, String yLable, double Xscale, boolean continuousPlot) throws IOException{
		/*Plot plot1=new Plot();
		plot1.setTitle(title);
		plot1.setXLabel(xLable);
		plot1.setYLabel(yLable);
		plot1.setMarksStyle("dots");
		*/
		PrintWriter w = null;
    	try {
    		w=new PrintWriter(title);    
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Set<Integer> keys=map.keySet();
		
		int val;
		for (Integer key : keys) {
			val=map.get(key);
			//plot1.addPoint(0, Xscale*key, val, continuousPlot);
			w.append(key+" "+val+"\r\n");						
		}	
		w.close();
		//new PlotApplication(plot1);		    
	}
    public static void temporalDist( String filename, int linebreaks, String separator, int stampColumn) throws IOException{
    	FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
    	String sgt="";
    	String[] columns;
    	int timeStamp=0;
    	Map<Integer,Integer> stamp_freq=new HashMap<Integer,Integer>();
    	int t=0;
    	if (linebreaks!=0) {
			for (int l = 0; l < linebreaks; l++) {
				br.readLine();
			}
		}while ((sgt = br.readLine()) != null){
    		columns = getColumns(sgt,separator);
    		timeStamp=Integer.parseInt(columns[stampColumn]);//new BigDecimal(columns[stampColumn]).intValue();
    		increaseValueInMap(timeStamp, stamp_freq);
    		System.out.println(t);
    		t++;
    	}
    	br.close();
    	plot_write_map( stamp_freq, "dist of timestamps -"+filename, "time stamp", "freq", 1, false);
    }
    
    private static Map<Double,Double> increaseValueInMap(double key, Double increment, Map<Double,Double> map){
		double val;
		if (map.containsKey(key)) {
			val=map.get(key);
			map.put(key, val+increment);
		}
		else{
			map.put(key, increment);
		}
		return map;
	}
    private static Map<Integer,Double> increaseValueInMap(int key, Double increment, Map<Integer,Double> map){
		double val;
		if (map.containsKey(key)) {
			val=map.get(key);
			map.put(key, val+increment);
		}
		else{
			map.put(key, increment);
		}
		return map;
	}
    private static Map<Integer,Integer> increaseValueInMap(int key, Integer increment, Map<Integer,Integer> map){
		int val;
		if (map.containsKey(key)) {
			val=map.get(key);
			map.put(key, val+increment);
		}
		else{
			map.put(key, increment);
		}
		return map;
	}
    private static Map<Vector<Integer>,Integer> increaseValueInMap(Vector<Integer> key, Integer increment, Map<Vector<Integer>,Integer> map){
		int val;
		if (map.containsKey(key)) {
			val=map.get(key);
			map.put(key, val+increment);
		}
		else{
			map.put(key, increment);
		}
		return map;
	}
    
   
    //1 get ground truth - Number of cliques at t=W_k.t - eager()
    private static double mean(ArrayList<Double> a){
    	double m=0;
    	for (Double e : a) {
			m+=e;
		}
    	return (m*1.0)/a.size();
    }
    private static double standardDeviation_alist(ArrayList<Double> a, double mean){
		double std=0;
		int n=a.size();
		for (int i = 0; i < n; i++) {
			std+=Math.pow(a.get(i)-mean, 2);
		}
		std/=n;
		std=Math.sqrt(std);
		return std;
	}    
    private static Map<Vector<Integer>,HashSet<Integer>> updateMap(Vector<Integer> key_Triple, int nextVal_v, Map<Vector<Integer>,HashSet<Integer>> map_Triple_contributingvertices){
    	HashSet<Integer> vals=map_Triple_contributingvertices.get(key_Triple);
    	if (vals!=null) {
    		vals.add(nextVal_v);
        	map_Triple_contributingvertices.put(key_Triple, vals);
		}
    	else{
    		vals=new HashSet<Integer>(1);
    		vals.add(nextVal_v);
    		map_Triple_contributingvertices.put(key_Triple, vals);
    	}
    	return map_Triple_contributingvertices;
    }	
    private static Set<Integer> getIntersection(Set<Integer> set1, Set<Integer> set2) {
        boolean set1IsLarger = set1.size() > set2.size();
        Set<Integer> cloneSet = new HashSet<Integer>(set1IsLarger ? set2 : set1);
        cloneSet.retainAll(set1IsLarger ? set1 : set2);
        return cloneSet;
    }
    private static Set<Integer> mutualNeighbors(int v1, int v2, Map<Integer,HashSet<Integer>> neighbors){
    	/*HashSet<Integer> m=new HashSet<Integer>();
    	HashSet<Integer> neighbors1=neighbors.get(v1);
    	HashSet<Integer> neighbors2=neighbors.get(v2);
    	int n1=neighbors1.size(), n2=neighbors2.size();
    	if (n1<=n2) {
			for (Integer i : neighbors1) {
				if (neighbors2.contains(i)) {
					m.add(i);
				}
			}
		}
    	else{
    		for (Integer i : neighbors2) {
				if (neighbors1.contains(i)) {
					m.add(i);
				}
			}
    	}
    	return m;*/
    	HashSet<Integer> neighbors1=neighbors.get(v1);
    	HashSet<Integer> neighbors2=neighbors.get(v2);
    	/*int n1=neighbors1.size(), n2=neighbors2.size();
    	if (n1<=n2) {
			neighbors1.retainAll(neighbors2);
			return neighbors1;
		}
    	else{
    		neighbors2.retainAll(neighbors1);
			return neighbors2;
    	}*/
    	return getIntersection(neighbors1, neighbors2);
    }
    private static Vector<Integer> toVector(Set<Integer> set){
    	Vector<Integer> v=new Vector<Integer>();
    	for (Integer i : set) {
			v.add(i);
		}
    	return v;   	
    }
    public static void grountruth_butterflyCount(int startVertexIndexinFile, int stampColumn, String filename, int firstTimestamp,String separator, int linebreaks, int lasttimeStep, int avgIdeg, int avgJdeg) throws NumberFormatException, IOException{
    	
		Plot plot1=new Plot();
		plot1.setTitle("Temporal evolution of butterflies - "+filename);
		plot1.setYLabel("cumulative Number of butterflies");
		plot1.setXLabel("t");
		plot1.setMarksStyle("dots");
		
		
		PrintWriter nc=new PrintWriter("2 groundtruth cumulative number of cliques at all steps untill  tl="+lasttimeStep+" "+filename);
    		
    	
		Map<Integer,HashSet<Integer>> imap, jmap;
		int previousTimestamp=firstTimestamp;
		
		//sgt ingestion
		FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		int vertexI_ID,vertexJ_ID,timeStamp, interarrival;
		IJ_Edge e_ij;
		String[] columns;
		String sgt;
		int t=1;
		
		Set<Integer> ivertices, jvertices, i2_vertices, j2_vertices;
		Vector<Integer>  i1neighbors=new Vector<Integer>(), j1neighbors=new Vector<Integer>(); List<Integer> i1neighbors_sublist=new ArrayList<Integer>(), j1neighbors_sublist=new ArrayList<Integer>(); 
		int i1neighbors_currentSize, vj1, i2vertices_size, j1neighbors_currentSize, vvi1, j2vertices_size;
		
		HashSet<String> clique=new HashSet<String>(4);
		HashSet<HashSet<String>> identified_cliques=new HashSet<HashSet<String>>();
		
		//Vector<Integer> windowborders=readArray(windowborderFile);
		int Nc=0;
		
		BipartiteGraph BG=new BipartiteGraph();
		
		long beforeUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.currentTimeMillis();
		System.out.println("\ngrountruth_butterflyCount() started at "+dateFormat.format(cal.getTime())+" , "+startTime+" millisec   , memory="+beforeUsedMem);
		
    	
		
		if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while (t<=lasttimeStep && (sgt = br.readLine()) != null ){
			//ingest sgt
			columns = getColumns(sgt,separator);
			vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
			vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
			timeStamp=new BigDecimal(columns[stampColumn]).intValue();
			interarrival=timeStamp-previousTimestamp;
			previousTimestamp=timeStamp;
			
	    	//update the graph
	    	e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
			BG.add_IJEdge(e_ij);
			imap= BG.IvertexID_JNeighborIDs_HashIndex;
	    	jmap= BG.JvertexID_INeighborIDs_HashIndex;
	    	
			//update triple contributions
	    	if (avgIdeg<=avgJdeg) {
	    		ivertices=imap.keySet();
		    	for (Integer vi1 : ivertices) {
		    		i1neighbors=toVector(imap.get(vi1));
		    		i1neighbors_currentSize=i1neighbors.size();
					for (int jindex = 0; jindex < i1neighbors_currentSize; jindex++) {//for each pair of i1's neighbors <j1,j2>, the mutual neighbors of j1 and j2 form a butterfly
						vj1=i1neighbors.elementAt(jindex);
						i1neighbors_sublist=i1neighbors.subList(jindex+1, i1neighbors_currentSize);
						for (Integer vj2 : i1neighbors_sublist) {
							
							i2_vertices=mutualNeighbors(vj1,vj2, jmap);i2_vertices.remove(vi1);
	                        i2vertices_size=i2_vertices.size();
							
	                        if (i2vertices_size!=0) {
								for (int vi2 : i2_vertices) {
									clique=new HashSet<String>(4);
			                		clique.add("i"+vi1);clique.add("j"+vj1);clique.add("i"+vi2);clique.add("j"+vj2);
			                		identified_cliques.add(clique);
								} 
							}						
						}
					}	    		
				}
			}
	    	else{
	    		jvertices=jmap.keySet();
		    	for (Integer vvj1 : jvertices) {
		    		j1neighbors=toVector(jmap.get(vvj1));
		    		j1neighbors_currentSize=j1neighbors.size();
					for (int index = 0; index < j1neighbors_currentSize; index++) {//for each pair of i1's neighbors <j1,j2>, the mutual i-neighbors of j1 and j2 form a butterfly
						vvi1=j1neighbors.elementAt(index);
						j1neighbors_sublist=j1neighbors.subList(index+1, j1neighbors_currentSize);
						for (Integer vvi2 : j1neighbors_sublist) {
							
							j2_vertices=mutualNeighbors(vvi1,vvi2,imap);j2_vertices.remove(vvj1);
	                        j2vertices_size=j2_vertices.size();
							if (j2vertices_size!=0) {
    							for (int vvj2 : j2_vertices) {
    								clique=new HashSet<String>(4);
    		                		clique.add("i"+vvi1);clique.add("j"+vvj1);clique.add("i"+vvi2);clique.add("j"+vvj2);
    		                		identified_cliques.add(clique);
    							} 
    						}						
    					}
    				}	    		
    			} 
	    	}
	    	
	    	Nc=identified_cliques.size();
	    	
	    	plot1.addPoint(0, t, Nc, false);
	    	nc.append(Nc+"\r\n");
	    
	    	/*if (windowborders.contains(t)) {
	    		plot12.addPoint(0, t, Nc, false);
		    	nc2.append(Nc+"\r\n");
		    	System.out.println("t="+t+" Nc="+Nc);
			}*/
	    	//System.out.println("t="+t);
    		t++;	
		}
		br.close();
		nc.close();
		new PlotApplication(plot1);
		
		long afterUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	long actualMemUsed=afterUsedMem-beforeUsedMem;
    	long finishTime=System.currentTimeMillis();
		long duration=finishTime-startTime;
		cal = Calendar.getInstance();
		System.out.println("grountruth_butterflyCount() finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" millisec, duration="+duration+" millisec+   memory usage:"+actualMemUsed );
	}
    
  
    public static void  sGrapp_efficiency(int iteration, double exponent, int startVertexIndexinFile, int stampColumn, String filename, int firstTimestamp, int rows, int avgIdeg, int avgJdeg,String separator, int linebreaks,int Nt, double Ntw) throws NumberFormatException, IOException{
    	PrintWriter //w=new PrintWriter(iteration+" - timestep - approximation - window cutoff="+cutoff+"*"+Nt+" - exponent="+exponent+" - "+filename)
    	//, winmem=new PrintWriter("window memory usages (MB) - window cutoff="+cutoff+"*"+Nt+" - exponent="+exponent+" - "+filename),
    	winThroughput=new PrintWriter(iteration+" - window throughputs (edge per s) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+filename),
    	wintime=new PrintWriter(iteration+" - window times (ns) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+filename),
    	totalthroughput=new PrintWriter(iteration+" - total throughput (edge per s) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+filename);
		
    
    	Map<Integer,HashSet<Integer>> imap, jmap;
		int previousTimestamp=firstTimestamp;
		int edges_currentCount=0;	
		HashSet<String> clique=new HashSet<String>(4);
		HashSet<HashSet<String>> identified_cliques=new HashSet<HashSet<String>>();
		
		Set<Integer> ivertices, jvertices, i2_vertices, j2_vertices;
		Vector<Integer>  i1neighbors=new Vector<Integer>(), j1neighbors=new Vector<Integer>(); List<Integer> i1neighbors_sublist=new ArrayList<Integer>(), j1neighbors_sublist=new ArrayList<Integer>(); 
		int i1neighbors_currentSize, j1, i2vertices_size, j1neighbors_currentSize, i1, j2vertices_size;
		
		FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		int vertexI_ID,vertexJ_ID,timeStamp, interarrival;
		IJ_Edge e_ij;//,toBeRetired_e;
		String[] columns;
		String sgt;
		HashSet<Integer> uniquestamps=new HashSet<Integer>();
		int winNum=0, t=0;
		
		Vector<IJ_Edge> currentEdges=new Vector<IJ_Edge>();
		
		long Nc_cumulative=0, Nc_window=0;
		
		int totaledges=0;
		
		BipartiteGraph slidingBG=new BipartiteGraph();
		
		
		//long beforeUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.nanoTime();
		//System.out.println("\nlong_approx2() started at "+dateFormat.format(cal.getTime())+" , "+startTime+" millisec , memory="+beforeUsedMem);
		long  total, wFinish, wStartTime=System.nanoTime(), thru = 0, wDuration,  winThru=0;//,wUsed,total,  wbeforeUsedMem;//=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory(), total;//, totalMem;
		System.out.println("sGrapp Started at "+dateFormat.format(cal.getTime())+" , "+startTime+" nanosec");
		
		if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while ((sgt = br.readLine()) != null){
			
			vertexI_ID=0;vertexJ_ID=0;e_ij=null;
			columns = getColumns(sgt,separator);
			vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
			vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
			timeStamp=new BigDecimal(columns[stampColumn]).intValue();
			interarrival=0;//timeStamp-previousTimestamp;
			//previousTimestamp=timeStamp;
			
	    	uniquestamps.add(timeStamp);
	    	
	    	e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
			if ( !(slidingBG.IvertexID_JNeighborIDs_HashIndex.containsKey(e_ij.iID) && slidingBG.IvertexID_JNeighborIDs_HashIndex.get(e_ij.iID).contains(e_ij.jID))){ 
				currentEdges.add(e_ij);
				slidingBG.add_IJEdge(e_ij);
				totaledges++;
			}
			edges_currentCount=currentEdges.size();                                   
	    	imap= slidingBG.IvertexID_JNeighborIDs_HashIndex;
	    	jmap= slidingBG.JvertexID_INeighborIDs_HashIndex;
	    	
	    	if (uniquestamps.size()==Ntw) {
	    		identified_cliques.clear();
			
	    	
	    		if (avgIdeg<=avgJdeg) {
	    			ivertices=imap.keySet();
	    			for (Integer vi1 : ivertices) {
	    				i1neighbors=toVector(imap.get(vi1));
	    				i1neighbors_currentSize=i1neighbors.size();
	    				for (int jindex = 0; jindex < i1neighbors_currentSize; jindex++) {
	    					j1=i1neighbors.elementAt(jindex);
	    					i1neighbors_sublist=i1neighbors.subList(jindex+1, i1neighbors_currentSize);
	    					for (Integer vj2 : i1neighbors_sublist) {
	    						i2_vertices=mutualNeighbors(j1,vj2, jmap);i2_vertices.remove(vi1);
	    						i2vertices_size=i2_vertices.size();
	    						if (i2vertices_size!=0) {
	    							for (int vi2 : i2_vertices) {
	    								clique=new HashSet<String>(4);
	    								clique.add("i"+vi1);clique.add("j"+j1);clique.add("i"+vi2);clique.add("j"+vj2);
	    								identified_cliques.add(clique);
	    							} 
	    						}						
	    					}
	    				}		
	    			} 
	    		}
	    		else{
	    			jvertices=jmap.keySet();
		    		for (Integer vj1 : jvertices) {
		    			j1neighbors=toVector(jmap.get(vj1));
		    			j1neighbors_currentSize=j1neighbors.size();
		    			for (int index = 0; index < j1neighbors_currentSize; index++) {
		    				i1=j1neighbors.elementAt(index);
		    				j1neighbors_sublist=j1neighbors.subList(index+1, j1neighbors_currentSize);
		    				for (Integer vi2 : j1neighbors_sublist) {
		    					j2_vertices=mutualNeighbors(i1,vi2,imap);j2_vertices.remove(vj1);
		    					j2vertices_size=j2_vertices.size();
		    					if (j2vertices_size!=0) {
		    						for (int vj2 : j2_vertices) {
		    							clique=new HashSet<String>(4);
		    							clique.add("i"+i1);clique.add("j"+vj1);clique.add("i"+vi2);clique.add("j"+vj2);
		    							identified_cliques.add(clique);
		    						} 
		    					}						
		    				}
		    			}	    		
		    		} 
	    		}
	    		
	    		
	    		Nc_window=identified_cliques.size();
	    		if (winNum>0) {
	    			Nc_cumulative+=Nc_window+(Math.pow(totaledges, exponent));
				}
	    		else{
	    			Nc_cumulative+=Nc_window;
	    		}
	    		
	    		//w.append(t+" "+Nc_cumulative+"\r\n");
	    		
	    		slidingBG=new BipartiteGraph();currentEdges=new Vector<IJ_Edge>();
	    		
	    		
	    		wFinish=System.nanoTime();
	    		wDuration=wFinish-wStartTime;
	    		wStartTime=wFinish;
	    		total=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
	    		
	    		//wUsed=total-wbeforeUsedMem;
	    		//wbeforeUsedMem=wUsed;
	    		//totalMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory()-beforeUsedMem;
	    		/*
	    		System.out.println("\n\nwinNumbwer="+winNum+"   step="+t+"   B="+Nc_cumulative+"   |E(w)|="+edges_currentCount+"      total seen edges=|E(t)|="+totaledges+" - cutoff="+cutoff+
	    				"\ntotal-memory:"+total+"    total-time="+(wFinish-startTime)+"   cumulatiive-throughput:"+(totaledges*1.0)/((wFinish-startTime)/Math.pow(10, 9))+
	    				//"\nwin-memory:"+wUsed+
	    			"\n win-time:"+wDuration+"   win-throughput:"+(edges_currentCount*1.0)/(wDuration/Math.pow(10, 9)));
	    		 */
	    		
	    		//winmem.append(((wUsed*1.0)/(1024.0 * 1024.0))+"\r\n");
	    		
	    		wintime.append(wDuration+"\r\n");
	    		if (Double.isFinite((edges_currentCount*1.0)/(wDuration/Math.pow(10, 9)))) {
					winThru=(long) ((edges_currentCount*1.0)/(wDuration/Math.pow(10, 9)));
				}
	    		winThroughput.append(winThru+"\r\n");
	    		
	    		if (Double.isFinite((totaledges*1.0)/((wFinish-startTime)/Math.pow(10, 9)))) {
	    			thru=(long) ((totaledges*1.0)/((wFinish-startTime)/Math.pow(10, 9)));	    			
				}totalthroughput.append(thru+"\r\n");	    		
	    		
	    		uniquestamps=new HashSet<Integer>();
	    		winNum++;
			}
	    	t++;
		}
		br.close();totalthroughput.close();winThroughput.close();wintime.close();//w.close();//winmem.close();
		
		//long afterUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	//long actualMemUsed=afterUsedMem-beforeUsedMem;
    	long finishTime=System.nanoTime();
		long duration=finishTime-startTime;
		cal = Calendar.getInstance();
		long throughput=(long) ((totaledges*1.0)/((finishTime-startTime)/Math.pow(10, 9)));	
		System.out.println("sGrapp finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" nanosec, duration="+duration+" nanosec  thru="+throughput );
		
    }
    public static void  sGrappx_efficiency(double x, String truth_file, int iteration, double exponent, int startVertexIndexinFile, int stampColumn, String filename, int firstTimestamp, int rows, int avgIdeg, int avgJdeg,String separator, int linebreaks,int Nt, double Ntw) throws NumberFormatException, IOException{
    	PrintWriter //w=new PrintWriter(iteration+" - timestep - approximation - window cutoff="+cutoff+"*"+Nt+" - exponent="+exponent+" - "+filename),
    	winThroughput=new PrintWriter(iteration+" - window throughputs (edge per s) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+filename),
    	wintime=new PrintWriter(iteration+" - window times (ns) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+filename),
    	totalthroughput=new PrintWriter(iteration+" - total throughput (edge per s) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+filename);
    	
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.nanoTime();
		System.out.println("sGrapp-x x="+x+" Started at "+dateFormat.format(cal.getTime())+" , "+startTime+" nanosec");
    	
    	Vector<Integer> groundtruth=readVector(truth_file); int truthSize=(int) (groundtruth.size()*x);
    	double residual=0;
    	
		Map<Integer,HashSet<Integer>> imap, jmap;
		//int previousTimestamp=firstTimestamp;
		int edges_currentCount=0;	
		HashSet<String> clique=new HashSet<String>(4);
		HashSet<HashSet<String>> identified_cliques=new HashSet<HashSet<String>>();
		
		Set<Integer> ivertices, jvertices, i2_vertices, j2_vertices;
		Vector<Integer>  i1neighbors=new Vector<Integer>(), j1neighbors=new Vector<Integer>(); List<Integer> i1neighbors_sublist=new ArrayList<Integer>(), j1neighbors_sublist=new ArrayList<Integer>(); 
		int i1neighbors_currentSize, j1, i2vertices_size, j1neighbors_currentSize, i1, j2vertices_size;
		
		FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		int vertexI_ID,vertexJ_ID,timeStamp, interarrival;
		IJ_Edge e_ij;//,toBeRetired_e;
		String[] columns;
		String sgt;
		HashSet<Integer> uniquestamps=new HashSet<Integer>();
		int winNum=0, t=0;
		
		Vector<IJ_Edge> currentEdges=new Vector<IJ_Edge>();
		
		long Nc_cumulative=0, Nc_window=0;
		
		int totaledges=0;
		BipartiteGraph slidingBG=new BipartiteGraph();
		
		
    	
		long  total, wFinish, wDuration, wStartTime=System.nanoTime(), thru = 0, winThru=0;
		
		if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while ((sgt = br.readLine()) != null){
			vertexI_ID=0;vertexJ_ID=0;e_ij=null;
			columns = getColumns(sgt,separator);
			vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
			vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
			timeStamp=new BigDecimal(columns[stampColumn]).intValue();
			interarrival=0;//timeStamp-previousTimestamp;
			//previousTimestamp=timeStamp;
			
	    	uniquestamps.add(timeStamp);
	    	
	    	e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
			if ( !(slidingBG.IvertexID_JNeighborIDs_HashIndex.containsKey(e_ij.iID) && slidingBG.IvertexID_JNeighborIDs_HashIndex.get(e_ij.iID).contains(e_ij.jID))){ 
				currentEdges.add(e_ij);
				slidingBG.add_IJEdge(e_ij);
				totaledges++;
			}
			edges_currentCount=currentEdges.size();                                   
	    	imap= slidingBG.IvertexID_JNeighborIDs_HashIndex;
	    	jmap= slidingBG.JvertexID_INeighborIDs_HashIndex;
	    	
	    	if (uniquestamps.size()==Ntw) {
	    		identified_cliques.clear();
			
	    	
	    		if (avgIdeg<=avgJdeg) {
	    			ivertices=imap.keySet();
	    			for (Integer vi1 : ivertices) {
	    				i1neighbors=toVector(imap.get(vi1));
	    				i1neighbors_currentSize=i1neighbors.size();
	    				for (int jindex = 0; jindex < i1neighbors_currentSize; jindex++) {
	    					j1=i1neighbors.elementAt(jindex);
	    					i1neighbors_sublist=i1neighbors.subList(jindex+1, i1neighbors_currentSize);
	    					for (Integer vj2 : i1neighbors_sublist) {
	    						i2_vertices=mutualNeighbors(j1,vj2, jmap);i2_vertices.remove(vi1);
	    						i2vertices_size=i2_vertices.size();
	    						if (i2vertices_size!=0) {
	    							for (int vi2 : i2_vertices) {
	    								clique=new HashSet<String>(4);
	    								clique.add("i"+vi1);clique.add("j"+j1);clique.add("i"+vi2);clique.add("j"+vj2);
	    								identified_cliques.add(clique);
	    							} 
	    						}						
	    					}
	    				}		
	    			} 
	    		}
	    		else{
	    			jvertices=jmap.keySet();
		    		for (Integer vj1 : jvertices) {
		    			j1neighbors=toVector(jmap.get(vj1));
		    			j1neighbors_currentSize=j1neighbors.size();
		    			for (int index = 0; index < j1neighbors_currentSize; index++) {
		    				i1=j1neighbors.elementAt(index);
		    				j1neighbors_sublist=j1neighbors.subList(index+1, j1neighbors_currentSize);
		    				for (Integer vi2 : j1neighbors_sublist) {
		    					j2_vertices=mutualNeighbors(i1,vi2,imap);j2_vertices.remove(vj1);
		    					j2vertices_size=j2_vertices.size();
		    					if (j2vertices_size!=0) {
		    						for (int vj2 : j2_vertices) {
		    							clique=new HashSet<String>(4);
		    							clique.add("i"+i1);clique.add("j"+vj1);clique.add("i"+vi2);clique.add("j"+vj2);
		    							identified_cliques.add(clique);
		    						} 
		    					}						
		    				}
		    			}	    		
		    		} 
	    		}
	    		
	    		
	    		Nc_window=identified_cliques.size();
	    		if (winNum>0) {
	    			if (truthSize>t && residual > 0.05) {
						exponent -= 0.005;
					}
	    			if (truthSize>t &&  residual < -0.05) {
						exponent += 0.005;
					}
	    			
	    			Nc_cumulative+=Nc_window+Math.pow(totaledges, exponent );
				}
	    		else{
	    			Nc_cumulative+=Nc_window;
	    		}
	    		if (truthSize>t) {
	    			residual=((Nc_cumulative-groundtruth.elementAt(t))*1.0)/(1.0*groundtruth.elementAt(t));
				}
	    		
	    		//w.append(t+" "+Nc_cumulative+"\r\n");
	    		
	    		slidingBG=new BipartiteGraph();currentEdges=new Vector<IJ_Edge>();
	    		
	    		
	    		wFinish=System.nanoTime();
	    		wDuration=wFinish-wStartTime;
	    		wStartTime=wFinish;
	    		total=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
	    		
	    		
	    		wintime.append(wDuration+"\r\n");
	    		if (Double.isFinite((edges_currentCount*1.0)/(wDuration/Math.pow(10, 9)))) {
					winThru=(long) ((edges_currentCount*1.0)/(wDuration/Math.pow(10, 9)));
				}
	    		winThroughput.append(winThru+"\r\n");
	    		
	    		if (Double.isFinite((totaledges*1.0)/((wFinish-startTime)/Math.pow(10, 9)))) {
	    			thru=(long) ((totaledges*1.0)/((wFinish-startTime)/Math.pow(10, 9)));
	    			
				}totalthroughput.append(thru+"\r\n");
	    		
	    		uniquestamps=new HashSet<Integer>();
	    		winNum++;
			}
	    	t++;
		}
		br.close();winThroughput.close();wintime.close();totalthroughput.close();//w.close();//winmem.close();
		
		long finishTime=System.nanoTime();
		long duration=finishTime-startTime;
		cal = Calendar.getInstance();
		long throughput=(long) ((totaledges*1.0)/((finishTime-startTime)/Math.pow(10, 9)));	
		System.out.println("sGrapp-x x="+x+" finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" millisec, duration="+duration+" millisec thru="+throughput );
		
    }
    
    private static Vector<Vector<Long>>  sGrapp(double exponent, int startVertexIndexinFile, int stampColumn, String filename, int firstTimestamp, int rows, int avgIdeg, int avgJdeg, String separator, int linebreaks,int Nt, double cutoff) throws NumberFormatException, IOException{
    	Map<Integer,HashSet<Integer>> imap, jmap;
		int previousTimestamp=firstTimestamp;
		HashSet<String> clique=new HashSet<String>(4);
		HashSet<HashSet<String>> identified_cliques=new HashSet<HashSet<String>>();
		
		Set<Integer> ivertices, jvertices, i2_vertices, j2_vertices;
		Vector<Integer>  i1neighbors=new Vector<Integer>(), j1neighbors=new Vector<Integer>(); List<Integer> i1neighbors_sublist=new ArrayList<Integer>(), j1neighbors_sublist=new ArrayList<Integer>(); 
		int i1neighbors_currentSize, j1, i2vertices_size, j1neighbors_currentSize, i1, j2vertices_size;
		
		
		//window management
		FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		int vertexI_ID,vertexJ_ID,timeStamp, interarrival;
		IJ_Edge e_ij;
		String[] columns;
		String sgt;
		
		HashSet<Integer> uniquestamps=new HashSet<Integer>();
		int winNum=0, t=1;
		
		
		long Nc_cumulative=0, Nc_window=0;
		Vector<Vector<Long>> step_cumulativeNc=new Vector<Vector<Long>>();
		Vector<Long> temp=new Vector<Long>(2);
		
		int totaledges=0;
		
		BipartiteGraph slidingBG=new BipartiteGraph();
		
		
		if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while ((sgt = br.readLine()) != null){
			
			vertexI_ID=0;vertexJ_ID=0;e_ij=null;
			columns = getColumns(sgt,separator);
			vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
			vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
			timeStamp=new BigDecimal(columns[stampColumn]).intValue();
			interarrival=timeStamp-previousTimestamp;
			previousTimestamp=timeStamp;
			
	    	uniquestamps.add(timeStamp);
	    	
	    	e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
			if ( !(slidingBG.IvertexID_JNeighborIDs_HashIndex.containsKey(e_ij.iID) && slidingBG.IvertexID_JNeighborIDs_HashIndex.get(e_ij.iID).contains(e_ij.jID))){ 
				slidingBG.add_IJEdge(e_ij);
				totaledges++;
			}
			                                 
	    	imap= slidingBG.IvertexID_JNeighborIDs_HashIndex;
	    	jmap= slidingBG.JvertexID_INeighborIDs_HashIndex;
	    	
	    	if (uniquestamps.size()==cutoff) {
	    		identified_cliques.clear();
			
	    	
	    		if (avgIdeg<=avgJdeg) {
	    			ivertices=imap.keySet();
	    			for (Integer vi1 : ivertices) {
	    				i1neighbors=toVector(imap.get(vi1));
	    				i1neighbors_currentSize=i1neighbors.size();
	    				for (int jindex = 0; jindex < i1neighbors_currentSize; jindex++) {
	    					j1=i1neighbors.elementAt(jindex);
	    					i1neighbors_sublist=i1neighbors.subList(jindex+1, i1neighbors_currentSize);
	    					for (Integer vj2 : i1neighbors_sublist) {
	    						i2_vertices=mutualNeighbors(j1,vj2, jmap);i2_vertices.remove(vi1);
	    						i2vertices_size=i2_vertices.size();
	    						if (i2vertices_size!=0) {
	    							for (int vi2 : i2_vertices) {
	    								clique=new HashSet<String>(4);
	    								clique.add("i"+vi1);clique.add("j"+j1);clique.add("i"+vi2);clique.add("j"+vj2);
	    								identified_cliques.add(clique);
	    							} 
	    						}						
	    					}
	    				}		
	    			} 
	    		}
	    		else{
	    			jvertices=jmap.keySet();
		    		for (Integer vj1 : jvertices) {
		    			j1neighbors=toVector(jmap.get(vj1));
		    			j1neighbors_currentSize=j1neighbors.size();
		    			for (int index = 0; index < j1neighbors_currentSize; index++) {
		    				i1=j1neighbors.elementAt(index);
		    				j1neighbors_sublist=j1neighbors.subList(index+1, j1neighbors_currentSize);
		    				for (Integer vi2 : j1neighbors_sublist) {
		    					j2_vertices=mutualNeighbors(i1,vi2,imap);j2_vertices.remove(vj1);
		    					j2vertices_size=j2_vertices.size();
		    					if (j2vertices_size!=0) {
		    						for (int vj2 : j2_vertices) {
		    							clique=new HashSet<String>(4);
		    							clique.add("i"+i1);clique.add("j"+vj1);clique.add("i"+vi2);clique.add("j"+vj2);
		    							identified_cliques.add(clique);
		    						} 
		    					}						
		    				}
		    			}	    		
		    		} 
	    		}
	    		
	    		
	    		Nc_window=identified_cliques.size();
	    		if (winNum>0) {
	    			Nc_cumulative+=Nc_window+Math.pow(totaledges, exponent );//(Math.pow(totaledges, 1.0/Math.pow(exponent,winNum) ));
				}
	    		else{
	    			Nc_cumulative+=Nc_window;
	    		}
	    		
	    		temp=new Vector<Long>(2);temp.add( Long.valueOf(t));temp.add(Nc_cumulative);
	    		step_cumulativeNc.add(temp);
	    		//System.out.println("step="+t+" Bw="+Nc_window+" |E|="+totaledges+" approximation="+Nc_cumulative);
	    		
	    		
	    		//delete the retired edges
	    		slidingBG=new BipartiteGraph();
	    		
	    		uniquestamps=new HashSet<Integer>();
	    		winNum++;
			}
	    	t++;
		}
		br.close();
		//System.out.println("step="+t+" B="+Nc_cumulative);
		
		return step_cumulativeNc;
    }
    private static Vector<Vector<Long>>  sGrappx(double truthPercentage, String truth_file, double exponent, int startVertexIndexinFile, int stampColumn, String filename, int firstTimestamp, int lastTimestep, int rows, int avgIdeg, int avgJdeg, String separator, int linebreaks,int Nt, int cutoff) throws NumberFormatException, IOException{
    	long beforeUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.nanoTime();
		System.out.println("sGrapp"+truthPercentage+" Started at "+dateFormat.format(cal.getTime())+" , "+startTime+" nanosec");
    	
    	Vector<Integer> groundtruth=readVector(truth_file); int truthSize=(int) (groundtruth.size()*truthPercentage); //System.out.println("truth size="+truthSize+" ");
    	double residual=0;
    	
    	Map<Integer,HashSet<Integer>> imap, jmap;
		int previousTimestamp=firstTimestamp;
		//int edges_currentCount=0;	
		HashSet<String> clique=new HashSet<String>(4);
		HashSet<HashSet<String>> identified_cliques=new HashSet<HashSet<String>>();
		
		Set<Integer> ivertices, jvertices, i2_vertices, j2_vertices;
		Vector<Integer>  i1neighbors=new Vector<Integer>(), j1neighbors=new Vector<Integer>(); List<Integer> i1neighbors_sublist=new ArrayList<Integer>(), j1neighbors_sublist=new ArrayList<Integer>(); 
		int i1neighbors_currentSize, j1, i2vertices_size, j1neighbors_currentSize, i1, j2vertices_size;
		
		
		//window management
		FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		int vertexI_ID,vertexJ_ID,timeStamp, interarrival;
		IJ_Edge e_ij;//,toBeRetired_e;
		String[] columns;
		String sgt;
		
		HashSet<Integer> uniquestamps=new HashSet<Integer>();
		//int Wb=firstTimestamp;
		int winNum=0, t=1;
		
		//Vector<IJ_Edge> currentEdges=new Vector<IJ_Edge>();
		//Vector<IJ_Edge> retiredEdges=new Vector<IJ_Edge>();
		
		long Nc_cumulative=0, Nc_window=0;
		Vector<Vector<Long>> step_cumulativeNc=new Vector<Vector<Long>>();
		Vector<Long> temp=new Vector<Long>(2);
		
		//int vi_degree=0,vj_degree=0; 
		int totaledges=0;
		
		BipartiteGraph slidingBG=new BipartiteGraph();
		
		
		if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while ((sgt = br.readLine()) != null && t<=lastTimestep){
			//ingest sgt
			vertexI_ID=0;vertexJ_ID=0;e_ij=null;
			columns = getColumns(sgt,separator);
			vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
			vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
			timeStamp=new BigDecimal(columns[stampColumn]).intValue();
			interarrival=timeStamp-previousTimestamp;
			previousTimestamp=timeStamp;
			
	    	uniquestamps.add(timeStamp);
	    	
	    	//update the graph
	    	e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
			if ( !(slidingBG.IvertexID_JNeighborIDs_HashIndex.containsKey(e_ij.iID) && slidingBG.IvertexID_JNeighborIDs_HashIndex.get(e_ij.iID).contains(e_ij.jID))){ 
				//currentEdges.add(e_ij);
				slidingBG.add_IJEdge(e_ij);
				totaledges++;
			}
			//edges_currentCount=currentEdges.size();                                   
	    	imap= slidingBG.IvertexID_JNeighborIDs_HashIndex;
	    	jmap= slidingBG.JvertexID_INeighborIDs_HashIndex;
	    	
	    	if (uniquestamps.size()==cutoff) {//System.out.println("\n step="+t+" -  W="+winNum+" |E(w)|="+edges_currentCount+"   -  total seen edges=|E(t)|="+totaledges+" - cutoff="+cuttOf);
	    		identified_cliques.clear();
			
	    	
	    		if (avgIdeg<=avgJdeg) {
	    			ivertices=imap.keySet();
	    			for (Integer vi1 : ivertices) {
	    				i1neighbors=toVector(imap.get(vi1));
	    				i1neighbors_currentSize=i1neighbors.size();
	    				for (int jindex = 0; jindex < i1neighbors_currentSize; jindex++) {//for each pair of i1's neighbors <j1,j2>, the mutual neighbors of j1 and j2 form a butterfly
	    					j1=i1neighbors.elementAt(jindex);
	    					i1neighbors_sublist=i1neighbors.subList(jindex+1, i1neighbors_currentSize);
	    					for (Integer vj2 : i1neighbors_sublist) {
	    						i2_vertices=mutualNeighbors(j1,vj2, jmap);i2_vertices.remove(vi1);
	    						i2vertices_size=i2_vertices.size();
	    						if (i2vertices_size!=0) {
	    							for (int vi2 : i2_vertices) {
	    								clique=new HashSet<String>(4);
	    								clique.add("i"+vi1);clique.add("j"+j1);clique.add("i"+vi2);clique.add("j"+vj2);
	    								identified_cliques.add(clique);
	    							} 
	    						}						
	    					}
	    				}		
	    			} 
	    		}
	    		else{
	    			jvertices=jmap.keySet();
		    		for (Integer vj1 : jvertices) {
		    			j1neighbors=toVector(jmap.get(vj1));
		    			j1neighbors_currentSize=j1neighbors.size();
		    			for (int index = 0; index < j1neighbors_currentSize; index++) {//for each pair of j1's neighbors <i1,i2>, the mutual j-neighbors of i1 and i2 form a butterfly
		    				i1=j1neighbors.elementAt(index);
		    				j1neighbors_sublist=j1neighbors.subList(index+1, j1neighbors_currentSize);
		    				for (Integer vi2 : j1neighbors_sublist) {
		    					j2_vertices=mutualNeighbors(i1,vi2,imap);j2_vertices.remove(vj1);
		    					j2vertices_size=j2_vertices.size();
		    					if (j2vertices_size!=0) {
		    						for (int vj2 : j2_vertices) {
		    							clique=new HashSet<String>(4);
		    							clique.add("i"+i1);clique.add("j"+vj1);clique.add("i"+vi2);clique.add("j"+vj2);
		    							identified_cliques.add(clique);
		    						} 
		    					}						
		    				}
		    			}	    		
		    		} 
	    		}
	    		
	    		
	    		Nc_window=identified_cliques.size();
	    		if (winNum>0) {
	    			
	    			if (truthSize>t && residual > 0.05) {
						exponent -= 0.005;
					}
	    			if (truthSize>t &&  residual < -0.05) {
						exponent += 0.005;
					}
	    			
	    			Nc_cumulative+=Nc_window+Math.pow(totaledges, exponent );//(Math.pow(totaledges, 1.0/Math.pow(exponent,winNum) ));
				}
	    		else{
	    			Nc_cumulative+=Nc_window;
	    		}
	    		
	    		temp=new Vector<Long>(2);temp.add( Long.valueOf(t));temp.add(Nc_cumulative);
	    		step_cumulativeNc.add(temp);
	    		
	    		if (truthSize>t) {
	    			residual=((Nc_cumulative-groundtruth.elementAt(t))*1.0)/(1.0*groundtruth.elementAt(t));
	    			//System.out.println("t="+t+" exponent="+exponent+
	    					//" Bw="+Nc_window+"|E(w)|="+slidingBG.edgeIDs_IJedges.size()+" |E|="+totaledges+" |E(w)|/|E|="+slidingBG.edgeIDs_IJedges.size()*1.0/totaledges*1.0+
	    					//"  approximation="+Nc_cumulative+" B="+Nc_cumulative +" truth="+groundtruth.elementAt(t)+
	    					//" residual="+residual);	    			
				}
	    		
	    		
	    		//slide window
	    		//Wb=timeStamp;
	    		
	    		//delete the retired edges
	    		slidingBG=new BipartiteGraph();
	    		/*
	    		edges_currentCount=currentEdges.size();
	    		for (int i = 0; i < edges_currentCount; i++) {
					toBeRetired_e=currentEdges.elementAt(i);
	    			if (toBeRetired_e.timeStamp<=Wb){
	    				slidingBG.remove_IJedge(toBeRetired_e);
						retiredEdges.add(toBeRetired_e);
					}
				}
	    		for (IJ_Edge e : retiredEdges) {
	    			currentEdges.remove(e);
				}*/
	    		
	    		uniquestamps=new HashSet<Integer>();
	    		winNum++;
			}
	    	t++;
		}
		br.close();
		//System.out.println("step="+t+" B="+Nc_cumulative);
		

		long afterUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	long actualMemUsed=afterUsedMem-beforeUsedMem;
    	long finishTime=System.currentTimeMillis();
		long duration=finishTime-startTime;
		long thru=(long) ((lastTimestep*1.0)/((duration)/Math.pow(10, 9)));
		cal = Calendar.getInstance();
		System.out.println("sGrapp"+truthPercentage+" finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" nanosec   duration="+duration+" nanoec     memory usage:"+actualMemUsed+" |E|="+lastTimestep+" throughput="+thru );
		
		return step_cumulativeNc;
    }
    public static Vector<Long> readvector(String file, String separator, int linebreaks) throws IOException{
    	FileInputStream fstream = new FileInputStream(file);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
    	String line;
    	Vector<Long> v=new Vector<Long>();
    	
    	while ((line = br.readLine())!=null) {
			v.add(Long.parseLong(line));
		}
    	br.close();	
    	return v;
    }
    public static void sGrappx_average_efficincy(double x, String truth_file, int windowscount, int iterations, double exponent, int startVertexIndexinFile, int stampColumn, String datafilename, int firstTimestamp, int rows, int avgIdeg, int avgJdeg,String separator, int linebreaks,int Nt, double Ntw) throws NumberFormatException, IOException{
    	
    	for (int i = 0; i < iterations; i++) {
    		sGrappx_efficiency(x, truth_file, i, exponent, startVertexIndexinFile, stampColumn, datafilename, firstTimestamp, rows, avgIdeg, avgJdeg, separator, linebreaks, Nt, Ntw);
		}
    	
    	Vector<Long> wthru=new Vector<Long>(), thru=new Vector<Long>(), wlatency=new Vector<Long>();
    	
    	
    	Long[] avgwthru=new Long[windowscount], avgthru=new Long[windowscount], avgwlatency=new Long[windowscount];
    	for (int j = 0; j < windowscount; j++) {
			avgwthru[j]=Long.valueOf(0);
			avgthru[j]=Long.valueOf(0);;
			avgwlatency[j]=Long.valueOf(0);
		}
    	for (int i = 0; i < iterations; i++) {
			wthru=readvector(i+" - window throughputs (edge per s) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+datafilename, separator, linebreaks);
			thru=readvector(i+" - total throughput (edge per s) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+datafilename, separator, linebreaks);
			wlatency=readvector(i+" - window times (ns) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+datafilename, separator, linebreaks);
			
			
			for (int j = 0; j < windowscount; j++) {
				avgwthru[j]+=new Long(wthru.elementAt(j));
				avgthru[j]+=thru.elementAt(j);
				avgwlatency[j]+=wlatency.elementAt(j);
			}
		}
    	for (int j = 0; j < windowscount; j++) {
			avgwthru[j]/=iterations;
			avgthru[j]/=iterations;
			avgwlatency[j]/=iterations;
		}
    	
    	PrintWriter winThroughput=new PrintWriter("avg window throughputs (edge per s) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+datafilename),
    	wintime=new PrintWriter("avg window times (ns) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+datafilename),
    	totalthroughput=new PrintWriter("avg total throughput (edge per s) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+datafilename);
    	
    	for (int j = 0; j < windowscount; j++) {
    		winThroughput.append(avgwthru[j]+"\r\n");
    		totalthroughput.append(avgthru[j]+"\r\n");
    		wintime.append(avgwlatency[j]+"\r\n");
    	}
    	winThroughput.close();totalthroughput.close();
    	wintime.close();
    	
    }
    public static void sGrapp_average_efficincy(int windowscount, int iterations, double exponent, int startVertexIndexinFile, int stampColumn, String datafilename, int firstTimestamp, int rows, int avgIdeg, int avgJdeg,String separator, int linebreaks,int Nt, double Ntw) throws NumberFormatException, IOException{
    	
    	for (int i = 0; i < iterations; i++) {
    		sGrapp_efficiency(i, exponent, startVertexIndexinFile, stampColumn, datafilename, firstTimestamp, rows, avgIdeg, avgJdeg, separator, linebreaks, Nt, Ntw);
		}
    	
    	Vector<Long> wthru=new Vector<Long>(), thru=new Vector<Long>(), wlatency=new Vector<Long>();
    	
    	
    	Long[] avgwthru=new Long[windowscount], avgthru=new Long[windowscount], avgwlatency=new Long[windowscount];
    	for (int j = 0; j < windowscount; j++) {
			avgwthru[j]=Long.valueOf(0);
			avgthru[j]=Long.valueOf(0);;
			avgwlatency[j]=Long.valueOf(0);
		}
    	for (int i = 0; i < iterations; i++) {
			wthru=readvector(i+" - window throughputs (edge per s) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+datafilename, separator, linebreaks);
			thru=readvector(i+" - total throughput (edge per s) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+datafilename, separator, linebreaks);
			wlatency=readvector(i+" - window times (ns) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+datafilename, separator, linebreaks);
			
			
			for (int j = 0; j < windowscount; j++) {
				avgwthru[j]+=new Long(wthru.elementAt(j));
				avgthru[j]+=thru.elementAt(j);
				avgwlatency[j]+=wlatency.elementAt(j);
			}
		}
    	for (int j = 0; j < windowscount; j++) {
			avgwthru[j]/=iterations;
			avgthru[j]/=iterations;
			avgwlatency[j]/=iterations;
		}
    	
    	PrintWriter winThroughput=new PrintWriter("avg window throughputs (edge per s) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+datafilename),
    	wintime=new PrintWriter("avg window times (ns) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+datafilename),
    	totalthroughput=new PrintWriter("avg total throughput (edge per s) - window cutoff="+Ntw+"*"+Nt+" - exponent="+exponent+" - "+datafilename);
    	
    	for (int j = 0; j < windowscount; j++) {
    		winThroughput.append(avgwthru[j]+"\r\n");
    		totalthroughput.append(avgthru[j]+"\r\n");
    		wintime.append(avgwlatency[j]+"\r\n");
    	}
    	winThroughput.close();totalthroughput.close();
    	wintime.close();
    	
    }
    
    //MAPE for 3d and relative error
    private static Vector<Integer> readVector(String FileName) throws IOException{
		FileInputStream fstream = new FileInputStream(FileName);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		String line; 
		Vector<Integer> matrix=new Vector<Integer>(); 
		while((line= br.readLine())!=null) {
			matrix.add(Integer.parseInt(line));	    
		}
		br.close();
		return matrix;
	}
    private static double MAPE(Vector<Integer> truth, Vector<Vector<Long>> index_approximation){
    	int n=index_approximation.size(); int n2=0;
    	double mape=0;int index=0;
    	double residual=0;
    	for (int i = 0; i < n; i++) {
    		index=index_approximation.elementAt(i).elementAt(0).intValue();
    		if (truth.size()<=index) {
				break;
			}
    		n2++;
    		
    		residual=(Math.abs(truth.elementAt(index)-index_approximation.elementAt(i).elementAt(1))*1.0)/(1.0*truth.elementAt(index));
    		if (residual>0 && residual!=Double.POSITIVE_INFINITY && residual!=Double.NEGATIVE_INFINITY) {
    			mape+=residual;
    		}
			
			//System.out.println("i="+i+" index="+index+" - truth="+truth.elementAt(index)+"  -  approximation="+index_approximation.elementAt(i).elementAt(1)+"  residual:"+residual);
		}//System.out.println(mape+" /"+n2+"="+mape/(n2*1.0));
		mape/=(n2*1.0);//System.out.println("MAPE="+mape);
    	
		System.out.print("mape over "+n2+" windows!!!!----------------> "+mape);
		
		return mape;
    }  
    private static void write_relativeError_ofeachWindow(Vector<Integer> truth, Vector<Vector<Long>> index_approximation, String filename, double exponent, int cutoff) throws FileNotFoundException{
    	PrintWriter w=new PrintWriter( "timestep-realtive error - "+filename+" exponent="+exponent+" Ntw="+cutoff);
    	int n=index_approximation.size(); int n2=0;
    	double mape=0;int index=0;
    	double residual=0;
    	for (int i = 0; i < n; i++) {
    		index=index_approximation.elementAt(i).elementAt(0).intValue();
    		if (truth.size()<=index) {
				break;
			}
    		n2++;
    		if (truth.elementAt(index)!=0) {
    			residual=((index_approximation.elementAt(i).elementAt(1)-truth.elementAt(index))*1.0)/(1.0*truth.elementAt(index));
			}
    		
    		if (residual!=Double.POSITIVE_INFINITY && residual!=Double.NEGATIVE_INFINITY) {
    			w.append(index+" "+residual+"\r\n");
    			mape+=Math.abs(residual);
    		}
    		
			System.out.println("i="+i+" index=t="+index+" - truth="+truth.elementAt(index)+"  -  approximation="+index_approximation.elementAt(i).elementAt(1)+"  residual:"+residual);
		}mape/=(n2*1.0);System.out.println("MAPE="+mape);
		w.close();
    }
    //3d MAPE - set for loop boundries, select sGrapp or sGrappx
    public static void writeMAPE(double x, String truth_file, int startVertexIndexinFile, int stampColumn, String filename, int firstTimestamp, int lastTimestep, int rows, int avgIdeg, int avgJdeg,String separator, int linebreaks,int Nt) throws IOException{
    
    	PrintWriter w=new PrintWriter( "75semisupervised- |E|=tl - exponent(tl) - windowPercentage - MAPE - "+filename);
    	long beforeUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.currentTimeMillis();
		System.out.println("\npre-process() started at "+dateFormat.format(cal.getTime())+" , "+startTime+" millisec\n");
		
		Vector<Double> exponents=new Vector<Double>();	
    	for (double i = 1.36; i <= 1.45; i=i+0.001) {
    		exponents.add(i);
		}
    	
    	long finishTime=System.currentTimeMillis();
		long duration=finishTime-startTime;
		cal = Calendar.getInstance();
		System.out.println("pre-process() finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" millisec, duration="+duration+" millisec" );
    	System.out.println();
    	
    	double exponent;
    	Vector<Vector<Long>> index_approximation;
    	double temp_MAPE=0;
    	
    	Vector<Integer> groundtruth=readVector(truth_file);
    	
    	dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		cal = Calendar.getInstance();
		startTime=System.currentTimeMillis();
		System.out.println("\nlearn() started at "+dateFormat.format(cal.getTime())+" , "+startTime+" millisec\n");
		
		int s=exponents.size();
    	for (int j = 0; j < s; j++) {
			exponent=exponents.elementAt(j);
			
			for (int Ntw = 469; Ntw <=961 ; Ntw+=49) {
				//index_approximation=sGrappx(x,truth_file, exponent, startVertexIndexinFile, stampColumn, filename, firstTimestamp, lastTimestep, rows, avgIdeg, avgJdeg, separator, linebreaks, Nt, Ntw);
				index_approximation=sGrapp(exponent, startVertexIndexinFile, stampColumn, filename, firstTimestamp, rows, avgIdeg, avgJdeg, separator, linebreaks, Nt, Ntw);
				temp_MAPE=MAPE(groundtruth, index_approximation);
				w.append(temp_MAPE+" ");    System.out.println("exponent="+exponent+" - |N_t^W|="+Ntw+" - MAPE="+temp_MAPE);
				
			}w.append("\r\n");
			
		}
    	w.close();
    	
    	long afterUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	long actualMemUsed=afterUsedMem-beforeUsedMem;
    	finishTime=System.currentTimeMillis();
		duration=finishTime-startTime;
		cal = Calendar.getInstance();
		System.out.println("\n\nlearn() finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" millisec, duration="+duration+" millisec+   memory usage:"+actualMemUsed );
    }
    //select sGrapp or sGrappx
    public static void WriteRelativeError(double x, String truth_file, int startVertexIndexinFile, int stampColumn, String filename, int firstTimestamp, int lastTimestep, int rows, int avgIdeg, int avgJdeg,String separator, int linebreaks,int Nt, double exponent, int cutoff) throws IOException{
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.currentTimeMillis();
		System.out.println("\nWriteRelativeError() started at "+dateFormat.format(cal.getTime())+" , "+startTime+" millisec\n");
		
    	Vector<Vector<Long>> index_approximation;
    	Vector<Integer> truth=readVector(truth_file);
    	index_approximation=sGrappx(x,truth_file, exponent, startVertexIndexinFile, stampColumn, filename, firstTimestamp, lastTimestep, rows, avgIdeg, avgJdeg, separator, linebreaks, Nt, cutoff);
    	//index_approximation=sGrapp(exponent, startVertexIndexinFile, stampColumn, filename, firstTimestamp, rows, avgIdeg, avgJdeg, separator, linebreaks, Nt, Ntw);
    	write_relativeError_ofeachWindow(truth, index_approximation, filename, exponent, cutoff);
    	
    	long finishTime=System.currentTimeMillis();
		long duration=finishTime-startTime;
		cal = Calendar.getInstance();
		System.out.println("\n\nWriteRelativeError() finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" millisec, duration="+duration+" millisec" );
    }
    
    private static double fractionOfEdgesConnecctedto_iHubs(BipartiteGraph bg, int hubdegreeThreshold){
    	int E=bg.edgeIDs_IJedges.size();
    	
    	//int[] idegree=bg.iDegree;
    	double fractionofedgesconnectedto_iHubs=0;
    	int sum=0;
    	int Ni=bg.IvertexID_JNeighborIDs_HashIndex.size();//idegree.length;
    	int ideg;
    	////////////////////////////////////////////bg.ihubs=new Vector<Integer>();
    	Set<Integer> ivertices=bg.IvertexID_JNeighborIDs_HashIndex.keySet();
    	bg.ihubs=new HashSet<Integer>();    	
    	for (Integer i : ivertices) {
		//for (int i = 0; i < Ni; i++) {System.out.print("\ndeg["+i+"]="+bg.IvertexID_JNeighborIDs_HashIndex.get(i).size()); 
			ideg=bg.IvertexID_JNeighborIDs_HashIndex.get(i).size();                 //idegree[i];            
			
			if (ideg>=hubdegreeThreshold) {
				if (bg.ihubs.contains(i)) {
					sum++;
				}
				else{
					sum+=ideg;
					bg.ihubs.add(i);
				}
				          // System.out.print(" --> added to i-hubs  --- sum="+sum);				
			}			
		}
    	fractionofedgesconnectedto_iHubs=(1.0*sum)/E; //(E*bg.ihubs.size());
    	//System.out.println("\nihubs:"+bg.ihubs);//+"- Normalized fraction of edges connected to i-hubs (i.e. i-vertioces with deg>"+hubdegreeThreshold+") = "+fractionofedgesconnectedto_iHubs);   	
    	return fractionofedgesconnectedto_iHubs;
    }
    private static double fractionOfEdgesConnecctedto_jHubs(BipartiteGraph bg, int hubdegreeThreshold){
    	int E=bg.edgeIDs_IJedges.size();
    	//int[] jdegree=bg.jDegree;
    	double fractionofedgesconnectedto_jHubs=0;
    	int sumj=0;
    	int jdeg;
    	int Nj=bg.JvertexID_INeighborIDs_HashIndex.size();//jdegree.length;
    	bg.jhubs=new HashSet<Integer>();
    	Set<Integer>jvertices=bg.JvertexID_INeighborIDs_HashIndex.keySet();
    	for (Integer j : jvertices) {
    	//for (int i = 0; i < Nj; i++) {
    		jdeg=bg.JvertexID_INeighborIDs_HashIndex.get(j).size();//jdegree[i]; 
    		
    		if (jdeg>=hubdegreeThreshold) {
				if (bg.jhubs.contains(j)) {
					sumj++;
				}
				else{
					sumj+=jdeg;
					bg.jhubs.add(j);
				}
				         
			}
		}
    	fractionofedgesconnectedto_jHubs=(1.0*sumj)/E; //(E*bg.jhubs.size());
    	//System.out.println("\njhubs:"+bg.jhubs);//+" - Normalized fraction of edges connected to j-hubs (i.e. i-vertioces with deg>"+hubdegreeThreshold+")  = "+fractionofedgesconnectedto_jHubs);
    	return fractionofedgesconnectedto_jHubs;
    }
    public static void plot_evolutionOf_edgesConnectedto_iHubs_and_jHubs(int startVertexIndexinFile, String filename, int stampColumn, int ihubdegreeThreshold, int jhubdegreeThreshold, int firstTimestamp,String separator, int linebreaks) throws IOException{
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.currentTimeMillis();
		System.out.println("\nplot_evolutionOf_edgesConnectedto_iHubs_and_jHubs() started at "+dateFormat.format(cal.getTime())+" , "+startTime+" millisec");
		/*
    	Plot plot1=new Plot();
		plot1.setTitle("Evolution of i-Hub connectivity - degree[iHub]>="+ihubdegreeThreshold+" - "+filename);
		plot1.setYLabel("fraction of edges connected to i-Hubs at time-step t");
		plot1.setXLabel("time-step t");
		plot1.setMarksStyle("dots");
		
		Plot plot2=new Plot();
		plot2.setTitle("Evolution of j-Hub connectivity - degree[jHub]>="+jhubdegreeThreshold+" - "+filename);
		plot2.setYLabel("fraction of edges connected to j-Hubs at time-step t");
		plot2.setXLabel("time-step t");
		plot2.setMarksStyle("dots");
		
		Plot plot3=new Plot();
		plot3.setTitle("Evolution of the number of i-Hub - degree[jHub]>="+ihubdegreeThreshold+" - "+filename);
		plot3.setYLabel("Count(i-Hubs) at t");
		plot3.setXLabel("time-step t");
		plot3.setMarksStyle("dots");
		
		Plot plot4=new Plot();
		plot4.setTitle("Evolution of the number of j-Hub - degree[jHub]>="+jhubdegreeThreshold+" - "+filename);
		plot4.setYLabel("Count(j-Hubs) at t");
		plot4.setXLabel("time-step t");
		plot4.setMarksStyle("dots");
		*/
		Plot plot11=new Plot();
		plot11.setTitle("Evolution of average i-Hub normalized degree - degree[iHub]>="+ihubdegreeThreshold+" - "+filename);
		plot11.setYLabel("fraction of edges connected to i-Hubs / N_ihubs");
		plot11.setXLabel("time-step t");
		plot11.setMarksStyle("dots");
		
		Plot plot12=new Plot();
		plot12.setTitle("Evolution of average j-Hub normalized degree - degree[jHub]>="+jhubdegreeThreshold+" - "+filename);
		plot12.setYLabel("fraction of edges connected to j-Hubs / N_jhubs");
		plot12.setXLabel("time-step t");
		plot12.setMarksStyle("dots");
    	
		
		PrintWriter //wi = null, wj = null,//wfi = null, wfj = null, 
				wnfi = null, wnfj = null;
    	
    	try {
    		//wi=new PrintWriter("Number of ihubs with deg>"+ihubdegreeThreshold+"-"+filename); 
    		//wj=new PrintWriter("Number of jhubs with deg>"+jhubdegreeThreshold+"-"+filename); 
    		//wfi=new PrintWriter("fracyion of ihubs with deg>"+ihubdegreeThreshold+"-"+filename); 
    		//wfj=new PrintWriter("fracyion of jhubs with deg>"+jhubdegreeThreshold+"-"+filename); 
    		wnfi=new PrintWriter("normalized fracyion of ihubs with deg>"+ihubdegreeThreshold+"-"+filename); 
    		wnfj=new PrintWriter("normalized fracyion of jhubs with deg>"+ihubdegreeThreshold+"-"+filename); 
    		//w2=new PrintWriter(fileName+"-y");   
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		double ihubCount=0, jhubcount=0, ifr=0,jfr=0, normalizedifr, normalizedjfr;
    	BipartiteGraph BG=new BipartiteGraph();
		
		FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
    	
		int vertexI_ID,vertexJ_ID,timeStamp, timestep=0, interarrival;
		IJ_Edge e_ij;
		String line;
		String[] columns;
		int previousTimestamp=firstTimestamp;
		
		if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while ((line = br.readLine()) != null) {
			vertexI_ID=0;vertexJ_ID=0;e_ij=null;
			columns = getColumns(line,separator);
			vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;//Integer.parseInt(columns[0])-1;
			vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;//Integer.parseInt(columns[1])-1;
			timeStamp=new BigDecimal(columns[stampColumn]).intValue()-startVertexIndexinFile;//Integer.parseInt(columns[stampColumn]);	
			interarrival=timeStamp-previousTimestamp;
			previousTimestamp=timeStamp;
			e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
			BG.add_IJEdge(e_ij);
			
			ifr=fractionOfEdgesConnecctedto_iHubs(BG, ihubdegreeThreshold);ihubCount=BG.ihubs.size();normalizedifr=ifr/ihubCount;
			if (ihubCount!=0) {
				//plot1.addPoint(0, timestep, ifr, false);wfi.append(timestep+" "+ifr+"\r\n");
				//plot3.addPoint(0, timestep, ihubCount, false);  wi.append(timestep+" "+ihubCount+"\r\n");	
				plot11.addPoint(0, timestep, normalizedifr, false);wnfi.append(timestep+" "+normalizedifr+"\r\n");
			}
			
			jfr=fractionOfEdgesConnecctedto_jHubs(BG, jhubdegreeThreshold);jhubcount=BG.jhubs.size();normalizedjfr=jfr/jhubcount;
			if (jhubcount!=0) {
				//plot2.addPoint(0, timestep, jfr, false);wfj.append(timestep+" "+jfr+"\r\n");
				//plot4.addPoint(0, timestep, jhubcount, false);  wj.append(timestep+" "+jhubcount+"\r\n");
				plot12.addPoint(0, timestep, normalizedjfr, false);wnfj.append(timestep+" "+normalizedjfr+"\r\n");
			}
			
			
			/*if (jfr>0) {
				System.out.print("\nt="+timestep+" e:"+e_ij.ID+" normalized fraction of edges connected to iHubs="+ifr+"  j-hubs fraction="+jfr);
			}*/
			
			//System.out.println("t="+timestep);
			
			timestep++;
		}		
		br.close();wnfi.close(); wnfj.close();//wfi.close(); wfj.close();wi.close(); wj.close(); 
		//new PlotApplication(plot1);	new PlotApplication(plot2);	
		//new PlotApplication(plot3); new PlotApplication(plot4);		
		new PlotApplication(plot11); new PlotApplication(plot12);
		
		System.out.print("\nt="+timestep+" fraction of edges connected to iHubs="+ifr+"  j-hubs fraction="+jfr);
		
		long finishTime=System.currentTimeMillis();
		long duration=finishTime-startTime;
		cal = Calendar.getInstance();
		System.out.println("\n\nplot_evolutionOf_edgesConnectedto_iHubs_and_jHubs() finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" millisec, duration="+duration+" millisec" );	
    }
    
    //in each window detect the young hubs as the vertices whose degrees is in top 10 percentile and their timestamp is also in last percentile 
    private static double mean(Set<Integer> a){
    	double m=0;
    	for (Integer e : a) {
			m+=e;
		}
    	return (m*1.0)/a.size();
    }
    public static void windowed_young_old_iHubs_jHubs(int Nt, int startVertexIndexinFile, int stampColumn,String filename, int t0, int Ni, int Nj, String separator, int linebreaks, int timestamptopPercent) throws IOException{
    	PrintWriter //wi = null, wj=null,
    			wiyoung=null, wjyoung=null, wiold=null, wjold=null;
    	
    	FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
    	String line;
		String[] columns;
		
		Plot plot1000=new Plot();
		plot1000.setTitle("degree of i-vertices");
		plot1000.setYLabel("idegree");
		plot1000.setXLabel("i-vertex");
		plot1000.setMarksStyle("dots");
		
		Plot plot010=new Plot();
		plot010.setTitle("degree of j-vertices");
		plot010.setYLabel("jdegree");
		plot010.setXLabel("j-vertex");
		plot010.setMarksStyle("dots");
		
		Plot plot10=new Plot();
		plot10.setTitle("number of ihubs after applying each window");
		plot10.setYLabel("number of iHubs");
		plot10.setXLabel("window number");
		plot10.setMarksStyle("dots");
		
		Plot plot100=new Plot();
		plot100.setTitle("number of jhubs after applying each window");
		plot100.setYLabel("number of jHubs");
		plot100.setXLabel("window number");
		plot100.setMarksStyle("dots");
		
		Plot plot1=new Plot();
		plot1.setTitle("number of young ihubs after applying each window");
		plot1.setYLabel("number of young iHubs");
		plot1.setXLabel("window number");
		plot1.setMarksStyle("dots");
		
		Plot plot11=new Plot();
		plot11.setTitle("number of young jhubs after applying each window");
		plot11.setYLabel("number of young jHubs");
		plot11.setXLabel("window number");
		plot11.setMarksStyle("dots");
		
		Plot plot2=new Plot();
		plot2.setTitle("number of old ihubs after applying each window");
		plot2.setYLabel("number of old iHubs");
		plot2.setXLabel("window number");
		plot2.setMarksStyle("dots");
		
		Plot plot22=new Plot();
		plot22.setTitle("number of old jhubs after applying each window");
		plot22.setYLabel("number of old jHubs");
		plot22.setXLabel("window number");
		plot22.setMarksStyle("dots");
		
		try {
			//wi=new PrintWriter("number of ihubs in windows of "+filename);	
			//wj=new PrintWriter("number of jhubs in windows of "+filename);	
			wiold=new PrintWriter("number of old ihubs in windows of "+filename);	
			wjold=new PrintWriter("number of old jhubs in windows of "+filename);	
			wiyoung=new PrintWriter("number of young ihubs in windows of "+filename);	
			wjyoung=new PrintWriter("number of young jhubs in windows of "+filename);	
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		int WindowInitialt=t0, k=1, timestep=0,interarrival,previousTimestamp=t0,vertexI_ID, vertexJ_ID, timeStamp;
		//Vector<IJ_Edge> edges=new Vector<IJ_Edge>();
		IJ_Edge e_ij;
		BipartiteGraph BG=new BipartiteGraph();
		BG.ivertices=new HashSet<Vertex>(); BG.jvertices=new HashSet<Vertex>();
		
		Set<Integer> unique_idegrees=new HashSet<Integer>(), unique_jdegrees=new HashSet<Integer>();
		double avgIdeg=0, avgJdeg=0;
		int[] iDegrees=new int[Ni];
		int[] jDegrees=new int[Nj];
		
		Map<Integer,Integer> i_ID_index=new HashMap<Integer,Integer>();
		Map<Integer,Integer> j_ID_index=new HashMap<Integer,Integer>();
		int temp_i_index, temp_j_index;
		
		int currentNi, currentNj;
		HashSet<Integer> currentpercentile_highest_idegrees, currentpercentile_highest_jdegrees, 
		currentPercentile_last_timestamps,currentPercentile_first_timestamps,
		young_ihubs=new HashSet<Integer>(), young_jhubs=new HashSet<Integer>(),
		old_ihubs=new HashSet<Integer>(), old_jhubs=new HashSet<Integer>(),
		ihubs=new HashSet<Integer>(), jhubs=new HashSet<Integer>();
		int temp=0,s=0, videg, vjdeg;
		
		Vertex iv,jv;
		ArrayList<Integer> timestamps=new ArrayList<Integer>();
		
		double normalizationFactor=1;
		double numberOfedgesAddedBywindow=0, numberofAlledges=0;
		
		
		//window management
		HashSet<Integer> Unique_timestamps_in_currentWindow=new HashSet<Integer>();
		double cutoff=Math.floor(0.1*Nt);  System.out.println("number of unique time-stamps in each window="+cutoff);
		
    	if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while ((line = br.readLine()) != null && k<11){
			
			vertexI_ID=0;vertexJ_ID=0;
			columns = getColumns(line, separator);
			vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;//Integer.parseInt(columns[0])-startVertexIndexinFile;//Integer.parseInt(columns[0])-1;
			vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile+Ni;
			timeStamp=new BigDecimal(columns[stampColumn]).intValue();//Integer.parseInt(columns[stampColumn]);	
			
			timestamps.add(timeStamp);//all the timestams seen so far -- for identifying young hubs
			Unique_timestamps_in_currentWindow.add(timeStamp);//for window management
			
			
			//----------------------given the potentially repeated vertices in the new edge, eagerly update the graph-----------------------------------
			if (i_ID_index.containsKey(vertexI_ID)) {//existing i-vertex
				temp_i_index=i_ID_index.get(vertexI_ID);
				
				if (j_ID_index.containsKey(vertexJ_ID)) {//existing j-vertex
					temp_j_index=j_ID_index.get(vertexJ_ID);
				}
				else {//new j-vertex
					temp_j_index=j_ID_index.keySet().size();
					j_ID_index.put(vertexJ_ID,temp_j_index);
					
					jv=new Vertex(timeStamp, temp_j_index);
					BG.jvertices.add(jv);
				}	
			}//end if existing i-vertex
			
			else{//new i-vertex
				temp_i_index=i_ID_index.keySet().size();
				i_ID_index.put(vertexI_ID,temp_i_index);
				
				iv=new Vertex(timeStamp, temp_i_index);
				BG.ivertices.add(iv);
				
				if (j_ID_index.containsKey(vertexJ_ID)) {//existing j-vertex
					temp_j_index=j_ID_index.get(vertexJ_ID);
				}
				else {//new j-vertex
					temp_j_index=j_ID_index.keySet().size();
					j_ID_index.put(vertexJ_ID,temp_j_index);
					
					jv=new Vertex(timeStamp, temp_j_index);
					BG.jvertices.add(jv);
				}
			}
			interarrival=timeStamp-previousTimestamp;
			previousTimestamp=timeStamp;
			e_ij=new IJ_Edge(temp_i_index,temp_j_index,timeStamp, interarrival);
			BG.add_IJEdge(e_ij);
			
			iDegrees[temp_i_index]=BG.IvertexID_JNeighborIDs_HashIndex.get(temp_i_index).size();
			jDegrees[temp_j_index]=BG.JvertexID_INeighborIDs_HashIndex.get(temp_j_index).size();
			
			
			//--------------------------------process the current window----------------------------
			if (Unique_timestamps_in_currentWindow.size()>=cutoff) {//if (!(WindowInitialt<=timeStamp && timeStamp<k*winSize+WindowInitialt)){                                       
				System.out.println("\n ... processing window "+k+" started...t="+timestep);
				
				//young_ihubs=new HashSet<Integer>(); young_jhubs=new HashSet<Integer>();ihubs=new HashSet<Integer>(); jhubs=new HashSet<Integer>();
				
				//-----------calculate the average degree of unique degrees of all vertcices seen so far----------------
				currentNi=i_ID_index.size();
				currentNj=j_ID_index.size();
				for (int i = 0; i < currentNi; i++) {
					unique_idegrees.add(iDegrees[i]);
				}
				for (int i = 0; i < currentNj; i++) {
					unique_jdegrees.add(jDegrees[i]);
				}
				
				avgIdeg=mean(unique_idegrees);
				avgJdeg=mean(unique_jdegrees);
				//timestamps.sort(null);
				
				
				
				//--------------------identify young/old hubs (i.e. vertices withe degree>=average degree && timestamp in last/first percentile)-----------------------------------
				s=timestamps.size();          
				temp=(int) (s*timestamptopPercent*1.0/100.0);
				/*currentPercentile_last_timestamps=new HashSet<Integer>(temp);
				for (int i = 0; i < temp; i++) {
					currentPercentile_last_timestamps.add(timestamps.get(s-i-1));
				}
				currentPercentile_first_timestamps=new HashSet<Integer>(temp);
				for (int i = 0; i < temp; i++) {
					currentPercentile_first_timestamps.add(timestamps.get(i));
				}*/
				
				/*
				try {
					wi=new PrintWriter("young ihubs in window "+k);	
					wj=new PrintWriter("young jhubs in window "+k);	
					wiold=new PrintWriter("old ihubs in window "+k);	
					wjold=new PrintWriter("old jhubs in window "+k);	
					wih=new PrintWriter("ihubs in window "+k);	
					wjh=new PrintWriter("jhubs in window "+k);	
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}*/
			
				ihubs=new HashSet<Integer>(); jhubs=new HashSet<Integer>();
				young_ihubs=new HashSet<Integer>(); young_jhubs=new HashSet<Integer>();
				old_ihubs=new HashSet<Integer>(); old_jhubs=new HashSet<Integer>();
				for (Vertex vi : BG.ivertices) {
					
					videg=BG.IvertexID_JNeighborIDs_HashIndex.get(vi.ID).size();
					if (videg>=avgIdeg) {
						ihubs.add(vi.ID);
						//wih.append(vi.ID+"\r\n");
						//System.out.println(temp+" "+s+" "+s*timestamptopPercent*1.0);//("\nevaluating i-hub "+vi.ID+" with t="+vi.Timestamp+" and degree="+videg+" avgDeg="+avgIdeg);
						if(vi.Timestamp>=timestamps.get(s-temp)){// (currentPercentile_last_timestamps.contains(vi.Timestamp) ) {
							young_ihubs.add(vi.ID);old_ihubs.remove(vi.ID);
							//wi.append(vi.ID+"\r\n");
							//System.out.print("t is in last...old ihubs:"+old_ihubs+" - young ihubs:"+young_ihubs);System.out.println(" - old jhubs:"+old_jhubs+" - young jhubs:"+young_jhubs);
						}
						if (vi.Timestamp<=timestamps.get(temp)){//(currentPercentile_first_timestamps.contains(vi.Timestamp) ) {
							old_ihubs.add(vi.ID);young_ihubs.remove(vi.ID);
							//wiold.append(vi.ID+"\r\n");
							//System.out.print("t is in first...old ihubs:"+old_ihubs+" - young ihubs:"+young_ihubs);System.out.println(" - old jhubs:"+old_jhubs+" - young jhubs:"+young_jhubs);
						}
					}
					
				}//System.out.print("ihubs:"+ihubs+"\nold ihubs:"+old_ihubs+"\nyoung ihubs:"+young_ihubs);System.out.println("\njhubs:"+jhubs+"\nold jhubs:"+old_jhubs+"\nyoung jhubs:"+young_jhubs);
				//wi.close();wih.close();wiold.close();
				
				for (Vertex vj : BG.jvertices) {
					vjdeg=BG.JvertexID_INeighborIDs_HashIndex.get(vj.ID).size();
					if (vjdeg>=avgJdeg) {
						jhubs.add(vj.ID);
						//wjh.append(vj.ID+"\r\n");
						if (vj.Timestamp>=timestamps.get(s-temp)){//(currentPercentile_last_timestamps.contains(vj.Timestamp)) {
							young_jhubs.add(vj.ID);old_jhubs.remove(vj.ID);
							//wj.append(vj.ID+"\r\n");
						}
						if (vj.Timestamp<=timestamps.get(temp)){//(currentPercentile_first_timestamps.contains(vj.Timestamp)) {
							old_jhubs.add(vj.ID);young_jhubs.remove(vj.ID);
							//wjold.append(vj.ID+"\r\n");
						}
					}
					
				}
				//wj.close();wjh.close();wjold.close();
				
				numberofAlledges=BG.edgeIDs_IJedges.size();
				//numberOfedgesAddedBywindow=numberofAlledges-numberOfedgesAddedBywindow;
				normalizationFactor=1.0;//Math.log10(BG.edgeIDs_IJedges.size());//(1.0*numberOfedgesAddedBywindow/numberofAlledges);//Math.log10(BG.edgeIDs_IJedges.size());
				
				//plot10.addPoint(0, k, (ihubs.size()*1.0)/normalizationFactor, false);      wi.append((ihubs.size()*1.0)/normalizationFactor+"\r\n");
				//plot100.addPoint(0, k, (jhubs.size()*1.0)/normalizationFactor, false);     wj.append((jhubs.size()*1.0)/normalizationFactor+"\r\n");
				
				plot1.addPoint(0, k, 1.0*young_ihubs.size()/normalizationFactor, false);   wiyoung.append(1.0*young_ihubs.size()/normalizationFactor+"\r\n");
				plot11.addPoint(0, k, 1.0*young_jhubs.size()/normalizationFactor, false);  wjyoung.append(1.0*young_jhubs.size()/normalizationFactor+"\r\n");
				plot2.addPoint(0, k, 1.0*old_ihubs.size()/normalizationFactor, false);     wiold.append(1.0*old_ihubs.size()/normalizationFactor+"\r\n");
				plot22.addPoint(0, k, 1.0*old_jhubs.size()/normalizationFactor, false);    wjold.append(1.0*old_jhubs.size()/normalizationFactor+"\r\n");
				
				//advance the window
				Unique_timestamps_in_currentWindow=new HashSet<Integer>();//WindowInitialt=timeStamp;				
				k++;
				
				//System.out.println("fraction of young iHubs="+young_ihubs.size()+"/"+ihubs.size()+"  - fraction of young jHubs="+young_jhubs.size()+"/"+jhubs.size()  +" number of edges iadded by window:"+numberOfedgesAddedBywindow+"/"+numberofAlledges+" normalization:"+normalizationFactor);
			}//System.out.println(step);
			timestep++;
		}
		wjyoung.close();wjold.close();wiyoung.close();wiold.close();//wj.close();wi.close();
		/*
		new PlotApplication(plot1);new PlotApplication(plot11);
		new PlotApplication(plot22);new PlotApplication(plot2);
		new PlotApplication(plot10);new PlotApplication(plot100);
		*/
		/*for (int i = 0; i < jDegrees.length; i++) {
			if (jDegrees[i]>=avgJdeg) {
				plot010.addPoint(1, i, jDegrees[i], false);
			}
			else{
				plot010.addPoint(0, i, jDegrees[i], false);
			}
			
		}
		
		for (int i = 0; i < iDegrees.length; i++) {
			if (iDegrees[i]>=avgIdeg) {
				plot1000.addPoint(1, i, iDegrees[i], false);
			}
			else{
				plot1000.addPoint(0, i, iDegrees[i], false);
			}
		}ap=new PlotApplication(plot1000);ap=new PlotApplication(plot010);*/
		
    }
    
    //degree distribution
    private static void array_plot_write(double[] arr, String title, String xLable, String yLable, int scale, boolean connectedPoints) throws IOException{
		PrintWriter p=new PrintWriter(title);
    	
		Plot plot1=new Plot();
		plot1.setTitle(title);
		plot1.setXLabel(xLable);
		plot1.setYLabel(yLable);
		plot1.setMarksStyle("dots");
		/*
		Plot plot2=new Plot();
		plot2.setTitle("Logarithm of"+title);
		plot2.setXLabel(xLable);
		plot2.setYLabel(yLable);
		plot2.setMarksStyle("dots");
		*/
		int s=arr.length;
		
		int i=1;
		while (i < s) {
				//if (arr[i]!=0 & arr[i]!=Double.POSITIVE_INFINITY & arr[i]!=Double.NEGATIVE_INFINITY ) { 
				plot1.addPoint(0, i, scale*arr[i], connectedPoints);
				//plot2.addPoint(0, i, scale*Math.log(arr[i]), true);
				p.append(i+" "+arr[i]+"\r\n");			
			//}
			i++;
		}				
	    new PlotApplication(plot1);							    
	    //app=new PlotApplication(plot2);
	    p.close();
		
	}
    public static void create_iDegree_iDegreeDistribution(int Ni, BipartiteGraph BG){//assuming IDs start from 1 -degree distribution is normalized to the number of vertices
  		HashSet<Integer> uniquedegreees=new HashSet<Integer>();
    	
  		BG.iDegree=new int[Ni];
  		int maxIdegree=0; double avgIdeg=0;
  		HashSet<Integer> jneighbors;
  		for (int i = 0; i < Ni; i++) {
  			BG.iDegree[i]=0;
  			jneighbors=BG.IvertexID_JNeighborIDs_HashIndex.get(i);
  			
  			if (jneighbors!=null) {
  				BG.iDegree[i]+=jneighbors.size();
  				if (BG.iDegree[i]>maxIdegree) {
  					maxIdegree=BG.iDegree[i];
  				}
  				uniquedegreees.add(BG.iDegree[i]);//avgIdeg+=BG.iDegree[i];
  			}
  			//for (Integer jvertex : jneighbors) {
  				//BG.iDegree[i]++;
  			//}
  								
  		}
  		avgIdeg/=Ni;
  		System.out.println("\nmax I-degree="+maxIdegree+"avg unique Ideg="+mean(uniquedegreees)+"\n");
  		
  		BG.iDegreeDistribution=new double[maxIdegree+2];		
  		for (int i = 0; i < Ni; i++) {
  			BG.iDegreeDistribution[BG.iDegree[i]]++;			
  		}
  		for (int i = 0; i < maxIdegree+1; i++) {
  			BG.iDegreeDistribution[i] = BG.iDegreeDistribution[i];//(Inumber*1.0);
  			if (BG.iDegreeDistribution[i]!=0) {
  				//System.out.println("I-degree="+i+" freq="+BG.iDegreeDistribution[i] );
  			}			
  		}
  		
  	}
  	public static void create_jDegree_jDegreeDistribution(int jnumber, BipartiteGraph BG){//assuming IDs start from 1
  		HashSet<Integer> uniquedegreees=new HashSet<Integer>();
  		BG.jDegree=new int[jnumber];
  		int maxJdegree=0;double avgJdeg=0;
  		HashSet<Integer> ineighbors;
  		for (int j = 0; j < jnumber; j++) {
  			BG.jDegree[j]=0;
  			ineighbors=BG.JvertexID_INeighborIDs_HashIndex.get(j+1);
  			if (ineighbors!=null) {
  				BG.jDegree[j]+=ineighbors.size();
  				if (BG.jDegree[j]>maxJdegree) {
  					maxJdegree=BG.jDegree[j];
  				}
  				uniquedegreees.add(BG.jDegree[j]);//avgJdeg+=BG.jDegree[j];
  			}							
  		}
  		avgJdeg/=jnumber;
  		System.out.println("\nmax J-degree="+maxJdegree+" avg unique Jdeg="+mean(uniquedegreees)+"\n");
  		
  		BG.jDegreeDistribution=new double[maxJdegree+2];		
  		for (int j = 1; j < jnumber; j++) {
  			BG.jDegreeDistribution[BG.jDegree[j]]++;			
  		}
  		
  		for (int j = 0; j < maxJdegree+1; j++) {
  			BG.jDegreeDistribution[j] =BG.jDegreeDistribution[j];///(jnumber*1.0);
  			if (BG.jDegreeDistribution[j]!=0) {
  				//System.out.println("J-degree="+j+" freq="+BG.jDegreeDistribution[j]);
  			}			
  		}
  		
  	}
    
  	//degree dist for unipartite graphs
  	public static int[][] readlist_getAdjacencyMatrix(String fileName, int N, int rows, int nodeIndexStart, boolean directed) throws IOException{
    	graph5 graph=new graph5();
    	for (int i = 0; i <N; i++) {
			graph.add(i);
		}
    	
    	FileInputStream fstream = new FileInputStream(fileName);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		String line; 
		String[] lineNumbers;
		//-------------------------------------------readind files and plotting---------------------------- 
		for (int row = 0; row < rows; row++) {
			line= br.readLine();
		    lineNumbers=line.split(" ");
		    graph.add(Integer.parseInt(lineNumbers[0]),Integer.parseInt(lineNumbers[1]),directed);	    
		}
		br.close();
		
    	return graph.getAdjacencyMatrix(nodeIndexStart);
    }
  	public static void  DegreeDistribution(String fileName, int[][] AdjacencyMatrix) throws IOException{
		
		int N=AdjacencyMatrix.length;
		
		int[] inDegree=new int[N];
		int[] outDegree=new int[N];
		int maxIndegree=0, maxOutDegree=0;
		int d=0;
		for (int i = 0; i < N; i++) {
			inDegree[i]=0;outDegree[i]=0;
			for (int j = 0; j < N; j++) {
				inDegree[i]+=AdjacencyMatrix[j][i];
				outDegree[i]+=AdjacencyMatrix[i][j];			
			}
			if (inDegree[i]>maxIndegree) {
				maxIndegree=inDegree[i];
			}
			if(outDegree[i]>maxOutDegree) {
				maxOutDegree=outDegree[i];
			}
			d=inDegree[i]+outDegree[i];
			//System.out.println("indegree["+i+"]:"+inDegree[i]+"\t"+"outdegree["+i+"]:"+outDegree[i]);
		}
		
		//System.out.println("max outdegree="+maxOutDegree);
		
		double[] inDegreeDistribution=new double[maxIndegree+2];
		double[] outDegreeDistribution=new double[maxOutDegree+2];
		for (int i = 0; i < N; i++) {
			inDegreeDistribution[inDegree[i]]++;
			outDegreeDistribution[outDegree[i]]++;
		}
		for (int i = 0; i < maxIndegree+1; i++) {
			inDegreeDistribution[i] =inDegreeDistribution[i]/(N*1.0);
			if (inDegreeDistribution[i]!=0) {
				System.out.println("indegree="+i+" freq="+inDegreeDistribution[i] );
			}
			
		}System.out.println("\n");
		array_plot_write(inDegreeDistribution, fileName+"- in-degree dist - N="+N, "", "", 1, false);
		
		for (int i = 0; i < maxOutDegree+1; i++) {
			outDegreeDistribution[i] =outDegreeDistribution[i]/(N*1.0);
			if (outDegreeDistribution[i]!=0) {
				System.out.println("outdegree="+i+" freq="+outDegreeDistribution[i] );
			}
			
		}array_plot_write(outDegreeDistribution, fileName+"- out-degree dist - N="+N, "", "", 1, false);		
	}
  	
  	public static void readFile(String file,String separator, int linebreaks, int column) throws IOException{
    	FileInputStream fstream = new FileInputStream(file);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
    	String line;
    	int max=0, min=70000000;
    	String[] columns;
    	int temp=0;
    	int c=0;
    	
    	HashSet<String> ids=new HashSet<String>();
    	if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}c++;
		}
    	while ((line = br.readLine()) != null){// && c<2){
    		
    		columns = getColumns(line,separator);
    		//System.out.println(line);//(columns[0]+" "+columns[1]+" "+columns[2]+" "+columns[3]);
    		c++;
    		ids.add(columns[column]);
    		
    		temp=new BigDecimal(columns[column]).intValue();
			if (max<temp) {
				max=temp;
			}
			if (min>temp) {
				min=temp;
			}
			
    	}
    	System.out.println(ids.size() +" number of rows:"+c+"  - max value in the selected column:"+max+" - min value in the selected column:"+min);
    }
  	
    public static void main(String[] args) throws NumberFormatException, IOException {
		
    	
    	//=================================================Data=========================================================================
    	
    	//----------> realworld edit-en-wiki
    	/*
    	String filename="timesorted-Enwiki"; int stampColumn=2; String separator=" ";int linebreaks=0;int startVertexIndexinFile=1; 
    	int avgIdeg=70 , avgJdeg=12;
    	int t0=979768389; int Ni=262373039; int Nj=266665865; int rows=266769613;  int Nt=134075025; int tl=1283771188; double Butterflies=2*Math.pow(10, 12);
     	*/
         //----------> realworld edit-fr-wiki
    	/*
    	String filename="timesorted-editfrwiki"; int stampColumn=2; String separator=" ";int linebreaks=0;int startVertexIndexinFile=1; 
    	int avgIdeg=160 , avgJdeg=11;
    	int t0=1036059361; int Ni=288275; int Nj=3992426; int rows=46168355;  int Nt=39190059; int tl=1283302334; double Butterflies=601.2*Math.pow(10, 12);
    	*/
    	//----------> realworld ML10m
   	    /*
    	String filename="timesorted-ml10m"; int stampColumn=2; String separator=" ";int linebreaks=0;int startVertexIndexinFile=1; 
    	int avgIdeg=143, avgJdeg=937;
    	int t0=789652009; int Ni=69878; int Nj=10677; int rows=10000054;  int Nt=7096905; int tl=1231131103;
        */
    	//----------> realworld ML1m
    	/*
    	String filename="timesortedmovielens1m"; int stampColumn=3; String separator=" ";int linebreaks=1;int startVertexIndexinFile=1; 
    	int avgIdeg=166, avgJdeg=270;
    	int uniquetimestamps=458455; int t0=956703932; int Ni=6040; int Nj=3706; int rows=1000210;  int Nt=458455;
    	int maxIdegat5k=888, maxJdegat5k=28;
		double avg_unique_Idegrees_at5k=128.13, avg_unique_Jdegrees_at5k=11.33;  
		double p_1ihub=0.43, p_2ihub=0.47, p_1jhub=0.15, p_2jhub=0.14;
    	*/
    	
    	//----------> Syntetic BA+ ML1m/random stamps
    	/*
    	String filename="timesorted-ML1m-readstamps-BA";String separator=" ";int startVertexIndexinFile=0; int linebreaks=0; int t0=956703954, tl=1046454590; int Nt=458312;int rows=999901;int Ni=6106, Nj=6022;int winSize=100000;int avgIdeg=164; int avgJdeg=166;int stampColumn=2;//max I-degree=166avgIdeg=163.72993776613168 max J-degree=1426 avgJdeg=165.85171039521754
    	//int maxIdegat5k=166, maxJdegat5k=8;
    	double avg_unique_Idegrees_at5k=88.87, avg_unique_Jdegrees_at5k=4.5;
    	*/
    	
    	/*String filename="timesorted-ML1m-randomstamps-BA";String separator=" ";int linebreaks=0; int t0=956704053, tl=1046454498; int Nt=994467; int rows=999901;int Ni=6106, Nj=6022;int winSize=100000;int avgIdeg=164; int avgJdeg=166;int stampColumn=2;int startVertexIndexinFile=0;    	
    	int maxIdegat5k=6, maxJdegat5k=14;
		*/
    	
    	//unipartote BA
    	//String filename="ML1m-BA-N=6107-m=166-m0=166"; int N=6107, rows=999901, nodeIndexStart=0;boolean directed=true;
    	
    	//----------------------------------------------------------------------------------------------------------------
    	
    	//----------> real-world ML100k
    	/*
    	String filename="timesorted100k";int winSize=100000;int avgIdeg=106;int avgJdeg=59;int startVertexIndexinFile=1;
    	int stampColumn=3;int t0=874724710, rows=100000,  Ni=943, Nj=1682; int ihubdegreeThreshold=250, jhubdegreeThreshold=250;
        String separator="\t";int linebreaks=0; int tl=893286638;int tspan=18561928;int Nt=49282;
		int maxIdegat5k=391, maxJdegat5k=34;
		double avg_unique_Idegrees_at5k=96, avg_unique_Jdegrees_at5k=15;
	*/
		
    	//----------> Syntetic BA+ML100k/random stamps
    	//int rows=99905; int avgIdeg=100; int avgJdeg=100;
    	//int Ni=995, Nj=982;  String separator=" ";int linebreaks=0; int startVertexIndexinFile=1;
    	/*String filename="timesorted-randomstampBA";int t0=874724804;int tl=893286411;int tspan=18561607;int Nt=99655;int stampColumn=2;
    	int maxIdegat5k=15, maxJdegat5k=36; 
    	*/
    	/*
        String filename="timesorted-mlstampsBA"; int t0= 874724710, tl= 893286638; int Nt=49254;int stampColumn=2; 
    	int maxIdegat5k=13, maxJdegat5k=32;
    	double avg_unique_Idegrees_at5k=7, avg_unique_Jdegrees_at5k=16;
    	*/
    	
    	//unipartote BA
    	//String filename="BA-N=996-m=106-m0=106"; int N=996, rows=99905, nodeIndexStart=0;boolean directed=true;
    	
    	//----------------------------------------------------------------------------------------------------------------
    	
    	//----------> real-world Epinions
    	/*
    	String filename="timesortedEpinions1m";int stampColumn=2; int startVertexIndexinFile=1;
    	int Ni=22164; int Nj=296277; int rows=922267; int t0=931158000;int tl=1304924400; 
    	String separator=" ";int linebreaks=0; int Nt=4318;
    	int avgIdeg=41;int avgJdeg=3;
    	int maxIdegat5k=225, maxJdegat5k=33;
		double avg_unique_Idegrees_at5k=36.93, avg_unique_Jdegrees_at5k=13.48;    	
		double p_1ihub=0.35;//0.37;//
		double p_2ihub=0.54;//0.42;//
		double p_1jhub=0.13;;//0.29;//
		double p_2jhub=0.02;//0.14;//
		//double P_1or2_ihubs_inClqs_efectiveedgesconnectinhtoIhubs=0.88,  P_1or2_jhubs_inClqs_efectiveedgesconnectinhtoJhubs=0.15,  P_effective_ihub_degree=0.1, P_effective_jhub_degree=0.05;
    	*/
		
    	//----------> Syntetic BA+Epinions stamps	
    	/*
    	String filename="timesorted-Epinions1m-readstampsBA";int stampColumn=2; int startVertexIndexinFile=0;
    	int Ni=22514; int Nj=21455; int rows=922254; int t0=931158000; int tl=1304924400;
    	String separator=" ";int linebreaks=0; int Nt=4318;
    	int avgIdeg=41;int avgJdeg=43; //number of unique time-stamps in each window=431.0
    	int maxIdegat5k=41, maxJdegat5k=13;
    	double avg_unique_Idegrees_at5k=19.17, avg_unique_Jdegrees_at5k=7;
    	*/
    	//----------> Syntetic BA+random stamps
        //String filename="timesorted-Epinions1m-BA-randomstamps";int stampColumn=2; int startVertexIndexinFile=0; String separator=" ";int linebreaks=0;
        //int Ni=22514; int Nj=21455; int t0=931158178, tl=1304924374; int rows=922254; int Nt=921159; int avgIdeg=41;int avgJdeg=43;
    	
    	//unipartote BA
    	//String filename="Epinioins1m-BA-N=22515-m=41-m0=41"; int N=22515, rows=922254, nodeIndexStart=0;boolean directed=true;String separator=" ";int linebreaks=0; int Ni=22514;int Nj=21455;
    	
		
    	
    	//==========================================================Methods===================================================================
		
    	//degree distribution for 3 real graphs
    	//degree dist - unipartite graphs
    	//int[][] AdjacencyMatrix=readlist_getAdjacencyMatrix(filename, N, rows, nodeIndexStart, directed);
    	//DegreeDistribution(filename, AdjacencyMatrix);
    	
    	//degree distribution - bipartite graphs
    	//BipartiteGraph BG= readFile_createBipartiteGraph(startVertexIndexinFile, filename, linebreaks, stampColumn, t0, rows, false, separator);
    	//create_iDegree_iDegreeDistribution(Ni, BG);
    	//create_jDegree_jDegreeDistribution(Nj, BG);
    	/*array_plot_write(BG.iDegreeDistribution, filename+" - idegree dist - Ni="+Ni, "", "", 1, false);
    	array_plot_write(BG.jDegreeDistribution, filename+" - jdegree dist - Nj="+Nj, "", "", 1, false);
    	*/
    	
    	
    	//temporal evolution of butterfly count
        //int lasttimeStep=75000;//epionins:72344; //ML100k 12259; //ML1m 21696; //ML10m 21778;
    	//grountruth_butterflyCount(startVertexIndexinFile, stampColumn, filename, t0, separator, linebreaks, lasttimeStep, avgIdeg, avgJdeg);
    	
    	
    	//Distribution of inter-arrivals of butterfly edges - //Table 6 in long version - Pearson correlation
    	//interarrival_of_clique_edges(startVertexIndexinFile, stampColumn, filename, t0, rows, Ni, Nj, separator, linebreaks, 5000);
    	
    	
    	//Pr(N_hub=0,1,3,4)  
    	//prob_of_clqswithhubs(5000, startVertexIndexinFile, stampColumn, filename, t0, rows, Ni, Nj, separator, linebreaks);
    	
    	
    	//Pr(N_ihub=0,1,2)  Pr(N_jhub=0,1,2)
    	//probs_of_clqswith_iHubs_jHubs(5000, startVertexIndexinFile, stampColumn, filename, t0, rows, Ni, Nj, separator, linebreaks);
    	
    	
    	//average i-hubs,j-hubs degree (normalized fraction of i,j-hub connections)
    	//plot_evolutionOf_edgesConnectedto_iHubs_and_jHubs(startVertexIndexinFile, filename, stampColumn, avgIdeg, avgJdeg, t0, separator, linebreaks);
    	
    	
    	//number of young/old i,j-hubs
    	//int timePercentile=25;
    	//windowed_young_old_iHubs_jHubs(Nt, startVertexIndexinFile, stampColumn,filename, t0, Ni, Nj, separator, linebreaks, timePercentile);
    	
    	
    	//temporal distribution
    	//temporalDist(filename, linebreaks, separator, stampColumn);
    	
    	
    	//MAPE
    	/*String truth_file=
		//"groundtruth cumulative number of cliques at all steps untill  tl=72344 timesortedEpinions1m";int lastTimestep=72344;
		//"groundtruth cumulative number of cliques at all steps untill  tl=12259 timesorted100k";int lastTimestep=12259;
		//"groundtruth cumulative number of cliques at all steps untill  tl=21696  timesortedmovielens1m";int lastTimestep=21696;
		//"groundtruth cumulative number of cliques at all steps untill  tl=21778 timesorted-ml10m";int lastTimestep=21778;
		//"groundtruth cumulative number of cliques at all steps untill  tl=75000 timesorted-Enwiki";int lastTimestep=75000;
		//"2 - groundtruth cumulative number of cliques at all steps untill  tl=75000 timesorted-editfrwiki";int lastTimestep=75000;
    	writeMAPE(truth_file, startVertexIndexinFile, stampColumn, filename, t0, lastTimestep, rows, avgIdeg, avgJdeg, separator, linebreaks, Nt) ;
    	*/
    	
    	
    	//relative error of sGrapp //figure 26-29 in long version - Matlab - relative error of sGrapp-x
    	/*String truth_file=
			//"groundtruth cumulative number of cliques at all steps untill  tl=72344 timesortedEpinions1m";int lastTimestep=72344;
			//"groundtruth cumulative number of cliques at all steps untill  tl=12259 timesorted100k";int lastTimestep=12259;
			//"groundtruth cumulative number of cliques at all steps untill  tl=21696  timesortedmovielens1m";int lastTimestep=21696;
			//"groundtruth cumulative number of cliques at all steps untill  tl=21778 timesorted-ml10m";int lastTimestep=21778;
			//"groundtruth cumulative number of cliques at all steps untill  tl=75000 timesorted-Enwiki";int lastTimestep=75000;
			//"2 - groundtruth cumulative number of cliques at all steps untill  tl=75000 timesorted-editfrwiki";int lastTimestep=75000;
		double x=0.25;//=0.75;//=0.5;//=1;
		int Ntw=912; double exponent=1.435
    	WriteRelativeError(truth_file, startVertexIndexinFile, stampColumn, filename, t0, lastTimestep, rows, avgIdeg, avgJdeg, separator, linebreaks, Nt, exponent, Ntw);
    	*/
    	
    	
    	//average window/total throughput/latency of sGrapp or sGrapp-x
    	/*double exponent=0.525; int Ntw=295;//ml100k1.435; int Ntw=912;//1.03; int Ntw=44;//ml100k //frwiki 0.53; int Ntw=300;//frwiki 0.9; int Ntw=360;//ml10m1.402; int Ntw=80;
    	int winCount=537489;//455344;//37329;//ml1m436;//ml100k54;//ml100k 167;//frwiki 108907;//ml10m88930;
    	sGrapp_average_efficincy(winCount, 50, exponent, startVertexIndexinFile, stampColumn, filename, t0, rows, avgIdeg, avgJdeg, separator, linebreaks, Nt, Ntw);
    	*/   
    	/*
    	double exponent=0.525; int Ntw=295;//ml100k1.435; int Ntw=912;//1.03; int Ntw=44;//ml100k //frwiki 0.53; int Ntw=300;//frwiki 0.9; int Ntw=360;//ml10m1.402; int Ntw=80;
    	int winCount=537489;//455344;//37329;//ml1m436;//ml100k54;//ml100k 167;//frwiki 108907;//ml10m88930;
    	String truth_file=
		//"groundtruth cumulative number of cliques at all steps untill  tl=72344 timesortedEpinions1m";int lastTimestep=72344;
		//"groundtruth cumulative number of cliques at all steps untill  tl=12259 timesorted100k";int lastTimestep=12259;
		//"groundtruth cumulative number of cliques at all steps untill  tl=21696  timesortedmovielens1m";int lastTimestep=21696;
		//"groundtruth cumulative number of cliques at all steps untill  tl=21778 timesorted-ml10m";int lastTimestep=21778;
		//"groundtruth cumulative number of cliques at all steps untill  tl=75000 timesorted-Enwiki";int lastTimestep=75000;
		//"2 - groundtruth cumulative number of cliques at all steps untill  tl=75000 timesorted-editfrwiki";int lastTimestep=75000;
    	double x=0.25;//=0.75;//=0.5;//=1;
    	sGrappx_average_efficincy(x, truth_file, wincount, 50, exponent, startVertexIndexinFile, stampColumn, filename, t0, rows, avgIdeg, avgJdeg, separator, linebreaks, winCount, Ntw)   
    	/*
    	int Ntw=912; double exponent=1.435;
    	sGrapp_efficiency(0, exponent, startVertexIndexinFile, stampColumn, filename, t0, rows, avgIdeg, avgJdeg, separator, linebreaks, Nt, Ntw);
    	*/
    	/*String truth_file=
    			//"groundtruth cumulative number of cliques at all steps untill  tl=72344 timesortedEpinions1m";int lastTimestep=72344;
    			"groundtruth cumulative number of cliques at all steps untill  tl=12259 timesorted100k";int lastTimestep=12259;
    			//"groundtruth cumulative number of cliques at all steps untill  tl=21696  timesortedmovielens1m";int lastTimestep=21696;
    			//"groundtruth cumulative number of cliques at all steps untill  tl=21778 timesorted-ml10m";int lastTimestep=21778;
    			//"groundtruth cumulative number of cliques at all steps untill  tl=75000 timesorted-Enwiki";int lastTimestep=75000;
    			//"2 - groundtruth cumulative number of cliques at all steps untill  tl=75000 timesorted-editfrwiki";int lastTimestep=75000;
    	double x=0.25;//=0.75;//=0.5;//=1;
    	int Ntw=912; double exponent=1.435;
    	sGrappx_efficiency(x, truth_file, 0, exponent, startVertexIndexinFile, stampColumn, filename, t0, rows, avgIdeg, avgJdeg, separator, linebreaks, Nt, Ntw);
    	*/
    	
    	
    	//one time execution: mape, latency and throughput 
    	/*int Ntw=912; double exponent=1.435;
    	//double x=0.25;//=0.75;//=0.5;//=1;
    	Vector<Vector<Long>> index_approximation=
    	//sGrappx(x,truth_file, exponent, startVertexIndexinFile, stampColumn, filename, t0, lastTimestep, rows, avgIdeg, avgJdeg, separator, linebreaks, Nt, Ntw);
    	sGrapp(exponent, startVertexIndexinFile, stampColumn, filename, t0, rows, avgIdeg, avgJdeg, separator, linebreaks, Nt, Ntw);
    	Vector<Integer> groundtruth=readVector(truth_file);
    	MAPE(groundtruth, index_approximation);
    	*/

	}
}