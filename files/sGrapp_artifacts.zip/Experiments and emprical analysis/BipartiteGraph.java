
import java.io.File;
import java.io.IOException;
import java.security.Timestamp;
import java.sql.Time;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import jxl.*;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

import ptolemy.plot.Plot;
import ptolemy.plot.PlotApplication;
import ptolemy.plot.PlotApplication;

class IJ_Edge{
	String ID;//I-J since the graph is simple and we don't have multiple edges between two vertices, concatenating the IDs of 2 vertices gives us a unique ID for the edge.
	//double Weight;
	//double[] Content;
	int iID;//Veimport ptolemy.plot.Plot;
	int jID;//Vertex JVertex;
	int timeStamp;
	int FreeVariable;
	
	IJ_Edge(int iVertexID, int jVertexID, int timestamp, int interarrival_or_windowID) {
		ID=iVertexID+"-"+jVertexID;
		iID=iVertexID;
		jID=jVertexID;
		timeStamp= timestamp;
		FreeVariable=interarrival_or_windowID;
	}
	
}

class Vertex{
	int Timestamp;
	int ID;
	Vertex(int timestamp, int id){
		Timestamp=timestamp;
		ID=id;
	}
}

public class BipartiteGraph{
	Map<Integer,HashSet<Integer>> JvertexID_INeighborIDs_HashIndex = new HashMap<Integer,HashSet<Integer>>();//map each vertex J to its I-type neighbors
	Map<Integer,HashSet<Integer>> IvertexID_JNeighborIDs_HashIndex = new HashMap<Integer,HashSet<Integer>>();//maps each vertex I  to its J-type neighbors //inverted hash index
	Map<String,IJ_Edge> edgeIDs_IJedges=new HashMap<String,IJ_Edge>();
	Vector<IJ_Edge> edges;
	//Map<Integer,Integer> ivertexIDs_ivertexes=new HashMap<Integer,Integer>();
	//Map<Integer,Integer> jvertexIDs_jvertexes=new HashMap<Integer,Integer>();
	HashSet<Vertex> ivertices, jvertices;
	//profile
	int t0;
	
	Map<String,Integer> edgeIDs_degdiff=new HashMap<String,Integer>();//not normalized by the maxDiff
	
	int[] jDegree, iDegree;
	double[] iDegreeDistribution, jDegreeDistribution;
	int maxDegreeDifferenceofedges;
	double meanDegreeDifferenceofedges;
	
	Map<Integer, int[]> timeUnit_selfSimilarityBins=new HashMap<Integer, int[]>();//selfSimilarityBins are the frequency of events happened at a certain number of time intervals
	
	Map<Integer, Integer> degDiffDistribution;//=new HashMap<Integer, Integer>();
	Map<Integer, Double> degDiff_probDistribution;//=new HashMap<Integer, Double>();
	Map<Double, Integer> degDiff_cumulativeDistribution;//=new HashMap<Double, Integer>();
	Map<Double, Double> degDiff_cumulativeprobDistribution;//=new HashMap<Double, Double>();
	Map<Double, Double> degDiff_casBasedEntropyOfProbDis;//t=new HashMap<Double, Double>();
	ArrayList<Double> degDiffs;//=new ArrayList<Double>();
	
	Vector<Integer> spikeIDs, spikeTimestamps, burstCounts, burstLengths;
	Vector<Double> burstRate;
	
	Map<Integer, Integer> burstCountDistribution=new HashMap<Integer, Integer>(), burstLengthDistribution=new HashMap<Integer, Integer>();
	int MaxBurstCount, MaxBurstLength;
	
	int[] interarrivals;
	Map<Integer, Integer> InterArrivalDistribution=new HashMap<Integer, Integer>();
	int MaxInterArrival;
	//double first_logIntearrival, last_logIntearrival,first_logfreq,last_logfreq, loglog_interarrivaldistribution_linearRegressionslope; //logarithm of inter-arrival time or logarithm of the frequency of the interarrival time
	
	HashSet<Integer> ihubs, jhubs;
	
	
	void add_JVertex (Integer jID) {
		if (this.JvertexID_INeighborIDs_HashIndex.containsKey(jID) || jID==null) return;
        //this.jvertexIDs_jvertexes.put(jID, v_j);	
        this.JvertexID_INeighborIDs_HashIndex.put(jID, new HashSet<Integer>());
	}
	void add_IVertex (Integer iID) {
		if (this.IvertexID_JNeighborIDs_HashIndex.containsKey(iID) || iID==null) return;
        //this.jvertexIDs_jvertexes.put(jID, v_j);	
        this.IvertexID_JNeighborIDs_HashIndex.put(iID, new HashSet<Integer>());
	}

	void add_IJEdge(IJ_Edge e_ij) {
		int iID=e_ij.iID,jID=e_ij.jID;
		//self-loop and duplicate-edges are not allowed.//no need to check this condition because hashset does not allow duplicates e.From.equals(e.To) || 
		if ( (IvertexID_JNeighborIDs_HashIndex.containsKey(e_ij.iID) && IvertexID_JNeighborIDs_HashIndex.get(e_ij.iID).contains(e_ij.jID))){ 
			//System.out.println(e_ij.ID+" is a duplicate edge not added");
			return;
		
		}
     	
		//this.add_IVertex(iID);
		//IvertexID_JNeighborIDs_HashIndex.get(iID).add(jID);
	    
	    this.add_JVertex(jID);
	    if (JvertexID_INeighborIDs_HashIndex.containsKey(jID)) {
	    	JvertexID_INeighborIDs_HashIndex.get(jID).add(iID);
		}
	    else{
	    	HashSet<Integer> ineighbors=new HashSet<Integer>();ineighbors.add(iID);
	    	JvertexID_INeighborIDs_HashIndex.put(jID, ineighbors);
	    }
	   
	    
	    this.add_IVertex(iID);
	    if (IvertexID_JNeighborIDs_HashIndex.containsKey(iID)) {
	    	IvertexID_JNeighborIDs_HashIndex.get(iID).add(jID);
		}
	    else{
	    	HashSet<Integer> jneighbors=new HashSet<Integer>();jneighbors.add(jID);
	    	IvertexID_JNeighborIDs_HashIndex.put(iID, jneighbors);
	    }
	    	     
	    edgeIDs_IJedges.put(e_ij.ID, e_ij);	       
	}

	boolean add_IJEdge_trueifNonduplicate (IJ_Edge e_ij) {
		int iID=e_ij.iID,jID=e_ij.jID;
		//self-loop and duplicate-edges are not allowed.//no need to check this condition because hashset does not allow duplicates e.From.equals(e.To) || 
		if ( (IvertexID_JNeighborIDs_HashIndex.containsKey(e_ij.iID) && IvertexID_JNeighborIDs_HashIndex.get(e_ij.iID).contains(e_ij.jID))){ 
			//System.out.println("duplicate edge");
			return false;
		
		}
     	
		this.add_IVertex(iID);
		IvertexID_JNeighborIDs_HashIndex.get(iID).add(jID);
	    
	    this.add_JVertex(jID);
	    if (this.JvertexID_INeighborIDs_HashIndex.containsKey(jID)) {
	    	JvertexID_INeighborIDs_HashIndex.get(jID).add(iID);
		}
	    else{
	    	HashSet<Integer> ineighbors=new HashSet<Integer>();ineighbors.add(iID);
	    	this.JvertexID_INeighborIDs_HashIndex.put(jID, ineighbors);
	    }
	   
	    
	    this.add_IVertex(iID);
	    if (this.IvertexID_JNeighborIDs_HashIndex.containsKey(iID)) {
	    	IvertexID_JNeighborIDs_HashIndex.get(iID).add(jID);
		}
	    else{
	    	HashSet<Integer> jneighbors=new HashSet<Integer>();jneighbors.add(jID);
	    	this.JvertexID_INeighborIDs_HashIndex.put(iID, jneighbors);
	    }
	    	     
	    edgeIDs_IJedges.put(e_ij.ID, e_ij);	 
	    return true;
	}
	
	void remove_IJedge(IJ_Edge e_ij){
		int iID=e_ij.iID,jID=e_ij.jID;
		
		if (this.IvertexID_JNeighborIDs_HashIndex.get(iID).isEmpty()) {
			System.out.println(iID+" has no j-neighbor! invalid edge to be removed!");
			//return;
		}
		if (this.JvertexID_INeighborIDs_HashIndex.get(jID).isEmpty()) {
			System.out.println(jID+" has no i-neighbor! invalid edge to be removed!");
			//return;
		}
		
		if (!this.IvertexID_JNeighborIDs_HashIndex.get(iID).isEmpty()) {
			this.IvertexID_JNeighborIDs_HashIndex.get(iID).remove(jID);
			this.edgeIDs_IJedges.remove(e_ij.ID);
		}
		
		/*if (this.IvertexID_JNeighborIDs_HashIndex.get(iID).isEmpty()) {
			this.IvertexID_JNeighborIDs_HashIndex.remove(iID);
			System.out.println("isolated i-vertex "+iID+" is deleted!");
			//ivertexIDs_ivertexes.remove(e_ij.IVertex.ID);
		}*/
		
		if (!this.JvertexID_INeighborIDs_HashIndex.get(jID).isEmpty()) {
			this.JvertexID_INeighborIDs_HashIndex.get(jID).remove(iID);
		}
		
		/*if (this.JvertexID_INeighborIDs_HashIndex.get(jID).isEmpty()) {
			this.JvertexID_INeighborIDs_HashIndex.remove(jID);
			System.out.println("isolated j-vertex "+jID+" is deleted!");
			//jvertexIDs_jvertexes.remove(e_ij.JVertex.ID);
		}*/
		
	}
	
	/*void change_IJedge(double viID, double vjID, double[] newContent){
		if (edgeIDs_IJedges.containsKey(viID+"-"+vjID)) {
			edgeIDs_IJedges.get(viID+"-"+vjID).Content=newContent;
		}				
	}*/

	void remove_IVertex (Integer iID){
		//this.ivertexIDs_ivertexes.remove(v_i.ID);
		
		this.IvertexID_JNeighborIDs_HashIndex.remove(iID);
		
		Set<Integer> jz=JvertexID_INeighborIDs_HashIndex.keySet();Iterator iterator = jz.iterator();		
		for (Integer j : jz) {
			this.JvertexID_INeighborIDs_HashIndex.get(j).remove(iID);
		}				
	}

	void remove_JVertex (Integer jID){
		//this.ivertexIDs_ivertexes.remove(v_i.ID);
		
		this.JvertexID_INeighborIDs_HashIndex.remove(jID);
		
		Set<Integer> iz=IvertexID_JNeighborIDs_HashIndex.keySet();Iterator iterator = iz.iterator();		
		for (Integer i : iz) {
			this.IvertexID_JNeighborIDs_HashIndex.get(i).remove(jID);
		}				
	}
}