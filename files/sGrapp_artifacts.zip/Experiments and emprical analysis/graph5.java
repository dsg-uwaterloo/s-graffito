
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import java.util.Vector;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Number;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import javax.management.ImmutableDescriptor;
import javax.swing.JFrame;

import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import ptolemy.plot.Plot;
import ptolemy.plot.PlotApplication;
//graph4+nodeIndexStart=graph5 and neighbors and some methods are not static in graph5
public class graph5<V> {
    static Map<Integer,ArrayList<Integer>> neighbors = new HashMap<Integer,ArrayList<Integer>>();
    public static double[] inDegreeDistribution;
    public static double[] outDegreeDistribution;
    public static int[] inDegree;
    public static int[] outDegree;
    public static double[][] AdjacencyMatrix;//to calculate eigenvalues matrix must be double[][]
    public static double[] AdjacencyMatrixImageEigenvalues;
    public static double[] AdjacencyMatrixRealEigenvalues;
    public static double[] AdjacencyMatrixEigenvalues;
    
    public static Map<Double, List<Double>>  AdjacencyMatrixEigenPairs= new HashMap<Double, List<Double>>();
    public static double[][] GoogleMatrix;
    public static double[] GoogleMatrixImageEigenvalues;
    public static double[] GoogleMatrixRealEigenvalues;
    public static Map<Double, List<Double>>  GoogleMatrixEigenPairs= new HashMap<Double, List<Double>>();
    //public static Map<Double[], List<Double>>  rightEigens= new HashMap<Double[], List<Double>>();//[normalizedRightEigenvector:[RealEigenvalue, ImaginaryEigenvalue, IPR]]
    //public static Map<Double[], List<Double>>  leftEigens= new HashMap<Double[], List<Double>>();//[normalizedLeftEigenvector:[RealEigenvalue, ImaginaryEigenvalue, IPR]]
    public static double[] rightIPR;
    public static double[] leftIPR;
    public static Map<Double,Double[]> rightIPRandeigenvectorMap=new HashMap<Double, Double[]>(); //[IPR:eigenvector]
    public static Map<Double,Double[]> leftIPRandeigenvectorMap=new HashMap<Double, Double[]>(); //[leftIPR:eigenvector]
    public static double[] RrealEigenvalues;
    public static double[] RimagEigenvalues;
    public static double[] LrealEigenvalues;
    public static double[] LimagEigenvalues;
    
    public static double[][] laplacianInMatrix;//to calculate eigenvalues matrix must be double[][]
    public static double[] laplacianInImageEigenvalues;
    public static double[] laplacianInRealEigenvalues;
    public static double[][] laplacianOutMatrix;//to calculate eigenvalues matrix must be double[][]
    public static double[] laplacianOutImageEigenvalues;
    public static double[] laplacianOutRealEigenvalues;
    public static Map<Double, List<Double>>  laplacianInEigenPairs= new HashMap<Double, List<Double>>();
    public static Map<Double, List<Double>>  laplacianOutEigenPairs= new HashMap<Double, List<Double>>();
    public static double[] RinrealEigenvalues;
    public static double[] RinimagEigenvalues;
    public static double[] LinrealEigenvalues;
    public static double[] LinimagEigenvalues;
    public static double[] RoutrealEigenvalues;
    public static double[] RoutimagEigenvalues;
    public static double[] LoutrealEigenvalues;
    public static double[] LoutimagEigenvalues;
    public static double[] rightIPRin;
    public static double[] leftIPRin;
    public static Map<Double,Double[]> rightIPRandeigenvectorMapin=new HashMap<Double, Double[]>(); //[IPR:eigenvector]
    public static Map<Double,Double[]> leftIPRandeigenvectorMapin=new HashMap<Double, Double[]>(); //[leftIPR:eigenvector]
    public static double[] rightIPRout;
    public static double[] leftIPRout;
    public static Map<Double,Double[]> rightIPRandeigenvectorMapout=new HashMap<Double, Double[]>(); //[IPR:eigenvector]
    public static Map<Double,Double[]> leftIPRandeigenvectorMapout=new HashMap<Double, Double[]>(); //[leftIPR:eigenvector]
        
    public static double InRatio;//lambdaNonZeroMinIn/lamdaNin
    public static double OutRatio;//LambdaNonzeroMinOut/LambdaMaxOut
	private double numeratorin;
	
	static double[][] pathLen;
	
	
    public graph5(){
    	neighbors = new HashMap<Integer,ArrayList<Integer>>();
    	AdjacencyMatrixEigenPairs= new HashMap<Double, List<Double>>();
    	GoogleMatrixEigenPairs= new HashMap<Double, List<Double>>();
    }
    
    //String representation of graph.
    public String toString () {
        StringBuffer s = new StringBuffer();
        for (Integer v: neighbors.keySet()) s.append("\n    " + v + " -> " + neighbors.get(v));
        return s.toString();                
    }
        
    public boolean contains (V vertex) {
        return neighbors.containsKey(vertex);
    }
    
    // Add a vertex to the graph.  Nothing happens if vertex is already in graph.
    public void add (Integer vertex) {
        if (neighbors.containsKey(vertex)) return;
        neighbors.put(vertex, new ArrayList<Integer>());
    }
    // Add an edge to the graph; if either vertex does not exist, it's added.
    public void add (Integer from, Integer to,Boolean directed) {
    	if (!directed) { //for undirected graph,self-loop and multi-edges are not allowed.
    		if (from.equals(to)| (neighbors.containsKey(from) && neighbors.get(from).contains(to))){  //this code is usefull when multi-edges are not allowed.
        		return;
        	}
		}
    	else{ //for directed multi-edges are allowed but self-loops are not.
    		if (from.equals(to)){  
        		return;
        	}
    	}
    	this.add(from); this.add(to);
    	neighbors.get(from).add(to);
    	if (!directed) {
    		neighbors.get(to).add(from);
		}    		
    }
    /**
     * Remove an edge from the graph.  Nothing happens if no such edge.
     * @throws IllegalArgumentException if either vertex doesn't exist.
     */
    public void remove (V from, V to, Boolean directed) {
        if (!(this.contains(from) && this.contains(to)))
            throw new IllegalArgumentException("Nonexistent vertex");
        neighbors.get(from).remove(to);
        if (!directed) {
        	neighbors.get(to).remove(from);
		}
    }
    
    //this methods generates int[][] matrix not double[][]
    //a[i][j]=1 if there is a link from j to i
    public static  int[][] getAdjacencyMatrix(int nodeIndexStart){
    	int N=neighbors.size();
		int[][] adjacencyMatrix=new int[N][N];
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				adjacencyMatrix[i][j]=0;
			}
		}
		for (int i = 0; i < N; i++){
			for (int j = 0; j < N; j++) {
				for (int k = 0; k < neighbors.get(i+nodeIndexStart).size(); k++) {
					if (neighbors.get(i+nodeIndexStart).get(k).equals(j+nodeIndexStart)){
						adjacencyMatrix[i][j]++;
					}
				}
			}//end for j	
		}//end for i					
		//AdjacencyMatrix=adjacencyMatrix;
		return adjacencyMatrix;
	}
    public static  int[][] getAdjacencyMatrixTranspose(int nodeIndexStart){
    	int N=neighbors.size();
		int[][] adjacencyMatrix=new int[N][N];
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				adjacencyMatrix[i][j]=0;
			}
		}
		for (int i = 0; i < N; i++){
			for (int j = 0; j < N; j++) {
				for (int k = 0; k < neighbors.get(j+nodeIndexStart).size(); k++) {
					if (neighbors.get(j+nodeIndexStart).get(k).equals(i+nodeIndexStart)){ 
						adjacencyMatrix[i][j]++;
					}
				}
			}//end for j	
		}//end for i					
		//AdjacencyMatrix=adjacencyMatrix;
		return adjacencyMatrix;
	}
    public static  int[][] getAdjacencyMatrixRDG(int nodeIndexStart){
    	int N=neighbors.size();
		int[][] adjacencyMatrix=new int[N][N];
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				adjacencyMatrix[i][j]=0;
			}
		}
		for (int i = 0; i < N; i++){
			for (int j = 0; j < N; j++) {
				for (int k = 0; k < neighbors.get(i+nodeIndexStart).size(); k++) {
					if (neighbors.get(i+nodeIndexStart).get(k).equals(j+nodeIndexStart)){  
						adjacencyMatrix[i][j]=1;
					}	
				}
			}//end for j	
		}//end for i
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if (adjacencyMatrix[i][j]==1 && adjacencyMatrix[j][i]==0) {
					adjacencyMatrix[i][j]=1;
				}
			}
		}
		//AdjacencyMatrix=adjacencyMatrix;
				
		return adjacencyMatrix;
	}
    public static  int[][] getAdjacencyMatrixRDGTranspose(int nodeIndexStart){
    	int N=neighbors.size();
		int[][] adjacencyMatrix=new int[N][N];
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				adjacencyMatrix[i][j]=0;
			}
		}
		for (int i = 0; i < N; i++){
			for (int j = 0; j < N; j++) {
				for (int k = 0; k < neighbors.get(j+nodeIndexStart).size(); k++) {
					if (neighbors.get(j+nodeIndexStart).get(k).equals(i+nodeIndexStart)){ 
						adjacencyMatrix[i][j]=1;
					}	
				}
			}//end for j	
		}//end for i
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if (adjacencyMatrix[i][j]==1 && adjacencyMatrix[j][i]==0) {
					adjacencyMatrix[i][j]=2;
				}
			}
		}
		//AdjacencyMatrix=adjacencyMatrix;
		
		/*int sum=0;
		for (int i = 0; i <N; i++) {
			for (int j = 0; j < N; j++) {
				sum+=adjacencyMatrix[i][j];
			}
		}
		System.out.println("GRAPH5-222- > sum of Aij="+sum);*/
		
		return adjacencyMatrix;
	}
    //this method set the double[][] adjacency matrix-Aij
    public static  void setAdjacencyMatrix(int nodeIndexStart,boolean directed){//in this method AdjacencyMatrix[i][j]=number of links from i to j
    	int N=neighbors.size();
		double[][] adjacencyMatrix=new double[N][N];
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				adjacencyMatrix[i][j]=0;
			}
		}
		for (int i = 0; i < N; i++)
			for (int j = 0; j < N; j++) 
				for (int k = 0; k < neighbors.get(i+nodeIndexStart).size(); k++) {
					if (neighbors.get(i+nodeIndexStart).get(k).equals(j+nodeIndexStart)){
						adjacencyMatrix[i][j]++;
					}
				//for (int k = 0; k < neighbors.get(i+nodeIndexStart).size(); k++) {
					//if (neighbors.get(i+nodeIndexStart).get(k).equals(j+nodeIndexStart)) adjacencyMatrix[i][j]++;
					//change 2 to 1 - for directedSmallworld.java
					//if (adjacencyMatrix[i][j]==2) {
						//adjacencyMatrix[i][j]=1;
					//}
				}
		if(directed)
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					if (adjacencyMatrix[i][j]==1 && adjacencyMatrix[j][i]==0) {
						adjacencyMatrix[i][j]=1;
					}
				}
			}
		AdjacencyMatrix=adjacencyMatrix;		
	}
	public void printAdjacencyMatrix(int nodeIndexStart,boolean directed){
		//int rowSum=0;
		//int colSum=0;
		//int sum=0;
		//int sumC=0;
		setAdjacencyMatrix(nodeIndexStart,directed);
		System.out.println();
		System.out.println("\n    Adjacency Matrix:");
		for (int i = 0; i <AdjacencyMatrix.length; i++) {
			System.out.print("   ");
			//rowSum=0;
			//colSum=0;
			for (int j = 0; j < AdjacencyMatrix.length; j++) {
				System.out.print(AdjacencyMatrix[i][j]+"    ");
				//rowSum+=A[i][j];
				//colSum+=A[j][i];
			}
			System.out.println();
			//System.out.println("rowSum:"+rowSum+" , colSum:"+colSum);
			//sum+=rowSum;
		}
		//System.out.println("graph3 line140- sum of rowSums:"+sum);
	}
    public void PrintNumberOfAllLinks(int[][] adjacency){//returns number of none zero elements of adjacency matrix  
    	int numberOfLinks=0;
    	int N=adjacency.length;
    	for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if (adjacency[i][j]!=0) {
					numberOfLinks++;
				}
			}
		}
    	System.out.println("number of all links in the graph = "+numberOfLinks);
    }
    
    
	public static void setLaplacianMatrix(int[][] adjacencyMatrix){ ///////////////////////////////////////*2
		int N=adjacencyMatrix.length;
		laplacianInMatrix=new double[N][N];
		laplacianOutMatrix=new double[N][N];
		//----------------------------------setting inDegree and outDegree for each node--------------
		inDegree=new int[N];
		outDegree=new int[N];
		for (int i = 0; i < N; i++) {
			inDegree[i]=0;outDegree[i]=0;
			for (int j = 0; j < N; j++) {
				inDegree[i]+=adjacencyMatrix[j][i];
				outDegree[i]+=adjacencyMatrix[i][j];//System.out.print(adjacencyMatrix[i][j]+" ");
				//outDegree[i]+=adjacencyMatrix[j][i];
				//inDegree[i]+=adjacencyMatrix[i][j];
			}//System.out.println();
		}
		//----------------------------------set laplacianINcand laplacianOut----------------------------
		//System.out.println("\nlaplacianOutMatrix");
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if(i!=j){
					laplacianInMatrix[i][j]=-adjacencyMatrix[i][j];
					laplacianOutMatrix[i][j]=-adjacencyMatrix[i][j];
				}
				else{
					laplacianInMatrix[i][j]=inDegree[i];
					laplacianOutMatrix[i][j]=outDegree[i];
				}//System.out.print(laplacianOutMatrix[i][j]+"  ");
			}
			//System.out.println();
		}
	}
	public static void setLaplacianMatrixTranspose(int[][] adjacencyMatrix){ ///////////////////////////////////////*2
		int N=adjacencyMatrix.length;
		laplacianInMatrix=new double[N][N];
		laplacianOutMatrix=new double[N][N];
		//----------------------------------setting inDegree and outDegree for each node--------------
		inDegree=new int[N];
		outDegree=new int[N];
		for (int i = 0; i < N; i++) {
			inDegree[i]=0;outDegree[i]=0;
			for (int j = 0; j < N; j++) {
				outDegree[i]+=adjacencyMatrix[j][i];
				inDegree[i]+=adjacencyMatrix[i][j];
			}
		}
		//----------------------------------set laplacianINcand laplacianOut----------------------------
		//System.out.println("\nlaplacianOutMatrix");
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if(i!=j){
					laplacianInMatrix[i][j]=-adjacencyMatrix[i][j];
					laplacianOutMatrix[i][j]=-adjacencyMatrix[i][j];
				}
				else{
					laplacianInMatrix[i][j]=inDegree[i];
					laplacianOutMatrix[i][j]=outDegree[i];
				}//System.out.print(laplacianOutMatrix[i][j]+"  ");
			}
			//System.out.println();
		}
	}
	public double[][] getLaplacian(int nodeIndexStart, boolean In, boolean directed){
		if(directed){
			setLaplacianMatrix(getAdjacencyMatrixRDG(nodeIndexStart));
		}
		else{
			setLaplacianMatrix(getAdjacencyMatrix(nodeIndexStart));
		}
		if (In) {
			return this.laplacianInMatrix;
		}
		else{
			return this.laplacianOutMatrix;
		}
	}
	public double[][] getLaplacianTranspose(int nodeIndexStart, boolean In, boolean directed){
		if(directed){
			setLaplacianMatrixTranspose(getAdjacencyMatrixRDG(nodeIndexStart));
		}
		else{
			setLaplacianMatrixTranspose(getAdjacencyMatrix(nodeIndexStart));
		}
		if (In) {
			return this.laplacianInMatrix;
		}
		else{
			return this.laplacianOutMatrix;
		}
	}
	
	public static void main(String[] args) throws IOException, WriteException, BiffException {
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		ArrayList<Integer> a=new ArrayList<Integer>();
		for (int i = 0; i <8; i++) {
			a.add(i);
			System.out.println(a+" "+a.get(0));
		}a.set(a.size(), 66);System.out.println(a);
		
		/*
		graph5 g=new graph5();
		for (int i = 0; i <8; i++) {
			g.add(i);
		}*/
		/*g.add(0,1,false);
		g.add(0,2,false);
		g.add(0,7,false);
		g.add(0,6,false);
		g.add(1,2,false);
		g.add(1,3,false);
		g.add(1,7,false);
		g.add(2,3,false);
		g.add(2,4,false);
		g.add(3,4,false);
		g.add(3,5,false);
		g.add(4,5,false);
		g.add(4,6,false);
		g.add(5,6,false);
		g.add(5,7,false);
		g.add(6,7,false);
		*/
		
		/*g.add(0,1,false);
		g.add(0,2,false);
		g.add(0,3,false);
		g.add(0,4,false);
		g.add(0,5,false);
		g.add(1,2,false);
		g.add(1,3,false);
		g.add(2,5,false);
		g.add(3,4,false);
		*/
		//directedEulerGraph2 dbg=new directedEulerGraph2(g, 1);
		//System.out.println("dbg: "+dbg.graph.neighbors);
		
		
		///BarabasiAlbertGraph ba=new BarabasiAlbertGraph(6, false, 3, 2);
		//System.out.println("BA: "+ba.graph.neighbors);
		//System.out.println("Start time: "+dateFormat.format(cal.getTime()));
		
		//numberOfComponents(readlistCreatGraph("u-operon-operon-0",755,false));
		//ShortestLoopLength(readlistCreatGraph("d-operon-operon-0",755,true));		
		
		/*
		undirectedWattsStrogatz3 u;
		graph5 Ugraph2;
		int N=800;
		int k=6;
		double p=1;
		double[][] RDGlap=new double[N][N];
		double[][] RADlap=new double[N][N];
		BufferedWriter bwRDG;
		BufferedWriter bwRAD;
		
		for (int n = 0; n < 3; n++) {
			u=new undirectedWattsStrogatz3(N,k,p);
			Ugraph2=new graph5<Integer>();
			for (int h = 0; h < N; h++) {
				Ugraph2.add(h);
			}
			Vector<Integer> e=new Vector<Integer>(2);
			Vector<Vector<Integer>> list=u.edgesList;
			int s=list.size();
			for (int ii = 0; ii < s; ii++) {
				e=list.elementAt(ii);
				Ugraph2.add(e.elementAt(0), e.elementAt(1), false);
			}
			
			//list for RAD
			Vector<Vector<Integer>> RADlist=new Vector<Vector<Integer>>();
			//Vector<Vector<Integer>> Ulist=Ugraph2.edgesList(0);
			for (int ii = 0; ii < s; ii++) {
				RADlist.add(list.elementAt(ii));
			}System.out.println("5992 - RADlist size="+RADlist.size()+" >> "+RADlist);
			
			directedRDGgraph RDG =new directedRDGgraph(u.graph, 1);	
			System.out.println("\nwritting "+n+"-RDGlap-p="+p);//+"="+RDG.graph.edgesList(0).size());
			RDGlap=RDG.graph.getLaplacian(0, false,true);
			bwRDG= new BufferedWriter(new FileWriter(new File(n+"-RDGlap-p="+p+".txt")));
			double sum2=0;
			for (int i = 0; i < N; i++) {
				sum2=0;
				for (int j = 0; j < N; j++) {
					if (j!=N-1) {
						sum2+=RDGlap[i][j];
						bwRDG.append(RDGlap[i][j]+" ");
					}
					else{
						sum2+=RDGlap[i][j];
						bwRDG.append(RDGlap[i][j]+"");
						bwRDG.newLine();
					}
				}//end for j
				System.out.println("  "+i+">"+sum2);
			}//end for i
			bwRDG.close();System.out.println("6012 - RDGlist size="+RDG.graph.edgesList(0).size());writeToExcel(RDG.graph.edgesList(0), n+"-RDG-p="+p);
			//======================================== RAD ==============================================
			RAD RAD=new RAD(RADlist, 1);				
			graph5<Integer> RADgraph=new graph5();
			for (int i = 0; i < u.graph.neighbors.size(); i++) {
				RADgraph.add(i);
			}
			
			int src, dest;
			for (int i = 0; i < RAD.edgesList.size(); i++) {
				src=RAD.edgesList.elementAt(i).elementAt(0);
				dest=RAD.edgesList.elementAt(i).elementAt(1);
				RADgraph.add(src, dest, true);
			}
			//+"="+RADgraph.edgesList(0).size());
			
			System.out.println("\nwritting "+n+"-RADlap-p="+p);
			RADlap=RADgraph.getLaplacian(0, false,true);
			bwRAD= new BufferedWriter(new FileWriter(new File(n+"-RADlap-p="+p+".txt")));
			double sum=0;
			for (int i = 0; i < N; i++) {
				sum=0;
				for (int j = 0; j < N; j++) {
					if (j!=N-1) {
						sum+=RADlap[i][j];
						bwRAD.append(RADlap[i][j]+" ");
					}
					else{
						sum+=RADlap[i][j];
						bwRAD.append(RADlap[i][j]+"");
						bwRAD.newLine();
					}
				}//end for j
				System.out.println("  "+i+">"+sum);
			}//end for i
			bwRAD.close();System.out.println("6042- RAD.edgesList size="+RAD.edgesList.size());writeToExcel(RAD.edgesList, n+"-RAD-p="+p);
		}
		*/	
		
		//plotSpectralDensity_WS_U_E_RDG_RAD(20, 800, 6, 0, 0.15);
		//plotSpectralDensity_WS_U_E_RDG_RAD(20, 800, 6, 0.01, 0.15);
		//plotSpectralDensity_WS_U_E_RDG_RAD(20, 800, 6, 0.3, 0.15);
		//plotSpectralDensity_WS_U_E_RDG_RAD(20, 800, 6, 1, 0.15);
		
		//int[] k={6};
		//double[] p={0.01,0.2,1};
		//plotLoopDist_WS_U_E_RAD_RDG(800,k,p);
		
		//double[] p={0, 0.0001, 0.0003, 0.0005, 0.0007, 0.0009, 0.001, 0.003, 0.005, 0.007, 0.009, 0.01, 0.03, 0.05, 0.07, 0.09, 0.1, 0.3, 0.5, 00.7, 0.9, 1.0};//{0, 0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0};{0, 0.0001, 0.0004, 0.0008, 0.001, 0.004, 0.008, 0.01, 0.04, 0.08, 0.1, 0.2, 0.4, 0.6, 0.8, 1};
		//plotCpC0LpL0_loops(20,800,8,p,4);
		
		//plot_NumberOfDirectedTriangles(50,800,6,1);
		
		//plot_MaxLoopLen_MaxImg_NumberofTriangles(50,800,6,1);
		
		//int M=800;
		//int[] K={6};
		//double[] P={0.01,0.2,1};
		//plotLoopDist_WS_U_E_RAD_RDG(M,K,P);
				
		//readExcel_writeShortestPaths("RDG1","RDG2",800,true,true);
		
		/*for (int i = 0; i < 50; i++) {
			WriteEdgeslistsOfCONNECTED_WS_U_E_RDG_RAD(800, 6, 1, i);
		}*/
		
		//undirectedWattsStrogatz3 U=new undirectedWattsStrogatz3(18,2,0.3);
		//directedRDGgraph RDG=new directedRDGgraph(U.graph,1);
		//RDG.graph.setLaplacianMatrix(RDG.graph.getAdjacencyMatrix(0));
		//double[][]l=RDG.graph.laplacianOutMatrix;
		/*System.out.println("\nU:"+U.edgesList);
		System.out.println("\nlaplacian out:\n");
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				System.out.print(l[i][j]+" ");
			}System.out.println();
		}*/
		/*double[] reals=matlabSortedRealEig(l);
		System.out.println("size="+reals.length);
		for (int j = 0; j < 18; j++) {
			System.out.println(reals[j]);
		}*/
		
		//WriteLaplacianOut_WS_U_E_RDG_RAD(800, 6, 1);
		
		//readAdjacencyWriteEdgelist("RADlap0.3", 800);
		//readAdjacencyWriteEdgelist("Ulap0.3", 800);
		//readAdjacencyWriteEdgelist("WSlap0.3", 800);
		//readAdjacencyWriteEdgelist("Elap0.3", 8);
		//readAdjacencyWriteEdgelist("RDGlap0.3", 8);
		
		//readExcelEdgeslistRunAverageKuramato("theta0","omega0",1,"RDG2",true,"",false,"",false,"",false,800,6,0.3,20);
		
		/*
		Random generator = new Random();
		double[] teta = new double[5];
		double d=0;
		for (int i = 0; i < 5; i++) {
			d=generator.nextDouble();
			teta[i] = (Math.toRadians(d * 360.0)-180);
			System.out.println(teta[i]);
		}*/
		
		//loop len distribution
		//double[] p={0, 0.0001, 0.0003, 0.0005, 0.0007, 0.0009, 0.001, 0.003, 0.005, 0.007, 0.009, 0.01, 0.03, 0.05, 0.07, 0.09, 0.1, 0.3, 0.5, 00.7, 0.9, 1.0};//{0, 0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0};{0, 0.0001, 0.0004, 0.0008, 0.001, 0.004, 0.008, 0.01, 0.04, 0.08, 0.1, 0.2, 0.4, 0.6, 0.8, 1};
    	//for (int j = 0; j < p.length; j++) {
    		
    		//undirectedWattsStrogatz3 U=new undirectedWattsStrogatz3(800,6,0.3);
    		//writeToExcel(U.graph.edgesList(0), "U - 800 - 6 - 0.3");
    		/*System.out.println("\n\nU:"+U.graph.neighbors);
    		directedRDGgraph RDG=new directedRDGgraph(U.graph,1);
    		System.out.println("\n\nRDG:"+RDG.graph.neighbors);
    		//plotLoopLengthDistribution(LoopLengthDistribution(RDG.graph),"RDG n=10 k=4 p=0.1");
    		
    		double[][] a=RDG.graph.getLaplacian(0, false, true);
    		for (int i = 0; i < a.length; i++) {
				for (int j = 0; j < a.length; j++) {
					System.out.print(a[i][j]+" ");
				}System.out.println();
			}*/
    		
    		
    		//System.out.println("\n\n-----------------------------Adjacency----------------------");
    		//RDG.graph.setAdjacencyMatrixSpectrum(0, true);
    		//plotSpectra(1, RDG.graph.AdjacencyMatrixRealEigenvalues, RDG.graph.AdjacencyMatrixImageEigenvalues, "RDG");
    		
    		//System.out.println("\n\n-----------------------------laplacian----------------------");
    		//RDG.graph.setlacianMatricesSpectrumRDG(0);
    		//plotSpectra(1, RDG.graph.laplacianOutRealEigenvalues, RDG.graph.laplacianOutImageEigenvalues, "RDG");
		//}
				
		/*
		undirectedWattsStrogatz3 U=new undirectedWattsStrogatz3(800,6,0.3);
		Vector<Vector<Integer>> list=new Vector<Vector<Integer>>();
		Vector<Vector<Integer>> Ulist=U.graph.edgesList(0);
		for (int ii = 0; ii < Ulist.size(); ii++) {
			list.add(Ulist.elementAt(ii));
		}
				
		directedEulerGraph2 E =new directedEulerGraph2(U, 1);
		E.graph.setAdjacencyMatrix(0,true);
		Matrix A=new Matrix(E.graph.AdjacencyMatrix);
		Matrix A3=A.times(A);A3=A3.times(A);
		System.out.println("E:"+A3.trace()+"\n");
		
		RAD RAD=new RAD(list, 1);
		graph5<Integer> RADgraph=new graph5();
		for (int ii = 0; ii < U.graph.neighbors.size(); ii++) {
			RADgraph.add(ii);
		}
		int src, dest;
		for (int ii = 0; ii < RAD.edgesList.size(); ii++) {
			src=RAD.edgesList.elementAt(ii).elementAt(0);
			dest=RAD.edgesList.elementAt(ii).elementAt(1);
			RADgraph.add(src, dest, true);
		}
		RADgraph.setAdjacencyMatrix(0,true);
		Matrix A2=new Matrix(RADgraph.AdjacencyMatrix);
		Matrix A32=A2.times(A2);A3=A32.times(A2);
		System.out.println("RAD:"+A3.trace());
		
		//directedRDGgraph RDG =new directedRDGgraph(U.graph, 1);
		
		/*writeToExcel(RDG.graph.edgesList(0), "RDG");
		int[][] adjacency=RDG.graph.getAdjacencyMatrixRDG(0);
		int[][] adjacencyMatrix = new int[801][801];
		for (int i = 1; i <= 800; i++) {
			for (int j = 1; j <= 800; j++) {
				adjacencyMatrix[i][j]=adjacency[i-1][j-1];
			}
		}
		kuramatoadj4 k2=new kuramatoadj4(adjacencyMatrix,"rdg",800,6,0.3,1,600,20);
		kuramatoadj4.plotTimeAndr(k2.timeAndr, "N=800 k=6 p=0.3 NN=20");
			
		//double range=0.16;
		//plotSpectralDensity_WS_U_E_RDG_RAD(10, 800, 6, 1, range);
		//plotSpectralDensity_WS_U_E_RDG_RAD(20, 800, 6, 0.3, range);
		//plotSpectralDensity_WS_U_E_RDG_RAD(20, 800, 6, 0.01, range);
		//plotSpectralDensity_WS_U_E_RDG_RAD(1, 800, 6, 1, range);
		
		//int averageNum=10;
		//int N=800;
    	//int k=8;
    	//double[] p={0, 0.0001, 0.0002, 0.0003, 0.0004, 0.0005, 0.0006, 0.0007, 0.0008, 0.0009, 0.001, 0.002, 0.003, 0.004, 0.005, 0.006, 0.007, 0.008, 0.009, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1, 0.3, 0.5, 00.7, 0.9, 1.0};//{0, 0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0};{0, 0.0001, 0.0004, 0.0008, 0.001, 0.004, 0.008, 0.01, 0.04, 0.08, 0.1, 0.2, 0.4, 0.6, 0.8, 1};
    	//double[] p={0, 0.0001, 0.0003, 0.0005, 0.0007, 0.0009, 0.001, 0.003, 0.005, 0.007, 0.009, 0.01, 0.03, 0.05, 0.07, 0.09, 0.1, 0.3, 0.5, 00.7, 0.9, 1.0};//{0, 0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0};{0, 0.0001, 0.0004, 0.0008, 0.001, 0.004, 0.008, 0.01, 0.04, 0.08, 0.1, 0.2, 0.4, 0.6, 0.8, 1};
    	//System.out.println("N="+N+" - k="+k+" - average of "+averageNum);
    	//plotCpC0LpL0_loops(averageNum,N,k,p,1);//Euler1_RAD2_RDG3_WS4_U5
    	//plotCpC0LpL0_loops(averageNum,N,k,p,3);
    	//plotCpC0LpL0_loops(averageNum,N,k,p,2);
    	/*for (int i = 3; i <= 5; i++) {
    		plotCpC0LpL0_loops(averageNum,N,k,p,i);
    		//plot_CpC0_LpL0_cycle(20, 800, 6, p, i);
        	//plot_CpC0_LpL0_Middleman(20, 800, 6, p, i);
        	//plot_CpC0_LpL0_in(20, 800, 6, p, i);
        	//plot_CpC0_LpL0_out(20, 800, 6, p, i);
		}*/
		
		/*graph5<Integer> g=new graph5<Integer>();
    	for (int i = 0; i < 7; i++) {
			g.add(i);
		}
    	g.add(0,3,true);
    	g.add(3,2,true);
    	g.add(2,1,true);
    	g.add(1,0,true);
    	//g.add(2,5,true);
    	g.add(5,4,true);
    	g.add(4,6,true);
    	g.add(6,5,true);
    	
    	/*g.add(0,1,true);
    	g.add(2,0,true);
    	g.add(1,2,true);
    	g.add(1,3,true);
    	g.add(2,3,true);
    	g.add(3,0,true);*/
    	//System.out.println("\n\n>> number of components:"+numberOfComponents(g));
    	/*g.setAdjacencyMatrixSpectrum(0, true);
    	double[] reals=g.AdjacencyMatrixRealEigenvalues;
    	double[] imgs=g.AdjacencyMatrixImageEigenvalues;
    	for (int i = 0; i < 10; i++) {
			System.out.println(reals[i]+" , "+imgs[i]);
		}
    	
    	System.out.println("\n\nAdjacency\n");
    	int[][] a=g.getAdjacencyMatrix(0);
    	for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				System.out.print(a[i][j]+"\t");
			}System.out.println();
		}*/
    	/*double[][] a=g.laplacianInMatrix;
    	double s;
    	for (int i = 0; i < a.length; i++) {
    		s=0;
    		for (int j = 0; j < a.length; j++) {
    			//s+=a[i][j];
        		System.out.print(a[i][j]+" ");
    		}System.out.println();
		}*/
		
		/*
		int N=10;
		BufferedWriter bwRDG= new BufferedWriter(new FileWriter(new File("RDGlap.txt")));
		undirectedWattsStrogatz3 net=new undirectedWattsStrogatz3(N, 2, 0.2);
		directedRDGgraph RDG=new directedRDGgraph(net.graph,1);
		RDG.graph.setlacianMatricesSpectrumRDG(0);
		System.out.println("laplacian out matrix");
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				System.out.print(RDG.graph.laplacianOutMatrix[i][j]);
			}System.out.println();
		}
		
		plotSpectra(1, RDG.graph.laplacianOutRealEigenvalues, RDG.graph.laplacianOutImageEigenvalues, "");
				
		System.out.println("\n\nwritting laplacian out of RDG..");
		double[][] RDGlap=RDG.graph.getLaplacian(0, false,true);
		
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if (j!=N-1) {
					bwRDG.append(RDGlap[i][j]+"\t");
				}
				else{
					bwRDG.append(RDGlap[i][j]+"");
					bwRDG.newLine();
				}
			}//end for j
		}//end for i
		bwRDG.close();
		*/
				
    	//celegants
    	/*graph5 graph=new graph5();
    	for (int i = 0; i < 306; i++) {
			graph.add(i);
		}
    	FileInputStream fstream = new FileInputStream("celegans.txt");
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		String line; 
		String[] lineNumbers;
		for (int row = 0; row < 2345; row++) {
			line= br.readLine();
		    lineNumbers=line.split(" ");
		    graph.add(Integer.parseInt(lineNumbers[0])-1,Integer.parseInt(lineNumbers[1])-1,true);
		}
		System.out.println(numberOfComponents(graph));
		*/
		/*
		//-------------------------------------------loop len distribution for celegans network-------------------------------------
		plotLoopLengthDistribution(LoopLengthDistribution(graph), "");
		//-------------------------------------------plot x=node i y= number loops of any length including node i-------------------		
    	double[][] looplengths=ShortestLoopLength(graph);
		double[] loopsNumber=new double[306];
    	for (int i = 0; i < 306; i++) {
			for (int j = 0; j < 306; j++) {
				if (looplengths[i][j]>2) {
					//System.out.println("looplength["+i+"]["+j+"]="+looplengths[i][j]);
					loopsNumber[i]+=1;
				}			
			}
		}
    	plot(loopsNumber, "Number of loops over nodes", "node i", "", false, false, 1);
    	//--------------------------------------------plot spectrum of laplacian matrix---------------------------------------------
    	graph.setlacianMatricesSpectrumRDG(0);
    	plotSpectra(1, graph.laplacianOutRealEigenvalues, graph.laplacianOutImageEigenvalues, "Spectrum of celegans");
    	*/
    	   	
    	//readExcelEdgeslistRunAverageKuramato(5, "WS - N=800 - k=6 - p=0.01", true, "U - N=800 - k=6 - p=0.01", false, "E - N=800 - k=6 - p=0.01", true, "RDG - N=800 - k=6 - p=0.01", true, 800, 6, 0.01);    	
    	
    	//plotCpLp(20, 800, 6, p, 3);
    	//read r vs time from xml and plot it
    	//double[] rU=readXml("U k=6 p=0.4",700);
    	//double[] rE=readXml("E k=6 p=0.4",700);
		//...sth about plotting is removed    	
    	/*
    	int N=800;
    	int k=6;
    	double p=0.2;
    	
		undirectedWattsStrogatz3 U=new undirectedWattsStrogatz3(N,k,p);
		BufferedWriter bwU= new BufferedWriter(new FileWriter(new File("lap.txt")));
		System.out.println("\nwritting adjacency of U-");
		double[][] l=U.graph.getLaplacian(0, false);
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if (j!=N-1) {
					bwU.append(l[i][j]+"\t");
					//System.out.print(adjacencyU[i][j]+"\t");
				}
				else{
					bwU.append(l[i][j]+"");
					bwU.newLine();
					//System.out.println(adjacencyU[i][j]);
				}
			}//end for j
		}//end for i
		bwU.close();*/
		
		/*directedEulerGraph2 E =new directedEulerGraph2(U, 1);
		System.out.println("E edgeslist:"+E.edgesList);
		int[][] adjacencyE=E.graph.getAdjacencyMatrix(0);
		int[][] adjacencyMatrix=new int[N+1][N+1];
		//copying the adjacency matrix[0..255][0..255] to matrix a[0..256][0..256] and change 2 to 1
		for (int i = 1; i <= N; i++) {
			for (int j = 1; j <= N; j++) {
				adjacencyMatrix[i][j]=2*adjacencyE[i-1][j-1];
			}
		}
		//kuramato=new kuramatoadj3(adjacencyMatrix,theta_0);
		kuramatoadj4 kuramato=new kuramatoadj4(adjacencyMatrix,"test", N, k, p);
		double[][] matrix3=kuramato.timeAndr;
		kuramatoadj4.plotTimeAndr(matrix3, "1");
				
    	writeToExcel(E.edgesList, "test2");*/
    	/*try {
			readExcelEdgeslistRunKuramato("WSA - N=800 - k=6 - p=1.0",true, "U - N=800 - k=6 - p=1.0", false,"E - N=800 - k=6 - p=1.0",true, N, k, p);
		} catch (WriteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
				    	
    	//readUadjacencyWriteEulerEdgelist("ad", 800);
    	
    	//readAdjacencyWriteEdgelist("a",3);
    	
    	//write_Edgeslist_Of_WSUE(800,6,1);    	
    	
    	//WStoUtoEDynamicPlots(256, 4, 0.01);
		//plotCorrelationMatrices("WS",1, 61, 600, 10, 800, 4, 0.01);
		    	
		/*int N=300;
		int k=10;
		double p=0.01;
		directedWattsStrogatz7 ws;
		graph5 WSgraph, Ugraph;
		int[][] adjacencyWS;
		double[] SortedlaplacianOutRealEigenvaluesU;
		int index2U;
		double Lambda2U;
		do {
			ws=new directedWattsStrogatz7(N,k,1,0,p,0,0);
			WSgraph=ws.graph;
			adjacencyWS=WSgraph.getAdjacencyMatrix(0);						
			
			Ugraph=new graph5<Integer>();
			for (int i = 0; i < N; i++) {
				Ugraph.add(i);
			}
			for (int ii = 0; ii < N; ii++) {
				for (int j = 0; j < N; j++) {
					if (adjacencyWS[ii][j]==1 ){
						Ugraph.add(ii, j, false);
					}
				}
			}
			Ugraph.setlacianMatricesSpectrum(0);
	    	SortedlaplacianOutRealEigenvaluesU=Ugraph.laplacianOutRealEigenvalues;Arrays.sort(SortedlaplacianOutRealEigenvaluesU);
			index2U=0;
			Lambda2U=SortedlaplacianOutRealEigenvaluesU[index2U];
			while (Lambda2U<=0.00001) {
				index2U++;
				Lambda2U=SortedlaplacianOutRealEigenvaluesU[index2U];
			}
    	} while (index2U>1);
    	//===================================WS B===============================================
		int[][] adjacencyMatrix=new int[N+1][N+1];
		//copying the adjacency matrix[0..255][0..255] to matrix a[0..256][0..256] and change 2 to 1
		for (int i = 1; i <= N; i++) {
			for (int j = 1; j <= N; j++) {
				adjacencyMatrix[i][j]=adjacencyWS[i-1][j-1];
				if (adjacencyMatrix[i][j]==2) {
					adjacencyMatrix[i][j]=1;
				}
			}
		}
		kuramatoadj4 kuramato=new kuramatoadj4(adjacencyMatrix,"WStest");
		writePathLenAndShortestLoopLenMatrixtoFile(WSgraph,"WStest");
		*/
		
		//double alpha=1;
		//int[] k={9};
	    //double[] p={}; 
	    //double[] p={0.004, 0.005, 0.006, 0.008, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06};////, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0};
	    //double[] p={0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0};
	    //double[] p={0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0};
    	//writeAverageLoopLenToFile(800, 1, k, p, alpha);
    	//WStoUtoEplots(800,k,p,alpha);
	        	
    	/*int averageNumber=20;
    	int[] N={300,400,500,600,700,800};//,900,1000};//
    	//int[] N={500,500,500,500,500,500,500,500,500,500};
    	int K=4;
    	//double[] P={0.001,0.002,0.003,0.004,0.005,0.006,0.007,0.008,0.009,0.01};
    	double[] P={0.003,0.003,0.003,0.003,0.003,0.003,0.003,0.003};
    	double alpha=1;
    	plotLambdaNtoLambda2AndMaxImgforMultipleGraphs(averageNumber, N, K, P, alpha);*/
    				
    	//ShortestLoopLength(g);
		/*writePathLenAndShortestLoopLenMatrixtoFile(g,"sample");*/
		
    	/*int N=500;
    	int K=4;
    	double P=0.1;
    	directedEulerGraph2 E=new directedEulerGraph2(new undirectedWattsStrogatz3(N,K,P),1);
    	String caption="Euler graph with N="+N+" k="+K+" P="+P;
    	plotLoopLengthDistribution(LoopLengthDistribution(E.graph),caption);
    	System.out.println("\n"+caption+" - abundant len="+abundantLoopLen(E.graph));
    	System.out.println("average loop length="+averageLoopLen(E.graph));
    	
    	N=500;
    	K=6;
    	P=0.1;
    	E=new directedEulerGraph2(new undirectedWattsStrogatz3(N,K,P),1);
    	caption="Euler graph with N="+N+" k="+K+" P="+P;
    	plotLoopLengthDistribution(LoopLengthDistribution(E.graph),caption);
    	System.out.println("\n"+caption+" - abundant len="+abundantLoopLen(E.graph));
    	System.out.println("average loop length="+averageLoopLen(E.graph));
    	
    	N=500;
    	K=8;
    	P=0.1;
    	E=new directedEulerGraph2(new undirectedWattsStrogatz3(N,K,P),1);
    	caption="Euler graph with N="+N+" k="+K+" P="+P;
    	plotLoopLengthDistribution(LoopLengthDistribution(E.graph),caption);
    	System.out.println("\n"+caption+" - abundant len="+abundantLoopLen(E.graph));
    	System.out.println("average loop length="+averageLoopLen(E.graph));
    	
    	N=500;
    	K=4;
    	P=0.3;
    	E=new directedEulerGraph2(new undirectedWattsStrogatz3(N,K,P),1);
    	caption="Euler graph with N="+N+" k="+K+" P="+P;
    	plotLoopLengthDistribution(LoopLengthDistribution(E.graph),caption);
    	System.out.println("\n"+caption+" - abundant len="+abundantLoopLen(E.graph));
    	System.out.println("average loop length="+averageLoopLen(E.graph));
    	
    	N=500;
    	K=6;
    	P=0.3;
    	E=new directedEulerGraph2(new undirectedWattsStrogatz3(N,K,P),1);
    	caption="Euler graph with N="+N+" k="+K+" P="+P;
    	plotLoopLengthDistribution(LoopLengthDistribution(E.graph),caption);
    	System.out.println("\n"+caption+" - abundant len="+abundantLoopLen(E.graph));
    	System.out.println("average loop length="+averageLoopLen(E.graph));
    	
    	N=500;
    	K=8;
    	P=0.3;
    	E=new directedEulerGraph2(new undirectedWattsStrogatz3(N,K,P),1);
    	caption="Euler graph with N="+N+" k="+K+" P="+P;
    	plotLoopLengthDistribution(LoopLengthDistribution(E.graph),caption);
    	System.out.println("\n"+caption+" - abundant len="+abundantLoopLen(E.graph));
    	System.out.println("average loop length="+averageLoopLen(E.graph));
    	*/
    	
    	/*System.out.println(g.neighbors);
    	Graph G=createDirectedJungGgraph(g.getAdjacencyMatrix(0));
    	Set vertices=G.getVertices();
		DijkstraShortestPath p=new DijkstraShortestPath(G);
		for (Object vi : vertices) {
			for (Object vj : vertices) {
				System.out.println("shortest path length fom "+vi+" to "+vj+" : "+p.getPath((Vertex)vi, (Vertex)vj).size());
			}
		}*/
    	
    	//plotLambda2LambdaNformultipleGraphs(1, 800, 4, 0.01);
    	
    	/*int[][] a=new int[4][4];
    	a[0][0]=0;a[0][1]=0;a[0][2]=1;a[0][3]=0;
    	a[1][0]=1;a[1][1]=0;a[1][2]=1;a[1][3]=0;
    	a[2][0]=0;a[2][1]=0;a[2][2]=0;a[2][3]=1;
    	a[3][0]=0;a[3][1]=1;a[3][2]=0;a[3][3]=0;
    	*/
    	/*
    	a[0][0]=0;a[0][1]=1;a[0][2]=1;a[0][3]=0;
    	a[1][0]=1;a[1][1]=0;a[1][2]=1;a[1][3]=1;
    	a[2][0]=1;a[2][1]=1;a[2][2]=0;a[2][3]=1;
    	a[3][0]=0;a[3][1]=1;a[3][2]=1;a[3][3]=0;*/
    	 
    	/*
    	System.out.println("\n-----------------*1------------------");
    	setLaplacianMatrix(a);
       
		System.out.println("\nlaplacian out matrix:");
		for (int i = 0; i <4; i++) {
			System.out.print("    ");
			for (int j = 0; j < 4; j++) {
				System.out.print(laplacianOutMatrix[i][j]+"    ");
			}
			System.out.println();
		}
		System.out.println("\n");
        
        
		//Matrix laplacianIn=new Jama.Matrix(laplacianInMatrix);
		//EigenvalueDecomposition eIn=laplacianIn.eig();//this line takes 1 minute!!!
		
		Matrix laplacianOut=new Jama.Matrix(laplacianOutMatrix);
		EigenvalueDecomposition eOut=laplacianOut.eig();//this line takes 1 minute!!!
		
		//laplacianInImageEigenvalues=eIn.getImagEigenvalues();
		//laplacianInRealEigenvalues=eIn.getRealEigenvalues();
		
		laplacianOutImageEigenvalues=eOut.getImagEigenvalues();
		laplacianOutRealEigenvalues=eOut.getRealEigenvalues();
		
		System.out.println("\neigen vectors:");
		double[][] eVector=eOut.getV().getArray();
		for (int i = 0; i < eVector.length; i++) {
			for (int j = 0; j < eVector.length; j++) {
				System.out.print(eVector[i][j]+"\t");
			}
			System.out.println();
		}
		
    	double[] sortedLaplacianOutRealPart=laplacianOutRealEigenvalues;Arrays.sort(sortedLaplacianOutRealPart);
    	
    	double[] sortedLaplacianOutImgPart=laplacianOutImageEigenvalues;Arrays.sort(sortedLaplacianOutImgPart);
    	
    	//printing sorted real eigenvalues of laplacian in matrix
    	System.out.println("\nsorted Laplacian Out Real Part");
    	for (int i = 0; i < sortedLaplacianOutRealPart.length; i++) {
			System.out.print(sortedLaplacianOutRealPart[i]+"\t");
		}
    	//printing sorted imaginary eigenvalues of laplacian in matrix
    	System.out.println("\nsorted Laplacian out img Part");
    	for (int i = 0; i < sortedLaplacianOutImgPart.length; i++) {
			System.out.print(sortedLaplacianOutImgPart[i]+"\t");
		}
    	System.out.println("\n-----------------*2------------------");
    	setLaplacianMatrix(a);
       
		System.out.println("\nlaplacian out matrix:");
		for (int i = 0; i <4; i++) {
			System.out.print("    ");
			for (int j = 0; j < 4; j++) {
				System.out.print(laplacianOutMatrix[i][j]+"    ");
			}
			System.out.println();
		}
		System.out.println("\n");
        
        
		//Matrix laplacianIn=new Jama.Matrix(laplacianInMatrix);
		//EigenvalueDecomposition eIn=laplacianIn.eig();//this line takes 1 minute!!!
		
		laplacianOut=new Jama.Matrix(laplacianOutMatrix);
		eOut=laplacianOut.eig();//this line takes 1 minute!!!
		
		//laplacianInImageEigenvalues=eIn.getImagEigenvalues();
		//laplacianInRealEigenvalues=eIn.getRealEigenvalues();
		
		System.out.println("\neigen vectors:");
		eVector=eOut.getV().getArray();
		for (int i = 0; i < eVector.length; i++) {
			for (int j = 0; j < eVector.length; j++) {
				System.out.print(eVector[i][j]+"\t");
			}
			System.out.println();
		}
		
		laplacianOutImageEigenvalues=eOut.getImagEigenvalues();
		laplacianOutRealEigenvalues=eOut.getRealEigenvalues();
				
    	sortedLaplacianOutImgPart=laplacianOutRealEigenvalues;Arrays.sort(sortedLaplacianOutRealPart);
    	sortedLaplacianOutImgPart=laplacianOutImageEigenvalues;Arrays.sort(sortedLaplacianOutImgPart);
    	
    	//printing sorted real eigenvalues of laplacian in matrix
    	System.out.println("\nsorted Laplacian Out Real Part");
    	for (int i = 0; i < sortedLaplacianOutRealPart.length; i++) {
			System.out.print(sortedLaplacianOutRealPart[i]+"\t");
		}
    	//printing sorted imaginary eigenvalues of laplacian in matrix
    	System.out.println("\nsorted Laplacian out img Part");
    	for (int i = 0; i < sortedLaplacianOutImgPart.length; i++) {
			System.out.print(sortedLaplacianOutImgPart[i]+"\t");
		}
    	*/
    	
    	
    	
    	/*int lambda2InIndex=0;
    	double lambda2In=sortedLaplacianInRealPart[lambda2InIndex];
    	while (lambda2In==0) {
			lambda2InIndex++;
			lambda2In=sortedLaplacianInRealPart[lambda2InIndex];
		}
    	System.out.println("\nlambda2In:"+lambda2In);
    	System.out.println("lambdaMaxIn:"+sortedLaplacianInRealPart[sortedLaplacianInRealPart.length-1]);
    	*/
    	//printing sorted real eigenvalues of laplacian in matrix
    	//System.out.println("\nsorted Laplacian out Real Part");
    	//for (int i = 0; i < sortedLaplacianOutRealPart.length; i++) {
			//System.out.print(sortedLaplacianOutRealPart[i]+"\t");
		//}
    	/*
    	//printing sorted imaginary eigenvalues of laplacian out matrix
    	System.out.println("\nsorted Laplacian out img Part");
    	for (int i = 0; i < sortedLaplacianOutImgPart.length; i++) {
			System.out.print(sortedLaplacianOutImgPart[i]+"\t");
		}
    	
    	int lambda2OutIndex=0;
    	double lambda2Out=sortedLaplacianOutRealPart[lambda2OutIndex];
    	while (lambda2In==0) {
			lambda2OutIndex++;
			lambda2Out=sortedLaplacianOutRealPart[lambda2OutIndex];
		}
    	
    	System.out.println("\nlambda2Out:"+lambda2Out);
    	System.out.println("lambdaMaxOut:"+sortedLaplacianOutRealPart[sortedLaplacianOutRealPart.length-1]);
    	
    	InRatio=lambda2In/sortedLaplacianInRealPart[sortedLaplacianInRealPart.length-1];
    	OutRatio=lambda2Out/sortedLaplacianOutRealPart[sortedLaplacianOutRealPart.length-1];
    	*/
    	
    	//plotSUMofIPRsforP();
    	
    	/*
    	//3D plotting using jmatPlot
    	double[] X ={1,2,3,4,5};
    	double[] Y = {1,2,3,8,9};
    	double[] Z = {10,20,30,11,33};
    	double[][] XY=new double[2][2];
    			 
    	// create your PlotPanel (you can use it as a JPanel)
    	Plot2DPanel plot = new Plot2DPanel();
    	Plot3DPanel plot3d= new Plot3DPanel();
    			 
    	// add a line plot to the PlotPanel
    	plot3d.addScatterPlot("plot name", X, Y, Z);
    			 
    	// put the PlotPanel in a JFrame, as a JPanel
    	JFrame frame = new JFrame("a plot panel");
    	frame.setContentPane(plot3d);
    	frame.setVisible(true);
    	*/
    	/*
    	//jzy3D
    	int size = 10;
    	float x;
    	float y;
    	float z;
    	Coord3d[] points = new Coord3d[size];

    	// Create scatter points
    	for(int i=0; i<size; i++){
    	    x = (float)Math.random() - 0.5f;
    	    y = (float)Math.random() - 0.5f;
    	    z = (float)Math.random() - 0.5f;
    	    points[i] = new Coord3d(x, y, z);
    	}       

    	// Create a drawable scatter with a colormap
    	ScatterMultiColor scatter = new ScatterMultiColor( points, new ColorMapper( new ColorMapRainbow(), -0.5f, 0.5f ) );

    	// Create a chart and add scatter
    	Chart chart = new Chart();
    	chart.getAxeLayout().setMainColor(Color.WHITE);
    	chart.getView().setBackgroundColor(Color.BLACK);
    	chart.getScene().add(scatter);
    	ChartLauncher.openChart(chart);*/
		
		cal = Calendar.getInstance();
		//System.out.println("\nFinish time: "+dateFormat.format(cal.getTime())); 
    }
}