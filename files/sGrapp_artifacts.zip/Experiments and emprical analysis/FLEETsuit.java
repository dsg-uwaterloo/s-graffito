import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;


//One day I will go to HR and file a complaint against you!

public class FLEETsuit {

	/**
	 * @param args
	 */
	private static String[] getColumns(String line, String separator) { //enhance this by extracting feature vectors from the data set
        return line.split(separator);//("/t");//
    }
	private static Set<Integer> getIntersection(Set<Integer> set1, Set<Integer> set2) {
        boolean set1IsLarger = set1.size() > set2.size();
        Set<Integer> cloneSet = new HashSet<Integer>(set1IsLarger ? set2 : set1);
        cloneSet.retainAll(set1IsLarger ? set1 : set2);
        return cloneSet;
    }
	private static Set<Integer> mutualNeighbors(int v1, int v2, Map<Integer,HashSet<Integer>> neighbors){
	    	HashSet<Integer> neighbors1=neighbors.get(v1);
	    	HashSet<Integer> neighbors2=neighbors.get(v2);
	    	
	    	return getIntersection(neighbors1, neighbors2);
	    }
	private static Vector<Integer> toVector(Set<Integer> set){
    	Vector<Integer> v=new Vector<Integer>();
    	for (Integer i : set) {
			v.add(i);
		}
    	return v;   	
    }
	private static long BFC_perEdge(IJ_Edge e, Map<Integer,HashSet<Integer>> imap, Map<Integer,HashSet<Integer>> jmap){
		HashSet<Integer> i1Neighbors=imap.get(e.iID);
		HashSet<Integer> j1Neighbors=jmap.get(e.jID);
		if (i1Neighbors==null || j1Neighbors==null) {
			return 0;
		}
		long B_edge=0;
		for (Integer i2 : j1Neighbors) {
			for (Integer j2 : i1Neighbors) {
				if (imap.get(i2).contains(j2)) {
					B_edge++;
				}
			}
			
		}
		return B_edge;		
	}
	private static long exactCount(int avgIdeg, int avgJdeg, Map<Integer,HashSet<Integer>> imap, Map<Integer,HashSet<Integer>> jmap){
		
		Set<Integer> ivertices, jvertices, i2_vertices, j2_vertices;
		Vector<Integer>  i1neighbors=new Vector<Integer>(), j1neighbors=new Vector<Integer>(); List<Integer> i1neighbors_sublist=new ArrayList<Integer>(), j1neighbors_sublist=new ArrayList<Integer>(); 
		int i1neighbors_currentSize, j1, i2vertices_size, j1neighbors_currentSize, i1, j2vertices_size;
		HashSet<String> butterfly=new HashSet<String>(4);
		HashSet<HashSet<String>> identified_butterflies=new HashSet<HashSet<String>>();
		
		if (avgIdeg<=avgJdeg) {
			ivertices=imap.keySet();
			for (Integer vi1 : ivertices) {
				i1neighbors=toVector(imap.get(vi1));
				i1neighbors_currentSize=i1neighbors.size();
				for (int jindex = 0; jindex < i1neighbors_currentSize; jindex++) {//for each pair of i1's neighbors <j1,j2>, the mutual neighbors of j1 and j2 form a butterfly
					j1=i1neighbors.elementAt(jindex);
					i1neighbors_sublist=i1neighbors.subList(jindex+1, i1neighbors_currentSize);
					for (Integer vj2 : i1neighbors_sublist) {
						i2_vertices=mutualNeighbors(j1,vj2, jmap);i2_vertices.remove(vi1);
						i2vertices_size=i2_vertices.size();
						if (i2vertices_size!=0) {
							for (int vi2 : i2_vertices) {
								butterfly=new HashSet<String>(4);
								butterfly.add("i"+vi1);butterfly.add("j"+j1);butterfly.add("i"+vi2);butterfly.add("j"+vj2);
								identified_butterflies.add(butterfly);
							} 
						}						
					}
				}		
			} 
		}
		else{
			jvertices=jmap.keySet();
    		for (Integer vj1 : jvertices) {
    			j1neighbors=toVector(jmap.get(vj1));
    			j1neighbors_currentSize=j1neighbors.size();
    			for (int index = 0; index < j1neighbors_currentSize; index++) {//for each pair of j1's neighbors <i1,i2>, the mutual j-neighbors of i1 and i2 form a butterfly
    				i1=j1neighbors.elementAt(index);
    				j1neighbors_sublist=j1neighbors.subList(index+1, j1neighbors_currentSize);
    				for (Integer vi2 : j1neighbors_sublist) {
    					j2_vertices=mutualNeighbors(i1,vi2,imap);j2_vertices.remove(vj1);
    					j2vertices_size=j2_vertices.size();
    					if (j2vertices_size!=0) {
    						for (int vj2 : j2_vertices) {
    							butterfly=new HashSet<String>(4);
    							butterfly.add("i"+i1);butterfly.add("j"+vj1);butterfly.add("i"+vi2);butterfly.add("j"+vj2);
    							identified_butterflies.add(butterfly);
    						} 
    					}						
    				}
    			}	    		
    		} 
		}
		
		long B=identified_butterflies.size();
		return B;
	}
	
	private static Vector<Vector<Long>> Fleet1_latency_throughput(int startVertexIndexinFile, int stampColumn, String filename, int firstTimestamp, int lastTimeStep, int avgIdeg, int avgJdeg, String separator, int linebreaks, int M, double gama, int Nt) throws IOException{
		long beforeUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.nanoTime();
		System.out.println("Fleet1 Started at "+dateFormat.format(cal.getTime())+" , "+startTime+" nanosec");
		
		
		//PrintWriter w=new PrintWriter("Fleet1 - timestep - approximation - "+filename);
				
		Map<Integer,HashSet<Integer>> imap, jmap;
		//int previousTimestamp=firstTimestamp;
		
		
		
		//window management
		FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		int vertexI_ID,vertexJ_ID,timeStamp, interarrival;
		IJ_Edge e_ij;
		String[] columns;
		String sgt;
		//HashSet<Integer> uniquestamps=new HashSet<Integer>();
		
		Vector<IJ_Edge> currentEdges=new Vector<IJ_Edge>(), deletedEdges=new Vector<IJ_Edge>();
		
		
		BipartiteGraph BG=new BipartiteGraph();
		double P=1;
		long B=0;
		int t=0;
		double randP_subsampling=0, randP_sampling;
		
		
		Vector<Vector<Long>> step_B=new Vector<Vector<Long>>();
		//Vector<Long> temp=new Vector<Long>(2);
		
		if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while ((sgt = br.readLine()) != null && t<lastTimeStep){
			while (BG.edgeIDs_IJedges.size()>=M) {
				P=gama*P;
				for (IJ_Edge e : currentEdges) {
					randP_subsampling=Math.random();
					if (randP_subsampling<=1-gama && BG.IvertexID_JNeighborIDs_HashIndex.get(e.iID).contains(e.jID)) {
						BG.remove_IJedge(e);
						deletedEdges.add(e);
					}
				}			
			}
			for (IJ_Edge ij_Edge : deletedEdges) {
				currentEdges.remove(ij_Edge);
			}deletedEdges=new Vector<IJ_Edge>();
			
			imap=BG.IvertexID_JNeighborIDs_HashIndex;
			jmap=BG.JvertexID_INeighborIDs_HashIndex;
			B=exactCount(avgIdeg, avgJdeg, imap, jmap);B*=1.0/Math.pow(P, 4)*1.0;
			
			randP_sampling=Math.random();
			if (randP_sampling<=P) {
				
				vertexI_ID=0;vertexJ_ID=0;e_ij=null;
				columns = getColumns(sgt,separator);
				vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
				vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
				timeStamp=new BigDecimal(columns[stampColumn]).intValue();
				interarrival=0;//timeStamp-previousTimestamp;
				//previousTimestamp=timeStamp;
					    
		    	//update the graph
		    	e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
				if ( !(BG.IvertexID_JNeighborIDs_HashIndex.containsKey(e_ij.iID) && BG.IvertexID_JNeighborIDs_HashIndex.get(e_ij.iID).contains(e_ij.jID))){ 
					currentEdges.add(e_ij);
					BG.add_IJEdge(e_ij);
					//uniquestamps.add(timeStamp);
					
					imap=BG.IvertexID_JNeighborIDs_HashIndex;
					jmap=BG.JvertexID_INeighborIDs_HashIndex;
					B+=BFC_perEdge(e_ij, imap, jmap)*1.0/Math.pow(P, 4)*1.0;
				}
			}
			/*if (uniquestamps.size()==Nt) {
				temp=new Vector<Long>(2);temp.add( Long.valueOf(t));temp.add(B);
	    		step_B.add(temp);
	    		//w.append(t+" "+B+"\r\n");
	    		uniquestamps=new HashSet<Integer>();
			}*/
		    t++;	
		}
		br.close();//w.close();
		
		
		long afterUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	long actualMemUsed=afterUsedMem-beforeUsedMem;
    	long finishTime=System.nanoTime();
		long duration=finishTime-startTime;
		long thru=(long) ((lastTimeStep*1.0)/((duration)/Math.pow(10, 9)));
		cal = Calendar.getInstance();
		System.out.println("Fleet1 Finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" nanosec, duration="+duration+" nanosec+   memory usage:"+actualMemUsed+" thru="+thru );
		
		return step_B;				
	}
	private static Vector<Vector<Long>> Fleet2_latency_throughput(int startVertexIndexinFile, int stampColumn, String filename, int t0, int lastTimeStep, int avgIdeg, int avgJdeg, String separator, int linebreaks, int M, double gama, int Nt) throws IOException{
		long beforeUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.nanoTime();
		System.out.println("Fleet2 Started at "+dateFormat.format(cal.getTime())+" , "+startTime+" nanosec");
		
		//PrintWriter w=new PrintWriter("Fleet2 - timestep - approximation - "+filename);
				
		Map<Integer,HashSet<Integer>> imap, jmap;
		//int previousTimestamp=t0;
		
		
		//window management
		FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		int vertexI_ID,vertexJ_ID,timeStamp, interarrival;
		IJ_Edge e_ij;
		String[] columns;
		String sgt;
		HashSet<Integer> uniquestamps=new HashSet<Integer>();
		
		Vector<IJ_Edge> currentEdges=new Vector<IJ_Edge>(), deletedEdges=new Vector<IJ_Edge>();
		
		BipartiteGraph BG=new BipartiteGraph();
		double P=1;
		long B=0;
		int t=0;
		double randP_subsampling=0, randP_sampling;
		
		Vector<Vector<Long>> step_B=new Vector<Vector<Long>>();
		Vector<Long> temp=new Vector<Long>(2);
		
		if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while ((sgt = br.readLine()) != null && t<=lastTimeStep){
			while (BG.edgeIDs_IJedges.size()>=M) {
				P=gama*P;
				for (IJ_Edge e : currentEdges) {
					randP_subsampling=Math.random();
					if (randP_subsampling<=1-gama && BG.IvertexID_JNeighborIDs_HashIndex.get(e.iID).contains(e.jID)) {
						BG.remove_IJedge(e);
						deletedEdges.add(e);
					}
				}			
			}
			for (IJ_Edge ij_Edge : deletedEdges) {
				currentEdges.remove(ij_Edge);
			}deletedEdges=new Vector<IJ_Edge>();
			
			randP_sampling=Math.random();
			if (randP_sampling<=P) {
				
				vertexI_ID=0;vertexJ_ID=0;e_ij=null;
				columns = getColumns(sgt,separator);
				vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
				vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
				timeStamp=new BigDecimal(columns[stampColumn]).intValue();
				interarrival=0;//timeStamp-previousTimestamp;
				//previousTimestamp=timeStamp;
					    
		    	//update the graph
		    	e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
				if ( !(BG.IvertexID_JNeighborIDs_HashIndex.containsKey(e_ij.iID) && BG.IvertexID_JNeighborIDs_HashIndex.get(e_ij.iID).contains(e_ij.jID))){ 
					currentEdges.add(e_ij);
					BG.add_IJEdge(e_ij);
					uniquestamps.add(timeStamp);
					
					imap=BG.IvertexID_JNeighborIDs_HashIndex;
					jmap=BG.JvertexID_INeighborIDs_HashIndex;
					B+=BFC_perEdge(e_ij, imap, jmap)*1.0/Math.pow(P, 3)*1.0;
				}
			}
			/*if (uniquestamps.size()==Nt) {
				temp=new Vector<Long>(2);temp.add( Long.valueOf(t));temp.add(B);
	    		step_B.add(temp);//System.out.println("t="+t+"  B="+B);	
	    		//w.append(t+" "+B+"\r\n");
	    		uniquestamps=new HashSet<Integer>();
			}*/
		    t++;		
		}
		br.close();//w.close();
		
		long afterUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	long actualMemUsed=afterUsedMem-beforeUsedMem;
    	long finishTime=System.nanoTime();
		long duration=finishTime-startTime;
		long thru=(long) ((lastTimeStep*1.0)/((duration)/Math.pow(10, 9)));
		cal = Calendar.getInstance();
		System.out.println("Fleet2 Finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" nanosec, duration="+duration+" nanosec+   memory usage:"+actualMemUsed+" thru="+thru );
		
		return step_B;
	}
	private static Vector<Vector<Long>> Fleet3_latency_throughput(int startVertexIndexinFile, int stampColumn, String filename, int t0, int lastTimeStep, int avgIdeg, int avgJdeg, String separator, int linebreaks, int M, double gama, int Nt) throws IOException{
		long beforeUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.nanoTime();
		System.out.println("Fleet3 Started at "+dateFormat.format(cal.getTime())+" , "+startTime+" nanosec");
		//PrintWriter w=new PrintWriter("Fleet3 - timestep - approximation - "+filename);
				
		Map<Integer,HashSet<Integer>> imap, jmap;
		//int previousTimestamp=t0;	
		
		FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		int vertexI_ID,vertexJ_ID,timeStamp, interarrival;
		IJ_Edge e_ij;
		String[] columns;
		String sgt;
		//HashSet<Integer> uniquestamps=new HashSet<Integer>();
		
		Vector<IJ_Edge> currentEdges=new Vector<IJ_Edge>(), deletedEdges=new Vector<IJ_Edge>();
		
		
		BipartiteGraph BG=new BipartiteGraph();
		double P=1;
		long B=0;
		int t=0;
		double randP_subsampling=0, randP_sampling;
		
		
		Vector<Vector<Long>> step_B=new Vector<Vector<Long>>();
		Vector<Long> temp=new Vector<Long>(2);
		
		if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while ((sgt = br.readLine()) != null && t<=lastTimeStep){
			//ingest sgt
			vertexI_ID=0;vertexJ_ID=0;e_ij=null;
			columns = getColumns(sgt,separator);
			vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
			vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
			timeStamp=new BigDecimal(columns[stampColumn]).intValue();
			interarrival=0;//timeStamp-previousTimestamp;
			//previousTimestamp=timeStamp;
			e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
			
			
			imap=BG.IvertexID_JNeighborIDs_HashIndex;
			jmap=BG.JvertexID_INeighborIDs_HashIndex;
			B+=BFC_perEdge(e_ij, imap, jmap)*1.0/Math.pow(P, 3)*1.0;
			
			while (BG.edgeIDs_IJedges.size()>=M) {
				P=gama*P;
				for (IJ_Edge e : currentEdges) {
					randP_subsampling=Math.random();
					if (randP_subsampling<=1-gama && BG.IvertexID_JNeighborIDs_HashIndex.get(e.iID).contains(e.jID)) {
						BG.remove_IJedge(e);
						deletedEdges.add(e);
					}
				}			
			}
			for (IJ_Edge ij_Edge : deletedEdges) {
				currentEdges.remove(ij_Edge);
			}deletedEdges=new Vector<IJ_Edge>();
			
			randP_sampling=Math.random();
			if (randP_sampling<=P) {
				if ( !(BG.IvertexID_JNeighborIDs_HashIndex.containsKey(e_ij.iID) && BG.IvertexID_JNeighborIDs_HashIndex.get(e_ij.iID).contains(e_ij.jID))){ 
					currentEdges.add(e_ij);
					BG.add_IJEdge(e_ij);
					//uniquestamps.add(timeStamp);
				}
			}
			//if (uniquestamps.size()==Nt) {
				//temp=new Vector<Long>(2);temp.add( Long.valueOf(t));temp.add(B);
	    		//step_B.add(temp);//System.out.println("t="+t+"  B="+B);	
	    		//w.append(t+" "+B+"\r\n");
	    		//uniquestamps=new HashSet<Integer>();
			//}
			
		    t++;		
		}
		br.close();//w.close();
		
		long afterUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	long actualMemUsed=afterUsedMem-beforeUsedMem;
    	long finishTime=System.nanoTime();
		long duration=finishTime-startTime;
		long thru=(long) ((lastTimeStep*1.0)/((duration)/Math.pow(10, 9)));
		cal = Calendar.getInstance();
		System.out.println("Fleet3 Finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" nanosec, duration="+duration+" nanosec+   memory usage:"+actualMemUsed+" thru="+thru );
		
		return step_B;
	}
		
	private static Vector<Vector<Long>> Fleet1_MAPE(int startVertexIndexinFile, int stampColumn, String filename, int firstTimestamp, int lastTimeStep, int avgIdeg, int avgJdeg, String separator, int linebreaks, int M, double gama, int Nt) throws IOException{
		long beforeUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.nanoTime();
		System.out.println("Fleet1 Started at "+dateFormat.format(cal.getTime())+" , "+startTime+" nanosec");
		
		//PrintWriter w=new PrintWriter("Fleet1 - timestep - approximation - "+filename);
				
		Map<Integer,HashSet<Integer>> imap, jmap;
		//int previousTimestamp=firstTimestamp;
		
		
		FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		int vertexI_ID,vertexJ_ID,timeStamp, interarrival;
		IJ_Edge e_ij;
		String[] columns;
		String sgt;
		HashSet<Integer> uniquestamps=new HashSet<Integer>();
		
		Vector<IJ_Edge> currentEdges=new Vector<IJ_Edge>(), deletedEdges=new Vector<IJ_Edge>();
		
		
		BipartiteGraph BG=new BipartiteGraph();
		double P=1;
		long B=0;
		int t=0;
		double randP_subsampling=0, randP_sampling;
		
		Vector<Vector<Long>> step_B=new Vector<Vector<Long>>();
		Vector<Long> temp=new Vector<Long>(2);
		
		if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while ((sgt = br.readLine()) != null && t<lastTimeStep){
			while (BG.edgeIDs_IJedges.size()>=M) {
				P=gama*P;
				for (IJ_Edge e : currentEdges) {
					randP_subsampling=Math.random();
					if (randP_subsampling<=1-gama && BG.IvertexID_JNeighborIDs_HashIndex.get(e.iID).contains(e.jID)) {
						BG.remove_IJedge(e);
						deletedEdges.add(e);
					}
				}			
			}
			for (IJ_Edge ij_Edge : deletedEdges) {
				currentEdges.remove(ij_Edge);
			}deletedEdges=new Vector<IJ_Edge>();
			
			imap=BG.IvertexID_JNeighborIDs_HashIndex;
			jmap=BG.JvertexID_INeighborIDs_HashIndex;
			B=exactCount(avgIdeg, avgJdeg, imap, jmap);B*=1.0/Math.pow(P, 4)*1.0;
			
			randP_sampling=Math.random();
			if (randP_sampling<=P) {
				
				vertexI_ID=0;vertexJ_ID=0;e_ij=null;
				columns = getColumns(sgt,separator);
				vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
				vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
				timeStamp=new BigDecimal(columns[stampColumn]).intValue();
				interarrival=0;//timeStamp-previousTimestamp;
				//previousTimestamp=timeStamp;
					    
		    	//update the graph
		    	e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
				if ( !(BG.IvertexID_JNeighborIDs_HashIndex.containsKey(e_ij.iID) && BG.IvertexID_JNeighborIDs_HashIndex.get(e_ij.iID).contains(e_ij.jID))){ 
					currentEdges.add(e_ij);
					BG.add_IJEdge(e_ij);
					uniquestamps.add(timeStamp);
					
					imap=BG.IvertexID_JNeighborIDs_HashIndex;
					jmap=BG.JvertexID_INeighborIDs_HashIndex;
					B+=BFC_perEdge(e_ij, imap, jmap)*1.0/Math.pow(P, 4)*1.0;
				}
			}
			if (uniquestamps.size()==Nt) {
				temp=new Vector<Long>(2);temp.add( Long.valueOf(t));temp.add(B);
	    		step_B.add(temp);
	    		//w.append(t+" "+B+"\r\n");
	    		uniquestamps=new HashSet<Integer>();
			}
		    t++;	
		}
		br.close();//w.close();
		
		
		long afterUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	long actualMemUsed=afterUsedMem-beforeUsedMem;
    	long finishTime=System.nanoTime();
		long duration=finishTime-startTime;
		long thru=(long) ((lastTimeStep*1.0)/((duration)/Math.pow(10, 9)));
		cal = Calendar.getInstance();
		System.out.println("Fleet1 Finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" nanosec, duration="+duration+" nanosec+   memory usage:"+actualMemUsed+" thru="+thru );
		
		return step_B;				
	}
	private static Vector<Vector<Long>> Fleet2_MAPE(int startVertexIndexinFile, int stampColumn, String filename, int t0, int lastTimeStep, int avgIdeg, int avgJdeg, String separator, int linebreaks, int M, double gama, int Nt) throws IOException{
		long beforeUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.nanoTime();
		System.out.println("Fleet2 Started at "+dateFormat.format(cal.getTime())+" , "+startTime+" nanosec");
		
		//PrintWriter w=new PrintWriter("Fleet2 - timestep - approximation - "+filename);
				
		Map<Integer,HashSet<Integer>> imap, jmap;
		//int previousTimestamp=t0;
		
		
		FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		int vertexI_ID,vertexJ_ID,timeStamp, interarrival;
		IJ_Edge e_ij;
		String[] columns;
		String sgt;
		HashSet<Integer> uniquestamps=new HashSet<Integer>();
		
		Vector<IJ_Edge> currentEdges=new Vector<IJ_Edge>(), deletedEdges=new Vector<IJ_Edge>();
		
		BipartiteGraph BG=new BipartiteGraph();
		double P=1;
		long B=0;
		int t=0;
		double randP_subsampling=0, randP_sampling;
		
		Vector<Vector<Long>> step_B=new Vector<Vector<Long>>();
		Vector<Long> temp=new Vector<Long>(2);
		
		if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while ((sgt = br.readLine()) != null && t<=lastTimeStep){
			while (BG.edgeIDs_IJedges.size()>=M) {
				P=gama*P;
				for (IJ_Edge e : currentEdges) {
					randP_subsampling=Math.random();
					if (randP_subsampling<=1-gama && BG.IvertexID_JNeighborIDs_HashIndex.get(e.iID).contains(e.jID)) {
						BG.remove_IJedge(e);
						deletedEdges.add(e);
					}
				}			
			}
			for (IJ_Edge ij_Edge : deletedEdges) {
				currentEdges.remove(ij_Edge);
			}deletedEdges=new Vector<IJ_Edge>();
			
			randP_sampling=Math.random();
			if (randP_sampling<=P) {
				
				vertexI_ID=0;vertexJ_ID=0;e_ij=null;
				columns = getColumns(sgt,separator);
				vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
				vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
				timeStamp=new BigDecimal(columns[stampColumn]).intValue();
				interarrival=0;//timeStamp-previousTimestamp;
				//previousTimestamp=timeStamp;
					    
		    	//update the graph
		    	e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
				if ( !(BG.IvertexID_JNeighborIDs_HashIndex.containsKey(e_ij.iID) && BG.IvertexID_JNeighborIDs_HashIndex.get(e_ij.iID).contains(e_ij.jID))){ 
					currentEdges.add(e_ij);
					BG.add_IJEdge(e_ij);
					uniquestamps.add(timeStamp);
					
					imap=BG.IvertexID_JNeighborIDs_HashIndex;
					jmap=BG.JvertexID_INeighborIDs_HashIndex;
					B+=BFC_perEdge(e_ij, imap, jmap)*1.0/Math.pow(P, 3)*1.0;
				}
			}
			if (uniquestamps.size()==Nt) {
				temp=new Vector<Long>(2);temp.add( Long.valueOf(t));temp.add(B);
	    		step_B.add(temp);	
	    		//w.append(t+" "+B+"\r\n");
	    		uniquestamps=new HashSet<Integer>();
			}
		    t++;		
		}
		br.close();//w.close();
		
		long afterUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	long actualMemUsed=afterUsedMem-beforeUsedMem;
    	long finishTime=System.nanoTime();
		long duration=finishTime-startTime;
		long thru=(long) ((lastTimeStep*1.0)/((duration)/Math.pow(10, 9)));
		cal = Calendar.getInstance();
		System.out.println("Fleet2 Finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" nanosec, duration="+duration+" nanosec+   memory usage:"+actualMemUsed+" thru="+thru );
		
		return step_B;
	}
	private static Vector<Vector<Long>> Fleet3_MAPE(int startVertexIndexinFile, int stampColumn, String filename, int t0, int lastTimeStep, int avgIdeg, int avgJdeg, String separator, int linebreaks, int M, double gama, int Nt) throws IOException{
		long beforeUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.nanoTime();
		System.out.println("Fleet3 Started at "+dateFormat.format(cal.getTime())+" , "+startTime+" nanosec");
		//PrintWriter w=new PrintWriter("Fleet3 - timestep - approximation - "+filename);
				
		Map<Integer,HashSet<Integer>> imap, jmap;
		//int previousTimestamp=t0;	
		
		FileInputStream fstream = new FileInputStream(filename);
    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		int vertexI_ID,vertexJ_ID,timeStamp, interarrival;
		IJ_Edge e_ij;
		String[] columns;
		String sgt;
		HashSet<Integer> uniquestamps=new HashSet<Integer>();
		
		Vector<IJ_Edge> currentEdges=new Vector<IJ_Edge>(), deletedEdges=new Vector<IJ_Edge>();
		
		
		BipartiteGraph BG=new BipartiteGraph();
		double P=1;
		long B=0;
		int t=0;
		double randP_subsampling=0, randP_sampling;
		
		
		Vector<Vector<Long>> step_B=new Vector<Vector<Long>>();
		Vector<Long> temp=new Vector<Long>(2);
		
		if (linebreaks!=0) {
			for (int i = 0; i < linebreaks; i++) {
				br.readLine();
			}
		}
		while ((sgt = br.readLine()) != null && t<=lastTimeStep){
			
			vertexI_ID=0;vertexJ_ID=0;e_ij=null;
			columns = getColumns(sgt,separator);
			vertexI_ID=new BigDecimal(columns[0]).intValue()-startVertexIndexinFile;
			vertexJ_ID=new BigDecimal(columns[1]).intValue()-startVertexIndexinFile;
			timeStamp=new BigDecimal(columns[stampColumn]).intValue();
			interarrival=0;//timeStamp-previousTimestamp;
			//previousTimestamp=timeStamp;
			e_ij=new IJ_Edge(vertexI_ID,vertexJ_ID,timeStamp, interarrival);
			
			
			imap=BG.IvertexID_JNeighborIDs_HashIndex;
			jmap=BG.JvertexID_INeighborIDs_HashIndex;
			B+=BFC_perEdge(e_ij, imap, jmap)*1.0/Math.pow(P, 3)*1.0;
			
			while (BG.edgeIDs_IJedges.size()>=M) {
				P=gama*P;
				for (IJ_Edge e : currentEdges) {
					randP_subsampling=Math.random();
					if (randP_subsampling<=1-gama && BG.IvertexID_JNeighborIDs_HashIndex.get(e.iID).contains(e.jID)) {
						BG.remove_IJedge(e);
						deletedEdges.add(e);
					}
				}			
			}
			for (IJ_Edge ij_Edge : deletedEdges) {
				currentEdges.remove(ij_Edge);
			}deletedEdges=new Vector<IJ_Edge>();
			
			randP_sampling=Math.random();
			if (randP_sampling<=P) {
				if ( !(BG.IvertexID_JNeighborIDs_HashIndex.containsKey(e_ij.iID) && BG.IvertexID_JNeighborIDs_HashIndex.get(e_ij.iID).contains(e_ij.jID))){ 
					currentEdges.add(e_ij);
					BG.add_IJEdge(e_ij);
					uniquestamps.add(timeStamp);
				}
			}
			if (uniquestamps.size()==Nt) {
				temp=new Vector<Long>(2);temp.add( Long.valueOf(t));temp.add(B);
	    		step_B.add(temp);	
	    		//w.append(t+" "+B+"\r\n");
	    		uniquestamps=new HashSet<Integer>();
			}
			
		    t++;		
		}
		br.close();//w.close();
		
		long afterUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
    	long actualMemUsed=afterUsedMem-beforeUsedMem;
    	long finishTime=System.nanoTime();
		long duration=finishTime-startTime;
		long thru=(long) ((lastTimeStep*1.0)/((duration)/Math.pow(10, 9)));
		cal = Calendar.getInstance();
		System.out.println("Fleet3 Finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" nanosec, duration="+duration+" nanosec+   memory usage:"+actualMemUsed+" thru="+thru );
		
		return step_B;
	}
	
	private static Vector<Integer> readVector(String FileName) throws IOException{
			FileInputStream fstream = new FileInputStream(FileName);
	    	BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
			String line; 
			Vector<Integer> matrix=new Vector<Integer>(); 
			while((line= br.readLine())!=null) {
				matrix.add(Integer.parseInt(line));	    
			}
			br.close();
			return matrix;
		}
	private static double MAPE(Vector<Integer> truth, Vector<Vector<Long>> index_approximation){
	    	int n=index_approximation.size(); int n2=0;System.out.println(n);
	    	double mape=0;int index=0;
	    	double residual=0;
	    	for (int i = 0; i < n; i++) {
	    		index=index_approximation.elementAt(i).elementAt(0).intValue();
	    		if (truth.size()<=index) {
					break;
				}
	    		n2++;
	    		
	    		residual=(Math.abs(truth.elementAt(index)-index_approximation.elementAt(i).elementAt(1))*1.0)/(1.0*truth.elementAt(index));
	    		if (residual>0 && residual!=Double.POSITIVE_INFINITY && residual!=Double.NEGATIVE_INFINITY) {
	    			mape+=residual;
	    		}
				
				System.out.println("i="+i+" t="+index+" - truth="+truth.elementAt(index)+"  -  approximation="+index_approximation.elementAt(i).elementAt(1)+"  residual:"+residual);
			}
			mape/=(n2*1.0);//System.out.println("MAPE="+mape);
	    	
			System.out.println("mape over "+n2+" windows!!!!----------------> "+mape);
			
		return mape;
	}
	public static void print_MAPE(String truth_file, int startVertexIndexinFile, int stampColumn, String filename, int t0, int tl, int rows, int avgIdeg, int avgJdeg,String separator, int linebreaks,double gama, int Ntw) throws IOException{
	    
    	//PrintWriter w=new PrintWriter( "MAPE - "+filename);
    	
		
    	Vector<Vector<Long>> time_B;
    	double temp_MAPE=0;
    	
    	Vector<Integer> groundtruth=readVector(truth_file);
    	int m=(int) Math.round(tl*0.1);
		for (int M = m; M <=m ; M+=2500) {
			//time_B=Fleet1_MAPE(startVertexIndexinFile, stampColumn, filename, t0, tl, avgIdeg, avgJdeg, separator, linebreaks, M, gama, Ntw);
			time_B=Fleet2_MAPE(startVertexIndexinFile, stampColumn, filename, t0, tl, avgIdeg, avgJdeg, separator, linebreaks, M, gama, Ntw);
			//time_B=Fleet3_MAPE(startVertexIndexinFile, stampColumn, filename, t0, tl, avgIdeg, avgJdeg, separator, linebreaks, M, gama, Ntw);
			temp_MAPE=MAPE(groundtruth, time_B);
			//w.append(temp_MAPE+"\r\n");	
		}
    	//w.close();
    	
    	
    }
	
	public static void print_latency_Throughput(int startVertexIndexinFile, int stampColumn, String filename, int t0, int rows, int avgIdeg, int avgJdeg,String separator, int linebreaks, double gama, int M, int Ntw) throws IOException{
		//Fleet1_latency_throughput(startVertexIndexinFile, stampColumn, filename, t0, rows, avgIdeg, avgJdeg, separator, linebreaks, M, gama, Ntw);
		Fleet2_latency_throughput(startVertexIndexinFile, stampColumn, filename, t0, rows, avgIdeg, avgJdeg, separator, linebreaks, M, gama, Ntw);
    	//Fleet3_latency_throughput(startVertexIndexinFile, stampColumn, filename, t0, rows, avgIdeg, avgJdeg, separator, linebreaks, M, gama, Ntw);
			
	}	
    
	
	public static void main(String[] args) throws IOException {
		
		//----------> realworld edit-en-wiki
    	/*
		String filename="timesorted-Enwiki"; int stampColumn=2; String separator=" ";int linebreaks=0;int startVertexIndexinFile=1; 
    	int avgIdeg=70 , avgJdeg=12;
    	int t0=979768389; int Ni=262373039; int Nj=266665865; int rows=266769613;  int Nt=134075025; int tl=1283771188; double Butterflies=2*Math.pow(10, 12);	
    	int Ntw=290;int lastgroundtruth_Timestep=75000;	
		*/
		
        //----------> realworld edit-fr-wiki
    	/*
		String filename="timesorted-editfrwiki"; int stampColumn=2; String separator=" ";int linebreaks=0;int startVertexIndexinFile=1; 
    	int avgIdeg=160 , avgJdeg=11;
    	int t0=1036059361; int Ni=288275; int Nj=3992426; int rows=46168355;  int Nt=39190059; int tl=1283302334; double Butterflies=601.2*Math.pow(10, 12);
    	int Ntw=500;int lastgroundtruth_Timestep=75000;
		*/
		
    	//----------> realworld ML10m
   	    /*
		String filename="timesorted-ml10m"; int stampColumn=2; String separator=" ";int linebreaks=0;int startVertexIndexinFile=1; 
    	int avgIdeg=143, avgJdeg=937;
    	int t0=789652009; int Ni=69878; int Nj=10677; int rows=10000054;  int Nt=7096905; int tl=1231131103;
    	int Ntw=80;int lastgroundtruth_Timestep=21778;
		*/
		
    	//---------> realworld ML1m
    	/*
		String filename="timesortedmovielens1m"; int stampColumn=3; String separator=" ";int linebreaks=1;int startVertexIndexinFile=1; 
    	int avgIdeg=166, avgJdeg=270;
    	int uniquetimestamps=458455; int t0=956703932; int Ni=6040; int Nj=3706; int rows=1000210;  int Nt=458455;
    	int maxIdegat5k=888, maxJdegat5k=28;
		double avg_unique_Idegrees_at5k=128.13, avg_unique_Jdegrees_at5k=11.33;  
		double p_1ihub=0.43, p_2ihub=0.47, p_1jhub=0.15, p_2jhub=0.14;
		int Ntw=1050;int lastgroundtruth_Timestep=21696;
    	*/
		//----->real-world ml100k
    	
		String filename="timesorted100k";int winSize=100000;int avgIdeg=106;int avgJdeg=59;int startVertexIndexinFile=1;
    	int stampColumn=3;int t0=874724710, rows=100000,  Ni=943, Nj=1682; int ihubdegreeThreshold=250, jhubdegreeThreshold=250;
        String separator="\t";int linebreaks=0; int tl=893286638;int tspan=18561928;int Nt=49282;
		int maxIdegat5k=391, maxJdegat5k=34;
		double avg_unique_Idegrees_at5k=96, avg_unique_Jdegrees_at5k=15;
		int Ntw=912;int lastgroundtruth_Timestep=12259;
	
		
		//----------> real-world Epinions
    	/*
		String filename="timesortedEpinions1m";int stampColumn=2; int startVertexIndexinFile=1;
    	int Ni=22164; int Nj=296277; int rows=922267; int t0=931158000;int tl=1304924400; 
    	String separator=" ";int linebreaks=0; int Nt=4318;
    	int avgIdeg=41;int avgJdeg=3;
    	int maxIdegat5k=225, maxJdegat5k=33;
		double avg_unique_Idegrees_at5k=36.93, avg_unique_Jdegrees_at5k=13.48;    	
		double p_1ihub=0.35;//0.37;//
		double p_2ihub=0.54;//0.42;//
		double p_1jhub=0.13;;//0.29;//
		double p_2jhub=0.02;//0.14;//
		//double P_1or2_ihubs_inClqs_efectiveedgesconnectinhtoIhubs=0.88,  P_1or2_jhubs_inClqs_efectiveedgesconnectinhtoJhubs=0.15,  P_effective_ihub_degree=0.1, P_effective_jhub_degree=0.05;
		int Ntw=42;int lastgroundtruth_Timestep=72344;
    	*/
		
		//String truth_file=
				//"groundtruth cumulative number of cliques at all steps untill  tl=72344 timesortedEpinions1m";int lastTimestep=72344;int Ntw=42;
				//"groundtruth cumulative number of cliques at all steps untill  tl=12259 timesorted100k";int lastTimestep=12259;int Ntw=912;
				//"groundtruth cumulative number of cliques at all steps untill  tl=21696  timesortedmovielens1m";int lastTimestep=21696;//int Ntw=1050;
				//"groundtruth cumulative number of cliques at all steps untill  tl=21778 timesorted-ml10m";int lastTimestep=21778;//int Ntw=80;
				//"groundtruth cumulative number of cliques at all steps untill  tl=75000 timesorted-Enwiki";int lastTimestep=75000;//int Ntw=290;
				//"2 - groundtruth cumulative number of cliques at all steps untill  tl=75000 timesorted-editfrwiki";int lastTimestep=75000;//int Ntw=500;
				
		
		//double gama=0.7;System.out.println(filename+"- gama="+gama+" - Ntw="+Ntw+" M="+Math.round(lastTimestep*0.01));
		//writeMAPE(truth_file, startVertexIndexinFile, stampColumn, filename, t0, lastTimestep, rows, avgIdeg, avgJdeg, separator, linebreaks, gama,Ntw);
		
		
		int lastRunStep=rows;int M=75000;//(int) Math.round(lastRunStep*0.1);
		double gama=0.7;System.out.println(filename+"- gama="+gama+" - Ntw="+Ntw+" M="+M+" S="+lastRunStep);
		print_latency_Throughput(startVertexIndexinFile, stampColumn, filename, t0, lastRunStep, avgIdeg, avgJdeg, separator, linebreaks, gama, M, Ntw);
		
	}

}