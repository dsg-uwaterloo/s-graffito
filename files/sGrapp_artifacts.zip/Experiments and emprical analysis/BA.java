

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;


public class BA {

	graph5 graph;
	private int m0;
	private int edgesToAdd;

	
	public BA(int pNumNodes, boolean pDirected, int pInit, int pEdgesToAdd) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		long startTime=System.currentTimeMillis();
		System.out.println("\nBA() started at "+dateFormat.format(cal.getTime())+" , "+startTime+" millisec");
		
		m0 = pInit;
		
		if(m0 > pNumNodes)
		{
			m0 = pNumNodes;
		}
		edgesToAdd = pEdgesToAdd;
		graph=generate(pNumNodes, pDirected);
		
		long finishTime=System.currentTimeMillis();
		long duration=finishTime-startTime;
		cal = Calendar.getInstance();
		System.out.println("finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" millisec, duration="+duration+duration+" millisec" );
		
	}

	
	 public graph5 generate(int N, boolean directed) {

		graph5 g=new graph5();

		int degrees[] = new int[N];

		for (int i = 0; i < N; i++) 
		{
			g.add(i);
		}

		int numEdges = 0;
		
		for (int i = 0; i < m0; i++) 
		{
			for (int j = (i + 1); j < m0; j++) 
			{
				g.add(i,j,directed);	
				
				degrees[i]++;
				degrees[j]++;

				numEdges++;
			}
		}
		
		for (int i = m0; i < N; i++) 
		{
			int added = 0;
			double degreeIgnore = 0;
			for (int m = 0; m < edgesToAdd; m++) 
			{
				
				double prob = 0;
				
				double randNum = Math.random();			
							
				
				for (int j = 0; j < i; j++) 
				{
					
				
					if(!g.neighbors.get(i).contains(j) && !g.neighbors.get(j).contains(i))
					{
						
						prob += (double) ((double) degrees[j])
							/ ((double) (2.0d * numEdges) - degreeIgnore);
					}
					

					if (randNum <= prob) 
					{
						
						g.add(i,j,directed);

						degreeIgnore += degrees[j];

						
						added++;
						
						degrees[i]++;
						degrees[j]++;
						
						break;
					}
				}
				//System.out.println(m+" --> "+g.neighbors);
			}
			numEdges += added;
		}
		System.out.println("number of dges of BA:"+numEdges);
		//return the resulting network
		return g;
	}

	 public static void writelist(Map<Integer,ArrayList<Integer>> neighbors, String fileName) throws IOException{
		 DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			long startTime=System.currentTimeMillis();
			System.out.println("\nwritelist() started at "+dateFormat.format(cal.getTime())+" , "+startTime+" millisec");
					
		 PrintWriter w=null;
	    	try {
				w=new PrintWriter(fileName);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
	   
			Vector<Integer> edge;
			Set<Integer> keys=neighbors.keySet();
			ArrayList<Integer> destinations;
			for (Integer src : keys) {
				destinations=neighbors.get(src);
				for (int i = 0; i < destinations.size(); i++) {
					w.append(src+" "+destinations.get(i)+"\r\n");
				}																
			}
			w.close();		
			
			long finishTime=System.currentTimeMillis();
			long duration=finishTime-startTime;
			cal = Calendar.getInstance();
			System.out.println("finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" millisec, duration="+duration+duration+" millisec" );
			
	    } 
	 public static void writelist_randomStamps(Map<Integer,ArrayList<Integer>> neighbors, String fileName, int firstTimestamp, int lastTimestamp) throws IOException{
		 DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			long startTime=System.currentTimeMillis();
			System.out.println("\nwritelist_randomStamps() started at "+dateFormat.format(cal.getTime())+" , "+startTime+" millisec");
					
		 PrintWriter w=null;
	    	try {
				w=new PrintWriter(fileName);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
	    	int randomTimestamp;
			Vector<Integer> edge;
			Set<Integer> keys=neighbors.keySet();
			ArrayList<Integer> destinations;
			for (Integer src : keys) {
				destinations=neighbors.get(src);
				for (int i = 0; i < destinations.size(); i++) {
					randomTimestamp=(int) (Math.random()*Math.abs(lastTimestamp-firstTimestamp)+firstTimestamp);
					w.append(src+" "+destinations.get(i)+" "+randomTimestamp+"\r\n");
				}																
			}
			w.close();		
			
			long finishTime=System.currentTimeMillis();
			long duration=finishTime-startTime;
			cal = Calendar.getInstance();
			System.out.println("finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" millisec, duration="+duration+duration+" millisec" );
			
	    }
	 private static String[] getColumns(String line, String separator) { //enhance this by extracting feature vectors from the data set
	        return line.split(separator);//("/t");//
	    }
	 public static void writelist_readStamps(Map<Integer,ArrayList<Integer>> neighbors, String fileName, String nonsorted_stampfile, int firstTimestamp, int lastTimestamp) throws IOException{
		 DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			long startTime=System.currentTimeMillis();
			System.out.println("\nwritelist_readStamps() started at "+dateFormat.format(cal.getTime())+" , "+startTime+" millisec");
						
	    	PrintWriter w=null;
	    	try {
				w=new PrintWriter(fileName);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
	    	
	   FileInputStream fstream = new FileInputStream(nonsorted_stampfile);
	   BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
	     
	   String line;
	   int timestamp;
			Vector<Integer> edge;
			Set<Integer> keys=neighbors.keySet();
			ArrayList<Integer> destinations;
			for (Integer src : keys) {
				destinations=neighbors.get(src);
				for (int i = 0; i < destinations.size(); i++) {
					line=br.readLine();
					if(line!=null){
						timestamp=new BigDecimal(line).intValue();//Integer.parseInt(line);
					}
					else{
						timestamp=(int) (Math.random()*Math.abs(lastTimestamp-firstTimestamp)+firstTimestamp);					
					}
					w.append(src+" "+destinations.get(i)+" "+timestamp+"\r\n");
				}																
			}
			w.close();		
			
			long finishTime=System.currentTimeMillis();
			long duration=finishTime-startTime;
			cal = Calendar.getInstance();
			System.out.println("finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" millisec, duration="+duration+duration+" millisec" );
			
	    }
	
	 
	 private static HashSet<Integer> mutualNeighbors(int v1, int v2, Map<Integer,HashSet<Integer>> neighbors){
	    	/*HashSet<Integer> m=new HashSet<Integer>();
	    	HashSet<Integer> neighbors1=neighbors.get(v1);
	    	HashSet<Integer> neighbors2=neighbors.get(v2);
	    	int n1=neighbors1.size(), n2=neighbors2.size();
	    	if (n1<=n2) {
				for (Integer i : neighbors1) {
					if (neighbors2.contains(i)) {
						m.add(i);
					}
				}
			}
	    	else{
	    		for (Integer i : neighbors2) {
					if (neighbors1.contains(i)) {
						m.add(i);
					}
				}
	    	}
	    	return m;*/
	    	HashSet<Integer> neighbors1=neighbors.get(v1);
	    	HashSet<Integer> neighbors2=neighbors.get(v2);
	    	int n1=neighbors1.size(), n2=neighbors2.size();
	    	if (n1<=n2) {
				neighbors1.retainAll(neighbors2);
				return neighbors1;
			}
	    	else{
	    		neighbors2.retainAll(neighbors1);
				return neighbors2;
	    	}
	    }
	 
	 public static void main (String[] args) throws IOException{
		 DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			long startTime=System.currentTimeMillis();
			System.out.println("\nstarted at "+dateFormat.format(cal.getTime())+" , "+startTime+" millisec");
			
			
		boolean directed=true;
		//int N=996;int m0=106;int m=106; int t0=874724710;int tl=893286638; String nonsortedstampsFile="100kstamps"; String f0="BA-N="+N+"-m="+m+"-m0="+m0;  String f1="randomstamps BA-N="+N+"-m="+m+"-m0="+m0; String f2="movielens100kreadstamps BA-N="+N+"-m="+m+"-m0="+m0;
		
		//int N=6107;int m0=166;int m=166; int t0=956703932;int tl=1046454590; String nonsortedstampsFile="ml1mstamps"; String f0="ML1m-BA-N="+N+"-m="+m+"-m0="+m0;  String f1="ML1m-randomstamps-BA-N="+N+"-m="+m+"-m0="+m0; String f2="ML1m-readstamps-BA-N="+N+"-m="+m+"-m0="+m0;
		
		//non done//int N=119995;int m0=114;int m=114; int t0=979081200;int tl=1022709600; String f0="BA-N="+N+"-m="+m+"-m0="+m0;  String f1="epinions-randomstamps BA-N="+N+"-m="+m+"-m0="+m0; String f2="epinions-readstamps BA-N="+N+"-m="+m+"-m0="+m0;
		
		int N=22515;int m0=41;int m=41; int t0=931158000;int tl=1304924400; String nonsortedstampsFile="Epinions1mstamps"; String f0="Epinioins1m-BA-N="+N+"-m="+m+"-m0="+m0;  String f1="Epinions1m-randomstamps-BA-N="+N+"-m="+m+"-m0="+m0; String f2="Epinions1m-readstamps-BA-N="+N+"-m="+m+"-m0="+m0;
		
		//BA BA=new BA(N,directed,m0,m);
		//writelist(BA.graph.neighbors, f0);
		//writelist_randomStamps(BA.graph.neighbors, f1,t0, tl);
		//writelist_readStamps(BA.graph.neighbors, f2,nonsortedstampsFile,t0,tl);
		
		
		//graph5 g=BA.graph;
		//g.DegreeDistribution(g.getAdjacencyMatrix(0));		
		//g.printDegreeDistribution(g.outDegreeDistribution, "out degrees ", false);
		//System.out.println("195");
		//BA.graph.plot(g.inDegreeDistribution,"in-degree distribution- N="+N+" m=m0="+m, "in-degree", "density", true, false, 1);
		//System.out.println("197");
		//BA.graph.plot(g.outDegreeDistribution,"out-degree distribution - N="+N+" m=m0="+m, "out-degree", "density", true, true, 1);
		
    	long finishTime=System.currentTimeMillis();
		long duration=finishTime-startTime;
		cal = Calendar.getInstance();
		System.out.println("finished at "+dateFormat.format(cal.getTime())+", "+finishTime+" millisec, duration="+duration+" millisec" );		
	}
}
